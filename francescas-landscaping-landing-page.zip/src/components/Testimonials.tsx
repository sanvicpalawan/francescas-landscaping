import { useState } from "react";
import { useSite } from "../context/SiteContext";
import { LeafSpray, PalmFrond } from "./Leaves";
import { AlertIcon, LeafIcon, QuoteIcon, StarIcon } from "./Icons";
import { ChevronLeft, ChevronRight } from "lucide-react";

export function Testimonials() {
  const { data } = useSite();
  const { testimonials, sectionVisibility } = data;
  const [activeIndex, setActiveIndex] = useState(0);

  if (!sectionVisibility.testimonials || !testimonials.items.length) {
    return null;
  }

  const current = testimonials.items[activeIndex] || testimonials.items[0];

  const prev = () => {
    setActiveIndex((idx) =>
      idx === 0 ? testimonials.items.length - 1 : idx - 1,
    );
  };

  const next = () => {
    setActiveIndex((idx) =>
      idx === testimonials.items.length - 1 ? 0 : idx + 1,
    );
  };

  return (
    <section aria-labelledby="testimonials-heading" className="bg-cream pb-8 md:pb-9">
      <div className="shell">
        <h2 id="testimonials-heading" className="sr-only">
          {testimonials.sectionTitle}
        </h2>

        <div className="relative overflow-hidden rounded-2xl border border-[#E4DFCC] bg-[#F1EEDF]">
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
            <PalmFrond className="absolute -left-20 -top-24 h-64 w-auto -rotate-[140deg] text-leaf/[0.16]" />
            <PalmFrond className="absolute -left-14 bottom-0 h-44 w-auto rotate-[60deg] text-leaf/[0.12]" />
            <PalmFrond flip className="absolute -right-16 -top-24 h-56 w-auto text-leaf/[0.16]" />
            <PalmFrond flip className="absolute -right-14 -bottom-24 h-64 w-auto rotate-[130deg] text-leaf/[0.18]" />
            <LeafSpray className="absolute -right-20 top-1/2 h-56 w-auto -translate-y-1/2 text-leaf/[0.12]" />
          </div>

          <div className="desktop-testimonial relative z-10 grid gap-5 p-5 sm:p-6 md:p-7 min-[900px]:grid-cols-[minmax(0,1.7fr)_minmax(0,1fr)] min-[900px]:items-center min-[900px]:gap-0">
            <figure className="min-[900px]:pr-8">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <QuoteIcon className="h-5 w-8 text-leaf-dark" />
                  {current.isPlaceholder ? (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/80 px-2.5 py-1 font-sans text-[0.6rem] font-bold uppercase tracking-[0.13em] text-forest/70 ring-1 ring-inset ring-forest/10">
                      <AlertIcon className="h-3 w-3" strokeWidth={2} />
                      Placeholder testimonial
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-leaf/20 px-2.5 py-1 font-sans text-[0.6rem] font-bold uppercase tracking-[0.13em] text-leaf-dark">
                      Verified Client
                    </span>
                  )}
                </div>

                {testimonials.items.length > 1 ? (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={prev}
                      aria-label="Previous review"
                      className="grid h-7 w-7 place-items-center rounded-full bg-white/80 text-forest hover:bg-white"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                    <span className="text-[0.7rem] font-semibold text-forest/70">
                      {activeIndex + 1}/{testimonials.items.length}
                    </span>
                    <button
                      type="button"
                      onClick={next}
                      aria-label="Next review"
                      className="grid h-7 w-7 place-items-center rounded-full bg-white/80 text-forest hover:bg-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                ) : null}
              </div>

              <blockquote className="max-w-[36rem] font-sans text-[0.92rem] leading-relaxed text-forest/85 sm:text-[0.98rem]">
                &ldquo;{current.quote}&rdquo;
              </blockquote>

              <figcaption className="mt-4 flex items-center gap-3">
                {current.portraitUrl ? (
                  <img
                    src={current.portraitUrl}
                    alt={current.name}
                    className="h-12 w-12 rounded-full object-cover ring-2 ring-white"
                  />
                ) : (
                  <span className="relative grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-full bg-[#E4E9D7] text-forest/60 ring-2 ring-white">
                    <svg viewBox="0 0 48 48" className="h-full w-full" aria-hidden="true" focusable="false">
                      <circle cx="24" cy="18" r="8" fill="currentColor" opacity="0.55" />
                      <path d="M8 46c1.6-9.4 8-14 16-14s14.4 4.6 16 14" fill="currentColor" opacity="0.55" />
                    </svg>
                  </span>
                )}
                <div>
                  <p className="font-display text-[0.92rem] font-bold text-forest">{current.name}</p>
                  <p className="font-sans text-[0.78rem] text-forest/70">{current.role}</p>
                </div>
              </figcaption>
            </figure>

            <div className="desktop-aside border-t border-forest/15 pt-6 text-center min-[900px]:border-l min-[900px]:border-t-0 min-[900px]:py-2 min-[900px]:pl-8 min-[900px]:pt-2">
              <LeafIcon className="mx-auto h-6 w-6 text-leaf-dark" strokeWidth={1.7} />
              <p className="mx-auto mt-1.5 max-w-[15rem] font-display text-[1rem] font-semibold leading-snug text-forest">
                {testimonials.trustHeading}
              </p>
              <div className="mt-2.5 flex items-center justify-center gap-1" aria-hidden="true">
                {Array.from({ length: current.rating || 5 }).map((_, index) => (
                  <StarIcon key={index} className="h-5 w-5 text-leaf" />
                ))}
              </div>
              <p className="sr-only">Rating display: {current.rating || 5} of 5 stars.</p>
              {testimonials.ratingNote ? (
                <p className="mx-auto mt-2 max-w-[14rem] font-sans text-[0.65rem] leading-relaxed text-forest/50">
                  {testimonials.ratingNote}
                </p>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
