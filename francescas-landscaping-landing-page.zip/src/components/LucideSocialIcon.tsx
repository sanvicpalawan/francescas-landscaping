import type { SVGProps } from "react";
import {
  Globe,
  Mail,
  Phone,
  Share2,
  Video,
  Send,
  MessageCircle,
} from "lucide-react";

export interface SocialIconProps extends SVGProps<SVGSVGElement> {
  name: string;
  size?: number | string;
}

export function LucideSocialIcon({
  name,
  size = 20,
  className = "",
  ...props
}: SocialIconProps) {
  const normalized = (name || "").toLowerCase().trim();

  // Lucide-style SVG wrapper
  const svgProps = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className,
    ...props,
  };

  switch (normalized) {
    case "facebook":
    case "fb":
      return (
        <svg {...svgProps}>
          <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
        </svg>
      );

    case "instagram":
    case "ig":
      return (
        <svg {...svgProps}>
          <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
          <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
        </svg>
      );

    case "youtube":
    case "yt":
      return (
        <svg {...svgProps}>
          <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
          <path d="m10 15 5-3-5-3z" fill="currentColor" stroke="none" />
        </svg>
      );

    case "whatsapp":
    case "wa":
      return <MessageCircle size={size} className={className} {...props} />;

    case "twitter":
    case "x":
      return (
        <svg {...svgProps}>
          <path d="M4 4l11.733 16h4.267l-11.733 -16z" />
          <path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772" />
        </svg>
      );

    case "linkedin":
      return (
        <svg {...svgProps}>
          <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
          <rect width="4" height="12" x="2" y="9" />
          <circle cx="4" cy="4" r="2" />
        </svg>
      );

    case "tiktok":
      return (
        <svg {...svgProps}>
          <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
        </svg>
      );

    case "mail":
    case "email":
      return <Mail size={size} className={className} {...props} />;

    case "phone":
    case "tel":
      return <Phone size={size} className={className} {...props} />;

    case "video":
      return <Video size={size} className={className} {...props} />;

    case "telegram":
    case "send":
      return <Send size={size} className={className} {...props} />;

    case "share":
      return <Share2 size={size} className={className} {...props} />;

    case "globe":
    case "website":
    default:
      return <Globe size={size} className={className} {...props} />;
  }
}

export const AVAILABLE_SOCIAL_ICONS = [
  { id: "facebook", label: "Facebook" },
  { id: "instagram", label: "Instagram" },
  { id: "youtube", label: "YouTube" },
  { id: "whatsapp", label: "WhatsApp" },
  { id: "twitter", label: "Twitter / X" },
  { id: "linkedin", label: "LinkedIn" },
  { id: "tiktok", label: "TikTok" },
  { id: "globe", label: "Website / URL" },
  { id: "mail", label: "Email" },
  { id: "phone", label: "Phone" },
];
