import { useEffect, useRef, useState } from "react";
import { useSite } from "../context/SiteContext";
import { LeafSpray, PalmFrond } from "./Leaves";
import { CareLeafIcon, ShieldCheckIcon, SparklesIcon, UsersIcon } from "./Icons";
import { Leaf, Award } from "lucide-react";
import { cn } from "../utils/cn";

export function WhyChoose() {
  const { data } = useSite();
  const { whyChoose, sectionVisibility } = data;

  const [isInView, setIsInView] = useState(false);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.2 },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  if (!sectionVisibility.whyChoose || !whyChoose.items.length) {
    return null;
  }

  const renderIcon = (iconName: string, isHovered: boolean) => {
    switch (iconName) {
      case "reliable":
        return (
          <span className={cn("transition-transform duration-300", isHovered && "scale-115 text-leaf")}>
            <ShieldCheckIcon className="h-8 w-8 text-leaf-dark lg:h-9 lg:w-9" strokeWidth={1.5} />
          </span>
        );
      case "tropical":
        return (
          <span className={cn("inline-block transition-transform duration-500", isHovered && "rotate-12 scale-110 text-leaf")}>
            <CareLeafIcon className="h-8 w-8 text-leaf-dark lg:h-9 lg:w-9" strokeWidth={1.5} />
          </span>
        );
      case "tailored":
        return (
          <span className={cn("inline-block transition-transform duration-500", isHovered && "rotate-45 scale-115 text-leaf")}>
            <SparklesIcon className="h-8 w-8 text-leaf-dark lg:h-9 lg:w-9" strokeWidth={1.5} />
          </span>
        );
      case "eco":
        return (
          <span className={cn("inline-block transition-transform duration-500", isHovered && "-rotate-12 scale-115 text-leaf")}>
            <Leaf className="h-8 w-8 text-leaf-dark lg:h-9 lg:w-9" strokeWidth={1.5} />
          </span>
        );
      case "quality":
        return (
          <span className={cn("transition-transform duration-300", isHovered && "scale-115 text-leaf")}>
            <Award className="h-8 w-8 text-leaf-dark lg:h-9 lg:w-9" strokeWidth={1.5} />
          </span>
        );
      case "professional":
      default:
        return (
          <span className={cn("transition-transform duration-300", isHovered && "scale-115 -translate-y-0.5 text-leaf")}>
            <UsersIcon className="h-8 w-8 text-leaf-dark lg:h-9 lg:w-9" strokeWidth={1.5} />
          </span>
        );
    }
  };

  return (
    <section
      id="about"
      ref={sectionRef}
      aria-labelledby="about-heading"
      className="bg-cream pb-8 md:pb-9 transition-opacity duration-700"
    >
      <div className="shell">
        <div className="group/panel relative overflow-hidden rounded-2xl bg-[#F1EEDF] px-5 py-7 sm:px-7 sm:py-8 lg:px-9 shadow-[0_8px_30px_-20px_rgba(27,82,54,0.15)] transition-all duration-500 hover:shadow-[0_14px_40px_-20px_rgba(27,82,54,0.22)]">
          {/* Animated Tropical Foliage in Background — Gentle Breeze Swaying Effect */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
            <PalmFrond className="animate-tropical-left absolute -left-20 top-1/2 h-[125%] w-auto text-leaf/[0.18] transition-opacity duration-700 group-hover/panel:text-leaf/[0.24]" />
            <LeafSpray className="animate-tropical-drift absolute -right-14 -top-14 h-[110%] w-auto text-leaf/[0.14] transition-opacity duration-700 group-hover/panel:text-leaf/[0.20]" />
            <PalmFrond
              flip
              className="animate-tropical-right absolute -right-20 bottom-0 hidden h-[135%] w-auto text-leaf/[0.17] transition-opacity duration-700 group-hover/panel:text-leaf/[0.23] sm:block"
            />
          </div>

          <div className="relative z-10 grid items-center gap-6 sm:gap-7 min-[900px]:grid-cols-[minmax(0,0.9fr)_minmax(0,2.6fr)] min-[900px]:gap-8 lg:gap-10">
            {/* Title Column with Reveal Motion */}
            <div
              className={cn(
                "max-w-[16rem] transition-all duration-700",
                isInView ? "translate-x-0 opacity-100" : "-translate-x-4 opacity-0",
              )}
            >
              <h2
                id="about-heading"
                className="font-display text-[clamp(1.65rem,3.1vw,2.1rem)] font-bold leading-[1.12] tracking-[-0.03em] text-forest"
              >
                {whyChoose.sectionTitle}
              </h2>
              <span
                aria-hidden="true"
                className={cn(
                  "mt-3.5 block h-[3px] rounded-full bg-leaf transition-all duration-1000",
                  isInView ? "w-14" : "w-0",
                )}
              />
            </div>

            {/* Benefits Grid with Staggered Entrance and Interactive Hover Motion */}
            <ul className="desktop-benefits grid grid-cols-1 gap-y-5">
              {whyChoose.items.map((benefit, idx) => {
                const isHovered = hoveredIdx === idx;
                const delayMs = idx * 120;

                return (
                  <li
                    key={benefit.id}
                    onMouseEnter={() => setHoveredIdx(idx)}
                    onMouseLeave={() => setHoveredIdx(null)}
                    style={{ transitionDelay: `${delayMs}ms` }}
                    className={cn(
                      "desktop-benefit-item group/item relative flex flex-col items-start gap-2 border-t border-forest/10 pt-5 first:border-t-0 first:pt-0 sm:border-t-0 sm:pt-0 rounded-xl transition-all duration-500",
                      isInView ? "translate-y-0 opacity-100" : "translate-y-5 opacity-0",
                      isHovered && "sm:bg-white/40 sm:p-2.5 sm:-my-2.5 sm:shadow-sm sm:backdrop-blur-xs",
                    )}
                  >
                    {/* Icon container with subtle pulse / motion */}
                    <div className="relative">
                      <div className="relative z-10 transition-transform duration-300 group-hover/item:scale-110">
                        {renderIcon(benefit.icon, isHovered)}
                      </div>
                      {/* Ambient hover glow halo */}
                      <span
                        className={cn(
                          "absolute -inset-1 rounded-full bg-leaf/20 blur-md transition-opacity duration-300",
                          isHovered ? "opacity-100" : "opacity-0",
                        )}
                        aria-hidden="true"
                      />
                    </div>

                    <h3 className="mt-1 font-display text-[1.02rem] font-bold leading-tight text-forest transition-colors duration-200 group-hover/item:text-leaf-dark">
                      {benefit.title}
                    </h3>
                    <p className="max-w-[15rem] font-sans text-[0.8rem] leading-relaxed text-forest/80 transition-colors duration-200 group-hover/item:text-forest">
                      {benefit.description}
                    </p>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
