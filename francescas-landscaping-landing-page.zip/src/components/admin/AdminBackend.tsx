import { useState, type ChangeEvent } from "react";
import { useSite } from "../../context/SiteContext";
import {
  type ServiceItem,
  type ProjectItem,
  type BenefitItem,
  type ProcessItem,
  type FaqItem,
  type TestimonialItem,
  type SocialLinkItem,
  type NavItem,
} from "../../types/siteData";
import { LucideSocialIcon, AVAILABLE_SOCIAL_ICONS } from "../LucideSocialIcon";
import { PRESET_TROPICAL_IMAGES, PRESET_TROPICAL_VIDEOS } from "./AdminPresets";
import { Logo } from "../Logo";
import {
  X,
  Palette,
  Layout,
  Layers,
  Image as ImageIcon,
  Video as VideoIcon,
  HelpCircle,
  MessageSquare,
  Share2,
  Database,
  Plus,
  Trash2,
  RotateCcw,
  Check,
  Eye,
  Key,
  ShieldCheck,
  Upload,
  Play,
  Copy,
  Inbox,
  FileText,
  Sliders,
} from "lucide-react";

type AdminTab =
  | "theme"
  | "logos"
  | "header"
  | "hero"
  | "services"
  | "whyChoose"
  | "projects"
  | "process"
  | "faq"
  | "testimonials"
  | "form"
  | "inbox"
  | "footer"
  | "backup";

function HeaderLogoSection({
  data,
  updateData,
  showToast,
  handleLocalFileUpload,
}: {
  data: ReturnType<typeof useSite>["data"];
  updateData: ReturnType<typeof useSite>["updateData"];
  showToast: (msg: string) => void;
  handleLocalFileUpload: (
    e: ChangeEvent<HTMLInputElement>,
    onComplete: (dataUrl: string) => void,
  ) => void;
}) {
  const isCustom = Boolean(data.header.useCustomLogo && data.header.customLogoUrl);
  const currentHeight = data.header.logoHeight || 42;

  return (
    <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-cream-line/70 pb-3">
        <div>
          <h3 className="font-display text-sm font-bold text-forest flex items-center gap-2">
            <ImageIcon className="h-4 w-4 text-leaf" />
            <span>Header Logo Upload &amp; Size Control</span>
          </h3>
          <p className="text-xs text-forest/70">
            Upload a custom logo file for the header navigation bar, adjust its rendered height, or use the approved vector leaf mark.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              updateData((prev) => ({
                ...prev,
                header: { ...prev.header, useCustomLogo: false },
              }));
              showToast("Switched to Approved Brand Vector Logo");
            }}
            className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
              !data.header.useCustomLogo
                ? "bg-forest text-white"
                : "border border-gray-200 bg-gray-50 text-forest/70 hover:bg-gray-100"
            }`}
          >
            Approved Vector
          </button>
          <button
            type="button"
            onClick={() => {
              updateData((prev) => ({
                ...prev,
                header: { ...prev.header, useCustomLogo: true },
              }));
              showToast("Switched to Custom Uploaded Logo");
            }}
            className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
              data.header.useCustomLogo
                ? "bg-forest text-white"
                : "border border-gray-200 bg-gray-50 text-forest/70 hover:bg-gray-100"
            }`}
          >
            Custom Logo
          </button>
        </div>
      </div>

      {/* File upload + URL */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-lg border border-dashed border-gray-300 bg-cream-soft p-3.5 text-center">
          <label className="block text-xs font-bold text-forest mb-1">
            Upload Header Logo File
          </label>
          <p className="text-[0.68rem] text-forest/60 mb-2">
            PNG, SVG, JPG, or WebP with transparent background
          </p>
          <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg bg-leaf px-3 py-1.5 text-xs font-bold text-white shadow-sm transition hover:bg-leaf-dark">
            <Upload className="h-3.5 w-3.5" />
            <span>Choose Logo File</span>
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(e) =>
                handleLocalFileUpload(e, (dataUrl) => {
                  updateData((prev) => ({
                    ...prev,
                    header: {
                      ...prev.header,
                      customLogoUrl: dataUrl,
                      useCustomLogo: true,
                    },
                  }));
                  showToast("Header logo uploaded and activated!");
                })
              }
            />
          </label>
        </div>

        <div>
          <label className="block text-xs font-semibold text-forest">
            Or Paste Custom Logo Image URL
          </label>
          <input
            type="url"
            value={data.header.customLogoUrl || ""}
            onChange={(e) => {
              const val = e.target.value;
              updateData((prev) => ({
                ...prev,
                header: {
                  ...prev.header,
                  customLogoUrl: val,
                  useCustomLogo: Boolean(val),
                },
              }));
            }}
            placeholder="https://example.com/logo.png"
            className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
          />
          {data.header.customLogoUrl ? (
            <button
              type="button"
              onClick={() => {
                updateData((prev) => ({
                  ...prev,
                  header: {
                    ...prev.header,
                    customLogoUrl: "",
                    useCustomLogo: false,
                  },
                }));
                showToast("Custom logo cleared; reverted to approved vector mark.");
              }}
              className="mt-2 text-xs font-semibold text-red-600 hover:underline"
            >
              Clear Custom Logo
            </button>
          ) : null}
        </div>
      </div>

      {/* Height Slider & Presets */}
      <div className="rounded-lg border border-cream-line p-3.5 bg-cream-soft">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-forest flex items-center gap-1.5">
            <Sliders className="h-3.5 w-3.5 text-leaf" />
            <span>Adjust Header Logo Size / Height</span>
          </label>
          <span className="rounded-full bg-forest px-2.5 py-0.5 font-mono text-xs font-bold text-white">
            {currentHeight}px
          </span>
        </div>

        <div className="mt-3 flex items-center gap-3">
          <span className="text-[0.68rem] text-forest/60">24px</span>
          <input
            type="range"
            min={24}
            max={100}
            step={2}
            value={currentHeight}
            onChange={(e) => {
              const val = Number(e.target.value);
              updateData((prev) => ({
                ...prev,
                header: { ...prev.header, logoHeight: val },
              }));
            }}
            className="flex-1 accent-leaf cursor-pointer"
          />
          <span className="text-[0.68rem] text-forest/60">100px</span>
        </div>

        {/* Quick Presets */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-[0.68rem] font-semibold text-forest/70">Presets:</span>
          {[
            { label: "Compact (32px)", h: 32 },
            { label: "Standard (42px)", h: 42 },
            { label: "Medium (54px)", h: 54 },
            { label: "Large (68px)", h: 68 },
            { label: "Heroic (84px)", h: 84 },
          ].map((preset) => (
            <button
              key={preset.h}
              type="button"
              onClick={() => {
                updateData((prev) => ({
                  ...prev,
                  header: { ...prev.header, logoHeight: preset.h },
                }));
                showToast(`Header logo height set to ${preset.h}px`);
              }}
              className={`rounded-md px-2 py-1 text-[0.68rem] font-semibold transition ${
                currentHeight === preset.h
                  ? "bg-leaf text-white"
                  : "bg-white border border-cream-line text-forest/80 hover:bg-cream"
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* Live Preview Box */}
      <div>
        <p className="text-xs font-semibold text-forest mb-1.5">
          Live Header Logo Preview (On White Nav Bar)
        </p>
        <div className="flex min-h-[90px] items-center justify-center rounded-xl border border-cream-line bg-white p-4 shadow-inner">
          {isCustom ? (
            <img
              src={data.header.customLogoUrl}
              alt="Custom Header Logo"
              style={{ height: `${currentHeight}px` }}
              className="w-auto object-contain"
            />
          ) : (
            <Logo height={currentHeight} />
          )}
        </div>
      </div>
    </div>
  );
}

function FooterLogoSection({
  data,
  updateData,
  showToast,
  handleLocalFileUpload,
}: {
  data: ReturnType<typeof useSite>["data"];
  updateData: ReturnType<typeof useSite>["updateData"];
  showToast: (msg: string) => void;
  handleLocalFileUpload: (
    e: ChangeEvent<HTMLInputElement>,
    onComplete: (dataUrl: string) => void,
  ) => void;
}) {
  const isCustom = Boolean(data.footer.useCustomLogo && data.footer.customLogoUrl);
  const currentHeight = data.footer.logoHeight || 46;

  return (
    <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-cream-line/70 pb-3">
        <div>
          <h3 className="font-display text-sm font-bold text-forest flex items-center gap-2">
            <ImageIcon className="h-4 w-4 text-leaf" />
            <span>Footer Logo Upload &amp; Size Control</span>
          </h3>
          <p className="text-xs text-forest/70">
            Upload custom logo for the dark footer, adjust height slider, or use the approved white vector mark.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              updateData((prev) => ({
                ...prev,
                footer: { ...prev.footer, useCustomLogo: false },
              }));
              showToast("Switched to Approved White Vector Logo");
            }}
            className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
              !data.footer.useCustomLogo
                ? "bg-forest text-white"
                : "border border-gray-200 bg-gray-50 text-forest/70 hover:bg-gray-100"
            }`}
          >
            Approved White Vector
          </button>
          <button
            type="button"
            onClick={() => {
              updateData((prev) => ({
                ...prev,
                footer: { ...prev.footer, useCustomLogo: true },
              }));
              showToast("Switched to Custom Footer Logo");
            }}
            className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
              data.footer.useCustomLogo
                ? "bg-forest text-white"
                : "border border-gray-200 bg-gray-50 text-forest/70 hover:bg-gray-100"
            }`}
          >
            Custom Logo
          </button>
        </div>
      </div>

      {/* File upload + URL + Sync from Header */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-lg border border-dashed border-gray-300 bg-cream-soft p-3.5 text-center">
          <label className="block text-xs font-bold text-forest mb-1">
            Upload Footer Logo File
          </label>
          <p className="text-[0.68rem] text-forest/60 mb-2">
            White or transparent SVG/PNG recommended for dark green footer
          </p>
          <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg bg-leaf px-3 py-1.5 text-xs font-bold text-white shadow-sm transition hover:bg-leaf-dark">
            <Upload className="h-3.5 w-3.5" />
            <span>Choose Footer Logo</span>
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(e) =>
                handleLocalFileUpload(e, (dataUrl) => {
                  updateData((prev) => ({
                    ...prev,
                    footer: {
                      ...prev.footer,
                      customLogoUrl: dataUrl,
                      useCustomLogo: true,
                    },
                  }));
                  showToast("Footer logo uploaded and activated!");
                })
              }
            />
          </label>
        </div>

        <div>
          <label className="block text-xs font-semibold text-forest">
            Or Paste Footer Logo Image URL
          </label>
          <input
            type="url"
            value={data.footer.customLogoUrl || ""}
            onChange={(e) => {
              const val = e.target.value;
              updateData((prev) => ({
                ...prev,
                footer: {
                  ...prev.footer,
                  customLogoUrl: val,
                  useCustomLogo: Boolean(val),
                },
              }));
            }}
            placeholder="https://example.com/footer-logo-white.png"
            className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
          />

          <div className="mt-2 flex items-center gap-3">
            {data.header.customLogoUrl ? (
              <button
                type="button"
                onClick={() => {
                  updateData((prev) => ({
                    ...prev,
                    footer: {
                      ...prev.footer,
                      customLogoUrl: prev.header.customLogoUrl,
                      useCustomLogo: true,
                    },
                  }));
                  showToast("Copied header logo to footer!");
                }}
                className="text-xs font-semibold text-leaf-dark hover:underline"
              >
                + Copy from Header Logo
              </button>
            ) : null}

            {data.footer.customLogoUrl ? (
              <button
                type="button"
                onClick={() => {
                  updateData((prev) => ({
                    ...prev,
                    footer: {
                      ...prev.footer,
                      customLogoUrl: "",
                      useCustomLogo: false,
                    },
                  }));
                  showToast("Footer custom logo cleared; reverted to white vector mark.");
                }}
                className="text-xs font-semibold text-red-600 hover:underline"
              >
                Clear Custom Logo
              </button>
            ) : null}
          </div>
        </div>
      </div>

      {/* Height Slider & Presets */}
      <div className="rounded-lg border border-cream-line p-3.5 bg-cream-soft">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-forest flex items-center gap-1.5">
            <Sliders className="h-3.5 w-3.5 text-leaf" />
            <span>Adjust Footer Logo Size / Height</span>
          </label>
          <span className="rounded-full bg-forest px-2.5 py-0.5 font-mono text-xs font-bold text-white">
            {currentHeight}px
          </span>
        </div>

        <div className="mt-3 flex items-center gap-3">
          <span className="text-[0.68rem] text-forest/60">24px</span>
          <input
            type="range"
            min={24}
            max={120}
            step={2}
            value={currentHeight}
            onChange={(e) => {
              const val = Number(e.target.value);
              updateData((prev) => ({
                ...prev,
                footer: { ...prev.footer, logoHeight: val },
              }));
            }}
            className="flex-1 accent-leaf cursor-pointer"
          />
          <span className="text-[0.68rem] text-forest/60">120px</span>
        </div>

        {/* Quick Presets */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-[0.68rem] font-semibold text-forest/70">Presets:</span>
          {[
            { label: "Compact (36px)", h: 36 },
            { label: "Standard (46px)", h: 46 },
            { label: "Medium (60px)", h: 60 },
            { label: "Large (76px)", h: 76 },
            { label: "Heroic (92px)", h: 92 },
          ].map((preset) => (
            <button
              key={preset.h}
              type="button"
              onClick={() => {
                updateData((prev) => ({
                  ...prev,
                  footer: { ...prev.footer, logoHeight: preset.h },
                }));
                showToast(`Footer logo height set to ${preset.h}px`);
              }}
              className={`rounded-md px-2 py-1 text-[0.68rem] font-semibold transition ${
                currentHeight === preset.h
                  ? "bg-leaf text-white"
                  : "bg-white border border-cream-line text-forest/80 hover:bg-cream"
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* Live Preview Box on Dark Forest Background */}
      <div>
        <p className="text-xs font-semibold text-forest mb-1.5">
          Live Footer Logo Preview (On Deep Forest Background)
        </p>
        <div className="flex min-h-[90px] items-center justify-center rounded-xl border border-forest-deep bg-forest-deep p-4 shadow-inner">
          {isCustom ? (
            <img
              src={data.footer.customLogoUrl}
              alt="Custom Footer Logo"
              style={{ height: `${currentHeight}px` }}
              className="w-auto object-contain brightness-0 invert"
            />
          ) : (
            <Logo tone="white" variant="footer" height={currentHeight} />
          )}
        </div>
      </div>
    </div>
  );
}

export function AdminBackend() {
  const {
    data,
    updateData,
    resetToDefaults,
    exportJson,
    importJson,
    isAdminOpen,
    closeAdmin,
    submissions,
    markSubmissionRead,
    deleteSubmission,
    clearSubmissions,
  } = useSite();

  const [activeTab, setActiveTab] = useState<AdminTab>("theme");
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [importText, setImportText] = useState("");
  const [showPresetPickerFor, setShowPresetPickerFor] = useState<{
    target: "hero" | "project" | "service";
    projectId?: string;
    serviceId?: string;
    subIndex?: number;
  } | null>(null);

  if (!isAdminOpen) return null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Helper for local file preview (Data URL)
  const handleLocalFileUpload = (
    e: ChangeEvent<HTMLInputElement>,
    onComplete: (dataUrl: string) => void,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        onComplete(result);
        showToast("Local media loaded for live preview!");
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-[200] flex flex-col bg-slate-900/80 backdrop-blur-sm">
      {/* Top Banner & Header */}
      <header className="flex shrink-0 items-center justify-between border-b border-forest/20 bg-forest-deep px-4 py-3 text-white sm:px-6">
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-leaf text-white shadow-sm">
            <Key className="h-5 w-5" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display text-base font-bold tracking-tight text-white sm:text-lg">
                Francesca&rsquo;s Admin CMS
              </h1>
              <span className="hidden rounded-full bg-leaf/20 px-2.5 py-0.5 font-sans text-[0.65rem] font-semibold text-leaf sm:inline-block">
                No Login Required • Site Creation Mode
              </span>
            </div>
            <p className="font-sans text-[0.7rem] text-white/60">
              Live updates reflect instantly across the landing page and save to browser storage.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {submissions.filter((s) => !s.read).length > 0 ? (
            <button
              type="button"
              onClick={() => setActiveTab("inbox")}
              className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/20 px-3 py-1 font-sans text-xs font-semibold text-amber-300 ring-1 ring-amber-500/30"
            >
              <Inbox className="h-3.5 w-3.5" />
              <span>{submissions.filter((s) => !s.read).length} New Inquiries</span>
            </button>
          ) : null}

          <button
            type="button"
            onClick={() => {
              showToast("All changes are automatically synced!");
            }}
            className="hidden items-center gap-1.5 rounded-md border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-white/20 sm:inline-flex"
          >
            <Check className="h-3.5 w-3.5 text-leaf" />
            <span>Synced</span>
          </button>

          <button
            type="button"
            onClick={closeAdmin}
            className="inline-flex items-center gap-1.5 rounded-md bg-leaf px-3.5 py-1.5 font-display text-xs font-bold text-white shadow transition hover:bg-leaf-dark"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>Back to Site</span>
          </button>

          <button
            type="button"
            onClick={closeAdmin}
            aria-label="Close admin modal"
            className="grid h-8 w-8 place-items-center rounded-md text-white/70 transition hover:bg-white/10 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Main Admin Workspace: Sidebar + Content */}
      <div className="flex min-h-0 flex-1 overflow-hidden bg-[#F6F5EE]">
        {/* Navigation Sidebar */}
        <aside className="w-56 shrink-0 overflow-y-auto border-r border-cream-line/80 bg-white p-2.5 sm:w-64">
          <p className="px-2.5 py-1.5 font-display text-[0.68rem] font-bold uppercase tracking-wider text-forest/50">
            Site Controls
          </p>

          <nav className="space-y-1">
            {[
              { id: "theme", label: "Theme & Palette", icon: Palette },
              { id: "logos", label: "Logos & Sizing", icon: Sliders },
              { id: "header", label: "Header & Nav", icon: Layout },
              { id: "hero", label: "Hero (Image / Video)", icon: Play },
              { id: "services", label: "Services (Cards)", icon: Layers },
              { id: "whyChoose", label: "Why Choose Us", icon: ShieldCheck },
              { id: "projects", label: "Projects & Media", icon: ImageIcon },
              { id: "process", label: "Process Stages", icon: Check },
              { id: "faq", label: "Frequently Asked Questions", icon: HelpCircle },
              { id: "testimonials", label: "Testimonials", icon: MessageSquare },
              { id: "form", label: "Quote Form Builder", icon: FileText },
              { id: "inbox", label: "Inquiries Inbox", icon: Inbox, count: submissions.length },
              { id: "footer", label: "Footer & Social URLs", icon: Share2 },
              { id: "backup", label: "Backup & Reset", icon: Database },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id as AdminTab)}
                  className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs font-semibold transition ${
                    isActive
                      ? "bg-forest text-white shadow-sm"
                      : "text-forest/80 hover:bg-cream hover:text-forest"
                  }`}
                >
                  <span className="flex items-center gap-2.5 truncate">
                    <Icon className={`h-4 w-4 shrink-0 ${isActive ? "text-leaf" : "text-forest/60"}`} />
                    <span className="truncate">{item.label}</span>
                  </span>
                  {item.count !== undefined && item.count > 0 ? (
                    <span
                      className={`rounded-full px-1.5 py-0.2 text-[0.65rem] font-bold ${
                        isActive ? "bg-white text-forest" : "bg-forest/10 text-forest"
                      }`}
                    >
                      {item.count}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>

          <div className="mt-6 border-t border-cream-line/70 pt-4">
            <button
              type="button"
              onClick={() => {
                if (window.confirm("Reset all content, colors, and media to the master reference design?")) {
                  resetToDefaults();
                  showToast("Reset to master reference design!");
                }
              }}
              className="flex w-full items-center gap-2 rounded-lg border border-red-200 bg-red-50/70 px-3 py-2 text-xs font-semibold text-red-700 transition hover:bg-red-100"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset to Defaults</span>
            </button>
          </div>
        </aside>

        {/* Tab Content Panel */}
        <main className="min-w-0 flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {/* TAB: THEME & COLOR PALETTE */}
          {activeTab === "theme" && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-forest">
                  Color Palette &amp; Typography
                </h2>
                <p className="mt-1 text-xs text-forest/70">
                  Control the brand color scheme and fonts. Changes update instantly across all components.
                </p>
              </div>

              {/* Color pickers */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm">
                <h3 className="font-display text-sm font-bold text-forest">
                  Approved Brand Colors (Hex &amp; Picker)
                </h3>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  {[
                    { key: "forest", label: "Primary Forest Green", default: "#1B5236" },
                    { key: "forestDeep", label: "Deep Forest / Footer", default: "#143F2A" },
                    { key: "leaf", label: "Secondary Leaf Green", default: "#6EB33F" },
                    { key: "leafDark", label: "Leaf Green Dark (Hover)", default: "#4F8E2A" },
                    { key: "cream", label: "Warm Cream Background", default: "#F6F3E8" },
                    { key: "creamLine", label: "Cream Border Line", default: "#E7E2D2" },
                    { key: "earth", label: "Earth Brown Accent", default: "#7B5E3B" },
                  ].map((c) => (
                    <div key={c.key} className="flex items-center gap-3 rounded-lg border border-cream-line p-2.5">
                      <input
                        type="color"
                        value={(data.theme as any)[c.key] || c.default}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            theme: { ...prev.theme, [c.key]: val },
                          }));
                        }}
                        className="h-9 w-10 cursor-pointer rounded border border-gray-300"
                      />
                      <div className="flex-1">
                        <label className="block text-xs font-semibold text-forest">
                          {c.label}
                        </label>
                        <input
                          type="text"
                          value={(data.theme as any)[c.key] || c.default}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              theme: { ...prev.theme, [c.key]: val },
                            }));
                          }}
                          className="mt-0.5 w-full rounded border border-gray-200 px-2 py-0.5 text-xs font-mono uppercase text-forest"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Typography */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm">
                <h3 className="font-display text-sm font-bold text-forest">
                  Typography &amp; Fonts
                </h3>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">
                      Heading Font (Display)
                    </label>
                    <select
                      value={data.theme.headingFont}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          theme: { ...prev.theme, headingFont: val },
                        }));
                        showToast(`Heading font updated to ${val}`);
                      }}
                      className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs font-medium text-forest"
                    >
                      <option value="Montserrat">Montserrat (Brand Guideline Default)</option>
                      <option value="Playfair Display">Playfair Display (Editorial Luxury)</option>
                      <option value="Plus Jakarta Sans">Plus Jakarta Sans (Modern Clean)</option>
                      <option value="Poppins">Poppins (Friendly Geometric)</option>
                      <option value="Cinzel">Cinzel (Classic Architectural)</option>
                      <option value="Inter">Inter (Ultra Clean Sans)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-forest">
                      Body Font (Content)
                    </label>
                    <select
                      value={data.theme.bodyFont}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          theme: { ...prev.theme, bodyFont: val },
                        }));
                        showToast(`Body font updated to ${val}`);
                      }}
                      className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs font-medium text-forest"
                    >
                      <option value="Open Sans">Open Sans (Brand Guideline Default)</option>
                      <option value="Inter">Inter (Modern Clean)</option>
                      <option value="Lato">Lato (Balanced Neutral)</option>
                      <option value="Roboto">Roboto (Crisp Technical)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Section Visibility Toggles */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm">
                <h3 className="font-display text-sm font-bold text-forest">
                  Section Visibility Controls
                </h3>
                <p className="mt-0.5 text-xs text-forest/70">
                  Enable or disable sections on the landing page at any time.
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {[
                    { key: "services", label: "Our Services" },
                    { key: "whyChoose", label: "Why Choose Francesca's" },
                    { key: "projects", label: "Featured Projects" },
                    { key: "process", label: "Our Process" },
                    { key: "testimonials", label: "Client Testimonials" },
                    { key: "faq", label: "Frequently Asked Questions (FAQ)" },
                    { key: "quote", label: "Get a Quote Form" },
                  ].map((sec) => {
                    const isVisible = (data.sectionVisibility as any)[sec.key];
                    return (
                      <label
                        key={sec.key}
                        className="flex cursor-pointer items-center justify-between rounded-lg border border-cream-line p-3 hover:bg-cream-soft"
                      >
                        <span className="text-xs font-semibold text-forest">{sec.label}</span>
                        <input
                          type="checkbox"
                          checked={isVisible}
                          onChange={(e) => {
                            const checked = e.target.checked;
                            updateData((prev) => ({
                              ...prev,
                              sectionVisibility: {
                                ...prev.sectionVisibility,
                                [sec.key]: checked,
                              },
                            }));
                          }}
                          className="h-4 w-4 rounded text-leaf focus:ring-leaf"
                        />
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB: LOGOS & SIZING (ONE-STOP LOGO MANAGEMENT FOR BOTH HEADER & FOOTER) */}
          {activeTab === "logos" && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-forest">
                  Logos Upload &amp; Size Controls
                </h2>
                <p className="mt-1 text-xs text-forest/70">
                  Full control to upload custom logo files or URLs for both Header and Footer, adjust rendered height with sliders, or switch between custom logos and the approved brand vector marks.
                </p>
              </div>

              <HeaderLogoSection
                data={data}
                updateData={updateData}
                showToast={showToast}
                handleLocalFileUpload={handleLocalFileUpload}
              />

              <FooterLogoSection
                data={data}
                updateData={updateData}
                showToast={showToast}
                handleLocalFileUpload={handleLocalFileUpload}
              />
            </div>
          )}

          {/* TAB: HEADER & NAVIGATION */}
          {activeTab === "header" && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-forest">
                  Header &amp; Navigation
                </h2>
                <p className="mt-1 text-xs text-forest/70">
                  Upload header logo image, adjust its size, customize brand text, navigation links, and quote button.
                </p>
              </div>

              {/* Header Logo Upload and Size */}
              <HeaderLogoSection
                data={data}
                updateData={updateData}
                showToast={showToast}
                handleLocalFileUpload={handleLocalFileUpload}
              />

              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <h3 className="font-display text-sm font-bold text-forest">
                  Brand Name &amp; Wordmark Text
                </h3>
                <div className="grid gap-3 sm:grid-cols-3">
                  <div>
                    <label className="block text-xs font-semibold text-forest">Brand Name</label>
                    <input
                      type="text"
                      value={data.header.brandName}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          header: { ...prev.header, brandName: val },
                        }));
                      }}
                      className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">Subtitle</label>
                    <input
                      type="text"
                      value={data.header.brandSubtitle}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          header: { ...prev.header, brandSubtitle: val },
                        }));
                      }}
                      className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">Tagline</label>
                    <input
                      type="text"
                      value={data.header.brandTagline}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          header: { ...prev.header, brandTagline: val },
                        }));
                      }}
                      className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">Header Button Text</label>
                    <input
                      type="text"
                      value={data.header.ctaText}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          header: { ...prev.header, ctaText: val },
                        }));
                      }}
                      className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">Header Button Link</label>
                    <input
                      type="text"
                      value={data.header.ctaHref}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          header: { ...prev.header, ctaHref: val },
                        }));
                      }}
                      className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                </div>
              </div>

              {/* Navigation Items Editor */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-sm font-bold text-forest">Navigation Menu Links</h3>
                  <button
                    type="button"
                    onClick={() => {
                      const newNav: NavItem = {
                        id: "nav-" + Date.now(),
                        label: "New Link",
                        href: "#",
                      };
                      updateData((prev) => ({
                        ...prev,
                        header: {
                          ...prev.header,
                          navItems: [...prev.header.navItems, newNav],
                        },
                      }));
                    }}
                    className="inline-flex items-center gap-1 rounded bg-leaf px-2.5 py-1 text-xs font-bold text-white hover:bg-leaf-dark"
                  >
                    <Plus className="h-3 w-3" /> Add Link
                  </button>
                </div>

                <div className="mt-4 space-y-2">
                  {data.header.navItems.map((item, idx) => (
                    <div key={item.id || idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={item.label}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            header: {
                              ...prev.header,
                              navItems: prev.header.navItems.map((n, i) =>
                                i === idx ? { ...n, label: val } : n,
                              ),
                            },
                          }));
                        }}
                        className="w-1/3 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="Label"
                      />
                      <input
                        type="text"
                        value={item.href}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            header: {
                              ...prev.header,
                              navItems: prev.header.navItems.map((n, i) =>
                                i === idx ? { ...n, href: val } : n,
                              ),
                            },
                          }));
                        }}
                        className="flex-1 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="Href (e.g. #services)"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          updateData((prev) => ({
                            ...prev,
                            header: {
                              ...prev.header,
                              navItems: prev.header.navItems.filter((_, i) => i !== idx),
                            },
                          }));
                        }}
                        className="grid h-8 w-8 place-items-center rounded text-red-600 hover:bg-red-50"
                        title="Delete link"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: HERO (IMAGE OR VIDEO) */}
          {activeTab === "hero" && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-forest">
                  Hero Section &amp; Media Background
                </h2>
                <p className="mt-1 text-xs text-forest/70">
                  Admin can configure text, buttons, and choose between a high-resolution tropical photo or a video background loop.
                </p>
              </div>

              {/* Media Type Switcher */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <div className="flex items-center gap-4">
                  <label className="text-xs font-bold uppercase tracking-wider text-forest">
                    Background Media Type:
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        updateData((prev) => ({
                          ...prev,
                          hero: { ...prev.hero, mediaType: "image" },
                        }));
                      }}
                      className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold ${
                        data.hero.mediaType === "image"
                          ? "bg-forest text-white"
                          : "border border-gray-300 bg-white text-forest/80"
                      }`}
                    >
                      <ImageIcon className="h-3.5 w-3.5" /> High-Res Image
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateData((prev) => ({
                          ...prev,
                          hero: { ...prev.hero, mediaType: "video" },
                        }));
                      }}
                      className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold ${
                        data.hero.mediaType === "video"
                          ? "bg-forest text-white"
                          : "border border-gray-300 bg-white text-forest/80"
                      }`}
                    >
                      <VideoIcon className="h-3.5 w-3.5" /> Tropical Video Loop
                    </button>
                  </div>
                </div>

                {data.hero.mediaType === "image" ? (
                  <div className="space-y-3">
                    <label className="block text-xs font-semibold text-forest">
                      Hero Image URL
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="url"
                        value={data.hero.imageUrl}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, imageUrl: val },
                          }));
                        }}
                        className="flex-1 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="https://images.pexels.com/..."
                      />
                      <button
                        type="button"
                        onClick={() => setShowPresetPickerFor({ target: "hero" })}
                        className="rounded-lg border border-leaf bg-leaf/10 px-3 py-2 text-xs font-semibold text-leaf-dark hover:bg-leaf/20"
                      >
                        Choose Preset
                      </button>
                    </div>

                    <div className="mt-2 flex items-center gap-3">
                      <span className="text-xs text-forest/60">Or upload local file:</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) =>
                          handleLocalFileUpload(e, (url) => {
                            updateData((prev) => ({
                              ...prev,
                              hero: { ...prev.hero, imageUrl: url },
                            }));
                          })
                        }
                        className="text-xs text-forest"
                      />
                    </div>

                    {data.hero.imageUrl ? (
                      <div className="relative mt-2 h-36 w-full overflow-hidden rounded-lg bg-black">
                        <img
                          src={data.hero.imageUrl}
                          alt="Hero Preview"
                          className="h-full w-full object-cover"
                        />
                      </div>
                    ) : null}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <label className="block text-xs font-semibold text-forest">
                      Hero Video URL (YouTube embed or direct MP4 link)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="url"
                        value={data.hero.videoUrl || ""}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, videoUrl: val },
                          }));
                        }}
                        className="flex-1 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="https://www.youtube.com/watch?v=... or direct .mp4 URL"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPresetPickerFor({ target: "hero" })}
                        className="rounded-lg border border-leaf bg-leaf/10 px-3 py-2 text-xs font-semibold text-leaf-dark hover:bg-leaf/20"
                      >
                        Preset Videos
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Text & Headline */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <h3 className="font-display text-sm font-bold text-forest">Headline &amp; Copy</h3>

                <div>
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-semibold text-forest">
                      Headline Lines (Stacked in master reference)
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        updateData((prev) => ({
                          ...prev,
                          hero: {
                            ...prev.hero,
                            headline: [...prev.hero.headline, "New Line"],
                          },
                        }));
                      }}
                      className="text-xs font-bold text-leaf hover:underline"
                    >
                      + Add Line
                    </button>
                  </div>
                  <div className="mt-2 space-y-2">
                    {data.hero.headline.map((line, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="text"
                          value={line}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              hero: {
                                ...prev.hero,
                                headline: prev.hero.headline.map((l, i) =>
                                  i === idx ? val : l,
                                ),
                              },
                            }));
                          }}
                          className="flex-1 rounded-lg border border-gray-300 p-2 text-xs text-forest font-display font-semibold"
                        />
                        {data.hero.headline.length > 1 ? (
                          <button
                            type="button"
                            onClick={() => {
                              updateData((prev) => ({
                                ...prev,
                                hero: {
                                  ...prev.hero,
                                  headline: prev.hero.headline.filter((_, i) => i !== idx),
                                },
                              }));
                            }}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        ) : null}
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-forest">Hero Description</label>
                  <textarea
                    rows={3}
                    value={data.hero.description}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        hero: { ...prev.hero, description: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                  />
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">
                      Primary Button (Text &amp; Link)
                    </label>
                    <div className="mt-1 flex gap-2">
                      <input
                        type="text"
                        value={data.hero.primaryCtaText}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, primaryCtaText: val },
                          }));
                        }}
                        className="w-1/2 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="Button text"
                      />
                      <input
                        type="text"
                        value={data.hero.primaryCtaHref}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, primaryCtaHref: val },
                          }));
                        }}
                        className="w-1/2 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="#contact"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-forest">
                      Secondary Button (Text &amp; Link)
                    </label>
                    <div className="mt-1 flex gap-2">
                      <input
                        type="text"
                        value={data.hero.secondaryCtaText}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, secondaryCtaText: val },
                          }));
                        }}
                        className="w-1/2 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="Button text"
                      />
                      <input
                        type="text"
                        value={data.hero.secondaryCtaHref}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, secondaryCtaHref: val },
                          }));
                        }}
                        className="w-1/2 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        placeholder="#services"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: SERVICES */}
          {activeTab === "services" && (
            <div className="max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-forest">
                    Our Services Cards
                  </h2>
                  <p className="mt-1 text-xs text-forest/70">
                    Add, edit, or delete services. Customize descriptions, photos, videos, and checklist bullet points.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newSvc: ServiceItem = {
                      id: "svc-" + Date.now(),
                      title: "New Service",
                      icon: "landscape",
                      blurb: "Brief description of the service for cards.",
                      description: "Detailed description explaining what is included.",
                      image:
                        "https://images.pexels.com/photos/28586235/pexels-photo-28586235.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=560",
                      alt: "Service photo",
                      includes: ["Consultation", "Planning", "Installation"],
                    };
                    updateData((prev) => ({
                      ...prev,
                      services: {
                        ...prev.services,
                        items: [...prev.services.items, newSvc],
                      },
                    }));
                    showToast("New service added!");
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-leaf px-3.5 py-1.5 text-xs font-bold text-white shadow hover:bg-leaf-dark"
                >
                  <Plus className="h-3.5 w-3.5" /> Add Service
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-forest">
                  Section Title
                </label>
                <input
                  type="text"
                  value={data.services.sectionTitle}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateData((prev) => ({
                      ...prev,
                      services: { ...prev.services, sectionTitle: val },
                    }));
                  }}
                  className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs font-display font-bold text-forest sm:w-80"
                />
              </div>

              <div className="space-y-4">
                {data.services.items.map((service, idx) => (
                  <div
                    key={service.id || idx}
                    className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4"
                  >
                    <div className="flex items-center justify-between border-b border-cream-line/70 pb-3">
                      <div className="flex items-center gap-2">
                        <span className="grid h-6 w-6 place-items-center rounded-full bg-leaf/20 text-xs font-bold text-forest">
                          {idx + 1}
                        </span>
                        <input
                          type="text"
                          value={service.title}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              services: {
                                ...prev.services,
                                items: prev.services.items.map((s, i) =>
                                  i === idx ? { ...s, title: val } : s,
                                ),
                              },
                            }));
                          }}
                          className="font-display text-base font-bold text-forest border-b border-transparent focus:border-leaf"
                          placeholder="Service Title"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm(`Delete service "${service.title}"?`)) {
                            updateData((prev) => ({
                              ...prev,
                              services: {
                                ...prev.services,
                                items: prev.services.items.filter((_, i) => i !== idx),
                              },
                            }));
                          }
                        }}
                        className="inline-flex items-center gap-1 rounded text-xs font-semibold text-red-600 hover:bg-red-50 p-1.5"
                      >
                        <Trash2 className="h-4 w-4" /> Delete
                      </button>
                    </div>

                    <div className="grid gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-semibold text-forest">Icon</label>
                        <select
                          value={service.icon}
                          onChange={(e) => {
                            const val = e.target.value as any;
                            updateData((prev) => ({
                              ...prev,
                              services: {
                                ...prev.services,
                                items: prev.services.items.map((s, i) =>
                                  i === idx ? { ...s, icon: val } : s,
                                ),
                              },
                            }));
                          }}
                          className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                        >
                          <option value="landscape">Landscape Leaf</option>
                          <option value="care">Garden Care Heart Leaf</option>
                          <option value="supply">Plant Supply Pot</option>
                          <option value="sprout">Sprout / Seedling</option>
                          <option value="tree">Pine / Palm Tree</option>
                          <option value="flower">Flower / Hibiscus</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-forest">
                          Image URL
                        </label>
                        <div className="mt-1 flex gap-1">
                          <input
                            type="url"
                            value={service.image}
                            onChange={(e) => {
                              const val = e.target.value;
                              updateData((prev) => ({
                                ...prev,
                                services: {
                                  ...prev.services,
                                  items: prev.services.items.map((s, i) =>
                                    i === idx ? { ...s, image: val } : s,
                                  ),
                                },
                              }));
                            }}
                            className="flex-1 rounded-lg border border-gray-300 p-2 text-xs text-forest"
                            placeholder="Image URL"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setShowPresetPickerFor({ target: "service", serviceId: service.id })
                            }
                            className="rounded bg-leaf/20 px-2 py-1 text-xs font-semibold text-leaf-dark"
                          >
                            Preset
                          </button>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-forest">Card Blurb (Short)</label>
                      <input
                        type="text"
                        value={service.blurb}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            services: {
                              ...prev.services,
                              items: prev.services.items.map((s, i) =>
                                i === idx ? { ...s, blurb: val } : s,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-forest">Full Description (Modal)</label>
                      <textarea
                        rows={2}
                        value={service.description}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            services: {
                              ...prev.services,
                              items: prev.services.items.map((s, i) =>
                                i === idx ? { ...s, description: val } : s,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-semibold text-forest">
                          Included Items (Checklist in modal)
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            updateData((prev) => ({
                              ...prev,
                              services: {
                                ...prev.services,
                                items: prev.services.items.map((s, i) =>
                                  i === idx ? { ...s, includes: [...s.includes, "New item"] } : s,
                                ),
                              },
                            }));
                          }}
                          className="text-xs font-bold text-leaf hover:underline"
                        >
                          + Add Bullet
                        </button>
                      </div>
                      <div className="mt-2 space-y-1.5">
                        {service.includes.map((inc, bulletIdx) => (
                          <div key={bulletIdx} className="flex items-center gap-2">
                            <input
                              type="text"
                              value={inc}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateData((prev) => ({
                                  ...prev,
                                  services: {
                                    ...prev.services,
                                    items: prev.services.items.map((s, i) =>
                                      i === idx
                                        ? {
                                            ...s,
                                            includes: s.includes.map((item, bI) =>
                                              bI === bulletIdx ? val : item,
                                            ),
                                          }
                                        : s,
                                    ),
                                  },
                                }));
                              }}
                              className="flex-1 rounded border border-gray-200 p-1.5 text-xs text-forest"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                updateData((prev) => ({
                                  ...prev,
                                  services: {
                                    ...prev.services,
                                    items: prev.services.items.map((s, i) =>
                                      i === idx
                                        ? {
                                            ...s,
                                            includes: s.includes.filter((_, bI) => bI !== bulletIdx),
                                          }
                                        : s,
                                    ),
                                  },
                                }));
                              }}
                              className="text-red-500 hover:text-red-700"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: WHY CHOOSE (BENEFITS) */}
          {activeTab === "whyChoose" && (
            <div className="max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-forest">
                    Why Choose Francesca&rsquo;s (Benefits)
                  </h2>
                  <p className="mt-1 text-xs text-forest/70">
                    Edit, delete, or add value propositions in the horizontal cream section.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newBenefit: BenefitItem = {
                      id: "ben-" + Date.now(),
                      title: "New Benefit",
                      description: "Short, punchy explanation.",
                      icon: "quality",
                    };
                    updateData((prev) => ({
                      ...prev,
                      whyChoose: {
                        ...prev.whyChoose,
                        items: [...prev.whyChoose.items, newBenefit],
                      },
                    }));
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-leaf px-3.5 py-1.5 text-xs font-bold text-white shadow hover:bg-leaf-dark"
                >
                  <Plus className="h-3.5 w-3.5" /> Add Benefit
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-forest">
                  Section Title
                </label>
                <input
                  type="text"
                  value={data.whyChoose.sectionTitle}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateData((prev) => ({
                      ...prev,
                      whyChoose: { ...prev.whyChoose, sectionTitle: val },
                    }));
                  }}
                  className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs font-display font-bold text-forest sm:w-80"
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {data.whyChoose.items.map((benefit, idx) => (
                  <div
                    key={benefit.id || idx}
                    className="rounded-xl border border-cream-line bg-white p-4 shadow-sm space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-forest/50">Benefit #{idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => {
                          updateData((prev) => ({
                            ...prev,
                            whyChoose: {
                              ...prev.whyChoose,
                              items: prev.whyChoose.items.filter((_, i) => i !== idx),
                            },
                          }));
                        }}
                        className="text-red-500 hover:text-red-700"
                        title="Delete benefit"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div>
                      <label className="block text-[0.7rem] font-semibold text-forest">Title</label>
                      <input
                        type="text"
                        value={benefit.title}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            whyChoose: {
                              ...prev.whyChoose,
                              items: prev.whyChoose.items.map((b, i) =>
                                i === idx ? { ...b, title: val } : b,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-1.5 text-xs font-display font-bold text-forest"
                      />
                    </div>

                    <div>
                      <label className="block text-[0.7rem] font-semibold text-forest">Description</label>
                      <textarea
                        rows={2}
                        value={benefit.description}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            whyChoose: {
                              ...prev.whyChoose,
                              items: prev.whyChoose.items.map((b, i) =>
                                i === idx ? { ...b, description: val } : b,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-1.5 text-xs text-forest"
                      />
                    </div>

                    <div>
                      <label className="block text-[0.7rem] font-semibold text-forest">Icon</label>
                      <select
                        value={benefit.icon}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          updateData((prev) => ({
                            ...prev,
                            whyChoose: {
                              ...prev.whyChoose,
                              items: prev.whyChoose.items.map((b, i) =>
                                i === idx ? { ...b, icon: val } : b,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-1.5 text-xs text-forest"
                      >
                        <option value="professional">Professional (Users)</option>
                        <option value="reliable">Reliable (Shield Check)</option>
                        <option value="tropical">Tropical Expertise (Leaf)</option>
                        <option value="tailored">Tailored Solutions (Sparkles)</option>
                        <option value="eco">Eco / Organic (Sprout)</option>
                        <option value="quality">Quality Guarantee (Award)</option>
                      </select>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: FEATURED PROJECTS & MULTIPLE IMAGES / VIDEOS */}
          {activeTab === "projects" && (
            <div className="max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-forest">
                    Featured Projects &amp; Media Gallery
                  </h2>
                  <p className="mt-1 text-xs text-forest/70">
                    <strong className="text-forest font-semibold">Critical:</strong> Support for multiple images per project and video walkthroughs as requested.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newProj: ProjectItem = {
                      id: "proj-" + Date.now(),
                      title: "New Garden Project",
                      category: "Landscape design · Palawan",
                      image:
                        "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
                      images: [
                        "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
                      ],
                      videoUrl: "",
                      alt: "Project photo",
                      description: "Description of plant species, stone materials, and landscape design.",
                      isPlaceholderPhoto: false,
                    };
                    updateData((prev) => ({
                      ...prev,
                      projects: {
                        ...prev.projects,
                        items: [newProj, ...prev.projects.items],
                      },
                    }));
                    showToast("New project added to gallery!");
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-leaf px-3.5 py-1.5 text-xs font-bold text-white shadow hover:bg-leaf-dark"
                >
                  <Plus className="h-3.5 w-3.5" /> Add Project
                </button>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-forest">
                    Section Title
                  </label>
                  <input
                    type="text"
                    value={data.projects.sectionTitle}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        projects: { ...prev.projects, sectionTitle: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs font-display font-bold text-forest"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-forest">
                    &quot;View All&quot; Button Text
                  </label>
                  <input
                    type="text"
                    value={data.projects.viewAllText}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        projects: { ...prev.projects, viewAllText: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                  />
                </div>
              </div>

              {/* Projects List */}
              <div className="space-y-6">
                {data.projects.items.map((project, idx) => {
                  const projectImages = project.images || [project.image];
                  return (
                    <div
                      key={project.id || idx}
                      className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4"
                    >
                      <div className="flex items-center justify-between border-b border-cream-line/70 pb-3">
                        <div className="flex items-center gap-2">
                          <span className="grid h-6 w-6 place-items-center rounded-full bg-leaf/20 text-xs font-bold text-forest">
                            {idx + 1}
                          </span>
                          <input
                            type="text"
                            value={project.title}
                            onChange={(e) => {
                              const val = e.target.value;
                              updateData((prev) => ({
                                ...prev,
                                projects: {
                                  ...prev.projects,
                                  items: prev.projects.items.map((p, i) =>
                                    i === idx ? { ...p, title: val } : p,
                                  ),
                                },
                              }));
                            }}
                            className="font-display text-base font-bold text-forest"
                            placeholder="Project Title"
                          />
                        </div>

                        <div className="flex items-center gap-3">
                          <label className="flex items-center gap-1.5 text-xs font-semibold text-forest/80 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={project.isPlaceholderPhoto}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                updateData((prev) => ({
                                  ...prev,
                                  projects: {
                                    ...prev.projects,
                                    items: prev.projects.items.map((p, i) =>
                                      i === idx ? { ...p, isPlaceholderPhoto: checked } : p,
                                    ),
                                  },
                                }));
                              }}
                              className="rounded text-leaf focus:ring-leaf"
                            />
                            <span>Placeholder Tag</span>
                          </label>

                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`Delete project "${project.title}"?`)) {
                                updateData((prev) => ({
                                  ...prev,
                                  projects: {
                                    ...prev.projects,
                                    items: prev.projects.items.filter((_, i) => i !== idx),
                                  },
                                }));
                              }
                            }}
                            className="text-red-500 hover:text-red-700 p-1"
                            title="Delete project"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>

                      <div className="grid gap-3 sm:grid-cols-2">
                        <div>
                          <label className="block text-xs font-semibold text-forest">Category / Subtitle</label>
                          <input
                            type="text"
                            value={project.category}
                            onChange={(e) => {
                              const val = e.target.value;
                              updateData((prev) => ({
                                ...prev,
                                projects: {
                                  ...prev.projects,
                                  items: prev.projects.items.map((p, i) =>
                                    i === idx ? { ...p, category: val } : p,
                                  ),
                                },
                              }));
                            }}
                            className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-forest">
                            Primary / Cover Image URL
                          </label>
                          <div className="mt-1 flex gap-1">
                            <input
                              type="url"
                              value={project.image}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateData((prev) => ({
                                  ...prev,
                                  projects: {
                                    ...prev.projects,
                                    items: prev.projects.items.map((p, i) =>
                                      i === idx
                                        ? {
                                            ...p,
                                            image: val,
                                            images: p.images ? [val, ...p.images.slice(1)] : [val],
                                          }
                                        : p,
                                    ),
                                  },
                                }));
                              }}
                              className="flex-1 rounded border border-gray-300 p-2 text-xs text-forest"
                              placeholder="Cover photo URL"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setShowPresetPickerFor({ target: "project", projectId: project.id })
                              }
                              className="rounded bg-leaf/20 px-2 py-1 text-xs font-semibold text-leaf-dark"
                            >
                              Preset
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Video Walkthrough URL */}
                      <div>
                        <label className="block text-xs font-semibold text-forest flex items-center gap-1.5">
                          <VideoIcon className="h-3.5 w-3.5 text-leaf" />
                          <span>Project Video URL (Optional — YouTube embed or direct MP4)</span>
                        </label>
                        <input
                          type="url"
                          value={project.videoUrl || ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              projects: {
                                ...prev.projects,
                                items: prev.projects.items.map((p, i) =>
                                  i === idx ? { ...p, videoUrl: val } : p,
                                ),
                              },
                            }));
                          }}
                          className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                          placeholder="e.g. https://www.youtube.com/watch?v=... or direct MP4"
                        />
                      </div>

                      {/* MULTIPLE IMAGES SECTION */}
                      <div className="rounded-lg border border-cream-line bg-cream-soft p-3.5">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold text-forest flex items-center gap-1.5">
                            <ImageIcon className="h-3.5 w-3.5 text-leaf" />
                            <span>Multiple Photos for this Project ({projectImages.length})</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => {
                              const newImg =
                                "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720";
                              updateData((prev) => ({
                                ...prev,
                                projects: {
                                  ...prev.projects,
                                  items: prev.projects.items.map((p, i) =>
                                    i === idx
                                      ? {
                                          ...p,
                                          images: [...(p.images || [p.image]), newImg],
                                        }
                                      : p,
                                  ),
                                },
                              }));
                            }}
                            className="text-xs font-bold text-leaf hover:underline"
                          >
                            + Add Another Photo
                          </button>
                        </div>

                        <div className="mt-3 space-y-2">
                          {projectImages.map((imgUrl, subIdx) => (
                            <div key={subIdx} className="flex items-center gap-2">
                              <span className="text-[0.7rem] font-semibold text-forest/60 w-5">
                                #{subIdx + 1}
                              </span>
                              <input
                                type="url"
                                value={imgUrl}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  updateData((prev) => ({
                                    ...prev,
                                    projects: {
                                      ...prev.projects,
                                      items: prev.projects.items.map((p, i) =>
                                        i === idx
                                          ? {
                                              ...p,
                                              images: (p.images || [p.image]).map((im, sI) =>
                                                sI === subIdx ? val : im,
                                              ),
                                              image: subIdx === 0 ? val : p.image,
                                            }
                                          : p,
                                      ),
                                    },
                                  }));
                                }}
                                className="flex-1 rounded border border-gray-300 p-1.5 text-xs text-forest"
                                placeholder="Image URL"
                              />
                              <img
                                src={imgUrl}
                                alt="Thumb"
                                className="h-7 w-10 rounded object-cover border"
                              />
                              {projectImages.length > 1 ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    updateData((prev) => ({
                                      ...prev,
                                      projects: {
                                        ...prev.projects,
                                        items: prev.projects.items.map((p, i) =>
                                          i === idx
                                            ? {
                                                ...p,
                                                images: (p.images || [p.image]).filter(
                                                  (_, sI) => sI !== subIdx,
                                                ),
                                              }
                                            : p,
                                        ),
                                      },
                                    }));
                                  }}
                                  className="text-red-500 hover:text-red-700"
                                >
                                  <X className="h-3.5 w-3.5" />
                                </button>
                              ) : null}
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-forest">
                          Project Description (Modal)
                        </label>
                        <textarea
                          rows={2}
                          value={project.description || ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              projects: {
                                ...prev.projects,
                                items: prev.projects.items.map((p, i) =>
                                  i === idx ? { ...p, description: val } : p,
                                ),
                              },
                            }));
                          }}
                          className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                          placeholder="Plant choices, paving materials, landscape features..."
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB: PROCESS STAGES */}
          {activeTab === "process" && (
            <div className="max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-forest">
                    Our Process (Connected Stages)
                  </h2>
                  <p className="mt-1 text-xs text-forest/70">
                    Edit the 4 workflow steps (Consult → Design → Build → Maintain) or add custom stages.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newProc: ProcessItem = {
                      id: "proc-" + Date.now(),
                      title: "New Stage",
                      description: "Brief stage description.",
                      icon: "check",
                    };
                    updateData((prev) => ({
                      ...prev,
                      process: {
                        ...prev.process,
                        items: [...prev.process.items, newProc],
                      },
                    }));
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-leaf px-3.5 py-1.5 text-xs font-bold text-white shadow hover:bg-leaf-dark"
                >
                  <Plus className="h-3.5 w-3.5" /> Add Step
                </button>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-forest">Section Title</label>
                  <input
                    type="text"
                    value={data.process.sectionTitle}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        process: { ...prev.process, sectionTitle: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs font-display font-bold text-forest"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-forest">Intro Text</label>
                  <input
                    type="text"
                    value={data.process.intro}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        process: { ...prev.process, intro: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {data.process.items.map((step, idx) => (
                  <div
                    key={step.id || idx}
                    className="rounded-xl border border-cream-line bg-white p-4 shadow-sm space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-forest/50">Stage #{idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => {
                          updateData((prev) => ({
                            ...prev,
                            process: {
                              ...prev.process,
                              items: prev.process.items.filter((_, i) => i !== idx),
                            },
                          }));
                        }}
                        className="text-red-500 hover:text-red-700"
                        title="Delete step"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div>
                      <label className="block text-[0.7rem] font-semibold text-forest">Title</label>
                      <input
                        type="text"
                        value={step.title}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            process: {
                              ...prev.process,
                              items: prev.process.items.map((s, i) =>
                                i === idx ? { ...s, title: val } : s,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-1.5 text-xs font-display font-bold text-forest"
                      />
                    </div>

                    <div>
                      <label className="block text-[0.7rem] font-semibold text-forest">Description</label>
                      <textarea
                        rows={2}
                        value={step.description}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            process: {
                              ...prev.process,
                              items: prev.process.items.map((s, i) =>
                                i === idx ? { ...s, description: val } : s,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-1.5 text-xs text-forest"
                      />
                    </div>

                    <div>
                      <label className="block text-[0.7rem] font-semibold text-forest">Icon</label>
                      <select
                        value={step.icon}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          updateData((prev) => ({
                            ...prev,
                            process: {
                              ...prev.process,
                              items: prev.process.items.map((s, i) =>
                                i === idx ? { ...s, icon: val } : s,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-1.5 text-xs text-forest"
                      >
                        <option value="consult">Consult (Chat Bubbles)</option>
                        <option value="design">Design (Pencil Leaf)</option>
                        <option value="build">Build (Layers Hardscape)</option>
                        <option value="maintain">Maintain (Sprouting Stem)</option>
                        <option value="leaf">Tropical Leaf</option>
                        <option value="check">Checkmark Completed</option>
                      </select>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: FREQUENTLY ASKED QUESTIONS (FAQ) */}
          {activeTab === "faq" && (
            <div className="max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-forest">
                    Frequently Asked Questions (FAQ)
                  </h2>
                  <p className="mt-1 text-xs text-forest/70">
                    Add, edit, or delete questions and answers for prospective Palawan clients.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newFaq: FaqItem = {
                      id: "faq-" + Date.now(),
                      question: "New Question Here?",
                      answer: "Detailed answer explaining your landscaping or garden process.",
                      category: "General",
                    };
                    updateData((prev) => ({
                      ...prev,
                      faq: { ...prev.faq, items: [...prev.faq.items, newFaq] },
                    }));
                    showToast("New FAQ question added!");
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-leaf px-3.5 py-1.5 text-xs font-bold text-white shadow hover:bg-leaf-dark"
                >
                  <Plus className="h-3.5 w-3.5" /> Add Question
                </button>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-forest">Section Title</label>
                  <input
                    type="text"
                    value={data.faq.sectionTitle}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        faq: { ...prev.faq, sectionTitle: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs font-display font-bold text-forest"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-forest">Section Subtitle</label>
                  <input
                    type="text"
                    value={data.faq.subtitle}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        faq: { ...prev.faq, subtitle: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                  />
                </div>
              </div>

              <div className="space-y-4">
                {data.faq.items.map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-3"
                  >
                    <div className="flex items-center justify-between border-b border-cream-line/70 pb-2.5">
                      <span className="text-xs font-bold text-forest/60">Q#{idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => {
                          updateData((prev) => ({
                            ...prev,
                            faq: {
                              ...prev.faq,
                              items: prev.faq.items.filter((_, i) => i !== idx),
                            },
                          }));
                        }}
                        className="text-red-500 hover:text-red-700"
                        title="Delete FAQ"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="grid gap-3 sm:grid-cols-[1fr_180px]">
                      <div>
                        <label className="block text-xs font-semibold text-forest">Question</label>
                        <input
                          type="text"
                          value={item.question}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              faq: {
                                ...prev.faq,
                                items: prev.faq.items.map((q, i) =>
                                  i === idx ? { ...q, question: val } : q,
                                ),
                              },
                            }));
                          }}
                          className="mt-1 w-full rounded border border-gray-300 p-2 text-xs font-semibold text-forest"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-forest">Category Tag</label>
                        <input
                          type="text"
                          value={item.category || ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              faq: {
                                ...prev.faq,
                                items: prev.faq.items.map((q, i) =>
                                  i === idx ? { ...q, category: val } : q,
                                ),
                              },
                            }));
                          }}
                          placeholder="e.g. Plant Selection"
                          className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-forest">Answer</label>
                      <textarea
                        rows={3}
                        value={item.answer}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            faq: {
                              ...prev.faq,
                              items: prev.faq.items.map((q, i) =>
                                i === idx ? { ...q, answer: val } : q,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-2 text-xs leading-relaxed text-forest"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: TESTIMONIALS */}
          {activeTab === "testimonials" && (
            <div className="max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-forest">
                    Client Testimonials
                  </h2>
                  <p className="mt-1 text-xs text-forest/70">
                    Add genuine customer reviews as they arrive. Toggle the placeholder tag whenever authentic feedback is added.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newTesti: TestimonialItem = {
                      id: "testi-" + Date.now(),
                      name: "Client Name",
                      role: "Homeowner, Palawan",
                      quote: "Francesca's Greens & Petals designed our dream tropical garden.",
                      rating: 5,
                      isPlaceholder: false,
                    };
                    updateData((prev) => ({
                      ...prev,
                      testimonials: {
                        ...prev.testimonials,
                        items: [...prev.testimonials.items, newTesti],
                      },
                    }));
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-leaf px-3.5 py-1.5 text-xs font-bold text-white shadow hover:bg-leaf-dark"
                >
                  <Plus className="h-3.5 w-3.5" /> Add Review
                </button>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-forest">Trust Heading</label>
                  <input
                    type="text"
                    value={data.testimonials.trustHeading}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        testimonials: { ...prev.testimonials, trustHeading: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs font-display font-bold text-forest"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-forest">Rating Note / Disclaimer</label>
                  <input
                    type="text"
                    value={data.testimonials.ratingNote}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        testimonials: { ...prev.testimonials, ratingNote: val },
                      }));
                    }}
                    className="mt-1 w-full rounded-lg border border-gray-300 p-2 text-xs text-forest"
                  />
                </div>
              </div>

              <div className="space-y-4">
                {data.testimonials.items.map((testi, idx) => (
                  <div
                    key={testi.id || idx}
                    className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-3"
                  >
                    <div className="flex items-center justify-between border-b border-cream-line/70 pb-2.5">
                      <span className="text-xs font-bold text-forest/60">Review #{idx + 1}</span>
                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-1.5 text-xs font-semibold text-forest/80 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={testi.isPlaceholder}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              updateData((prev) => ({
                                ...prev,
                                testimonials: {
                                  ...prev.testimonials,
                                  items: prev.testimonials.items.map((t, i) =>
                                    i === idx ? { ...t, isPlaceholder: checked } : t,
                                  ),
                                },
                              }));
                            }}
                            className="rounded text-leaf focus:ring-leaf"
                          />
                          <span>Placeholder Badge</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            updateData((prev) => ({
                              ...prev,
                              testimonials: {
                                ...prev.testimonials,
                                items: prev.testimonials.items.filter((_, i) => i !== idx),
                              },
                            }));
                          }}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid gap-3 sm:grid-cols-3">
                      <div>
                        <label className="block text-xs font-semibold text-forest">Client Name</label>
                        <input
                          type="text"
                          value={testi.name}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              testimonials: {
                                ...prev.testimonials,
                                items: prev.testimonials.items.map((t, i) =>
                                  i === idx ? { ...t, name: val } : t,
                                ),
                              },
                            }));
                          }}
                          className="mt-1 w-full rounded border border-gray-300 p-2 text-xs font-semibold text-forest"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-forest">Role / Location</label>
                        <input
                          type="text"
                          value={testi.role}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              testimonials: {
                                ...prev.testimonials,
                                items: prev.testimonials.items.map((t, i) =>
                                  i === idx ? { ...t, role: val } : t,
                                ),
                              },
                            }));
                          }}
                          className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-forest">Star Rating (1-5)</label>
                        <select
                          value={testi.rating}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            updateData((prev) => ({
                              ...prev,
                              testimonials: {
                                ...prev.testimonials,
                                items: prev.testimonials.items.map((t, i) =>
                                  i === idx ? { ...t, rating: val } : t,
                                ),
                              },
                            }));
                          }}
                          className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                        >
                          <option value={5}>5 Stars (★★★★★)</option>
                          <option value={4}>4 Stars (★★★★)</option>
                          <option value={3}>3 Stars (★★★)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-forest">Testimonial Quote</label>
                      <textarea
                        rows={3}
                        value={testi.quote}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            testimonials: {
                              ...prev.testimonials,
                              items: prev.testimonials.items.map((t, i) =>
                                i === idx ? { ...t, quote: val } : t,
                              ),
                            },
                          }));
                        }}
                        className="mt-1 w-full rounded border border-gray-300 p-2 text-xs leading-relaxed text-forest"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: QUOTE FORM BUILDER */}
          {activeTab === "form" && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-forest">
                  Proper Full Out Quote Form Builder
                </h2>
                <p className="mt-1 text-xs text-forest/70">
                  Configure form fields, WhatsApp destination number, dropdown service options, and submission endpoint.
                </p>
              </div>

              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">Form Title</label>
                    <input
                      type="text"
                      value={data.quoteForm.title}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          quoteForm: { ...prev.quoteForm, title: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs font-display font-bold text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">Form Subtitle</label>
                    <input
                      type="text"
                      value={data.quoteForm.subtitle}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          quoteForm: { ...prev.quoteForm, subtitle: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">Submit Button Text</label>
                    <input
                      type="text"
                      value={data.quoteForm.submitButtonText}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          quoteForm: { ...prev.quoteForm, submitButtonText: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">WhatsApp Button Text</label>
                    <input
                      type="text"
                      value={data.quoteForm.whatsappButtonText}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          quoteForm: { ...prev.quoteForm, whatsappButtonText: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">
                      WhatsApp Phone Number (Digits only, e.g. 639171234567)
                    </label>
                    <input
                      type="text"
                      value={data.quoteForm.whatsappNumber}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          quoteForm: { ...prev.quoteForm, whatsappNumber: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                      placeholder="639171234567"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-forest">
                      Submission Webhook / API Endpoint (Optional)
                    </label>
                    <input
                      type="url"
                      value={data.quoteForm.submissionEndpoint}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          quoteForm: { ...prev.quoteForm, submissionEndpoint: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                      placeholder="https://formspree.io/f/... or Zapier Webhook"
                    />
                  </div>
                </div>

                {/* Additional Field Toggles */}
                <div className="pt-2">
                  <p className="text-xs font-bold text-forest mb-2">Extended Form Fields:</p>
                  <div className="flex flex-wrap gap-4">
                    <label className="flex items-center gap-2 text-xs font-semibold text-forest cursor-pointer">
                      <input
                        type="checkbox"
                        checked={data.quoteForm.showLocationField}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          updateData((prev) => ({
                            ...prev,
                            quoteForm: { ...prev.quoteForm, showLocationField: checked },
                          }));
                        }}
                        className="rounded text-leaf focus:ring-leaf"
                      />
                      <span>Show Property Location Field</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-forest cursor-pointer">
                      <input
                        type="checkbox"
                        checked={data.quoteForm.showBudgetField}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          updateData((prev) => ({
                            ...prev,
                            quoteForm: { ...prev.quoteForm, showBudgetField: checked },
                          }));
                        }}
                        className="rounded text-leaf focus:ring-leaf"
                      />
                      <span>Show Project Scope / Budget Field</span>
                    </label>
                  </div>
                </div>

                {/* Service Options List */}
                <div className="border-t border-cream-line/70 pt-4">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-forest">
                      &quot;Service Needed&quot; Dropdown Options
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        updateData((prev) => ({
                          ...prev,
                          quoteForm: {
                            ...prev.quoteForm,
                            serviceOptions: [
                              ...prev.quoteForm.serviceOptions,
                              "New Service Option",
                            ],
                          },
                        }));
                      }}
                      className="text-xs font-bold text-leaf hover:underline"
                    >
                      + Add Option
                    </button>
                  </div>

                  <div className="mt-2 space-y-2">
                    {data.quoteForm.serviceOptions.map((opt, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="text"
                          value={opt}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateData((prev) => ({
                              ...prev,
                              quoteForm: {
                                ...prev.quoteForm,
                                serviceOptions: prev.quoteForm.serviceOptions.map((o, i) =>
                                  i === idx ? val : o,
                                ),
                              },
                            }));
                          }}
                          className="flex-1 rounded border border-gray-300 p-1.5 text-xs text-forest"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            updateData((prev) => ({
                              ...prev,
                              quoteForm: {
                                ...prev.quoteForm,
                                serviceOptions: prev.quoteForm.serviceOptions.filter(
                                  (_, i) => i !== idx,
                                ),
                              },
                            }));
                          }}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: INQUIRIES SUBMISSIONS INBOX */}
          {activeTab === "inbox" && (
            <div className="max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-forest flex items-center gap-2">
                    <Inbox className="h-5 w-5 text-leaf" />
                    <span>Inquiry Submissions Inbox</span>
                  </h2>
                  <p className="mt-1 text-xs text-forest/70">
                    All quote inquiries submitted on the website are captured here in real time.
                  </p>
                </div>
                {submissions.length > 0 ? (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm("Clear all captured inquiries from browser inbox?")) {
                        clearSubmissions();
                        showToast("Inbox cleared.");
                      }
                    }}
                    className="text-xs font-semibold text-red-600 hover:underline"
                  >
                    Clear All Inquiries
                  </button>
                ) : null}
              </div>

              {submissions.length === 0 ? (
                <div className="rounded-xl border border-cream-line bg-white p-10 text-center">
                  <Inbox className="mx-auto h-10 w-10 text-forest/30" />
                  <p className="mt-3 font-display text-sm font-bold text-forest">
                    No submissions yet
                  </p>
                  <p className="mt-1 text-xs text-forest/60">
                    Test submitting a quote request in the &quot;Get a Quote&quot; section to see incoming inquiries here.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {submissions.map((sub) => (
                    <div
                      key={sub.id}
                      className={`rounded-xl border p-4 shadow-sm transition ${
                        sub.read
                          ? "border-cream-line bg-white"
                          : "border-leaf/50 bg-[#F4F9EC] ring-1 ring-leaf/30"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-display text-sm font-bold text-forest">
                              {sub.name}
                            </h3>
                            {!sub.read ? (
                              <span className="rounded bg-leaf px-2 py-0.5 text-[0.62rem] font-bold uppercase text-white">
                                New
                              </span>
                            ) : null}
                            <span className="rounded bg-cream px-2 py-0.5 text-[0.68rem] font-semibold text-forest/70">
                              {sub.service}
                            </span>
                          </div>
                          <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-forest/70">
                            <a
                              href={`mailto:${sub.email}`}
                              className="font-medium text-forest hover:text-leaf-dark underline"
                            >
                              {sub.email}
                            </a>
                            {sub.phone ? <span>• Phone: {sub.phone}</span> : null}
                            {sub.location ? <span>• Location: {sub.location}</span> : null}
                            {sub.budget ? <span>• Scope: {sub.budget}</span> : null}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-[0.68rem] text-forest/50">
                            {new Date(sub.timestamp).toLocaleDateString()}
                          </span>
                          {!sub.read ? (
                            <button
                              type="button"
                              onClick={() => markSubmissionRead(sub.id)}
                              className="rounded bg-white border border-gray-200 px-2 py-1 text-[0.68rem] font-semibold text-forest hover:bg-gray-50"
                            >
                              Mark Read
                            </button>
                          ) : null}
                          <button
                            type="button"
                            onClick={() => deleteSubmission(sub.id)}
                            className="text-red-500 hover:text-red-700 p-1"
                            title="Delete"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="mt-3 rounded-lg bg-white/70 border border-cream-line/60 p-2.5 text-xs text-forest/90 leading-relaxed whitespace-pre-wrap">
                        {sub.message}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB: FOOTER & LUCIDE SOCIAL MEDIA ICONS */}
          {activeTab === "footer" && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-forest">
                  Footer &amp; Social Media Links
                </h2>
                <p className="mt-1 text-xs text-forest/70">
                  Upload footer logo, adjust its rendered height, and configure Lucide social media account URLs.
                </p>
              </div>

              {/* Footer Logo Upload and Size */}
              <FooterLogoSection
                data={data}
                updateData={updateData}
                showToast={showToast}
                handleLocalFileUpload={handleLocalFileUpload}
              />

              {/* Social Media Links Manager */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-sm font-bold text-forest flex items-center gap-2">
                    <Share2 className="h-4 w-4 text-leaf" />
                    <span>Lucide Social Media Accounts</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      const newSoc: SocialLinkItem = {
                        id: "soc-" + Date.now(),
                        platform: "Instagram",
                        label: "Instagram",
                        url: "https://instagram.com",
                        icon: "instagram",
                        enabled: true,
                      };
                      updateData((prev) => ({
                        ...prev,
                        footer: {
                          ...prev.footer,
                          socialLinks: [...prev.footer.socialLinks, newSoc],
                        },
                      }));
                    }}
                    className="inline-flex items-center gap-1 rounded bg-leaf px-2.5 py-1 text-xs font-bold text-white hover:bg-leaf-dark"
                  >
                    <Plus className="h-3 w-3" /> Add Social Account
                  </button>
                </div>

                <div className="space-y-3">
                  {data.footer.socialLinks.map((social, idx) => (
                    <div
                      key={social.id || idx}
                      className="flex flex-col gap-2 rounded-lg border border-cream-line p-3 sm:flex-row sm:items-center"
                    >
                      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-forest text-white">
                        <LucideSocialIcon name={social.icon} size={18} />
                      </div>

                      <div className="w-32 shrink-0">
                        <select
                          value={social.icon}
                          onChange={(e) => {
                            const val = e.target.value;
                            const match = AVAILABLE_SOCIAL_ICONS.find((a) => a.id === val);
                            updateData((prev) => ({
                              ...prev,
                              footer: {
                                ...prev.footer,
                                socialLinks: prev.footer.socialLinks.map((s, i) =>
                                  i === idx
                                    ? {
                                        ...s,
                                        icon: val,
                                        platform: match ? match.label : val,
                                        label: match ? match.label : val,
                                      }
                                    : s,
                                ),
                              },
                            }));
                          }}
                          className="w-full rounded border border-gray-300 p-1.5 text-xs text-forest"
                        >
                          {AVAILABLE_SOCIAL_ICONS.map((opt) => (
                            <option key={opt.id} value={opt.id}>
                              {opt.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      <input
                        type="url"
                        value={social.url}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateData((prev) => ({
                            ...prev,
                            footer: {
                              ...prev.footer,
                              socialLinks: prev.footer.socialLinks.map((s, i) =>
                                i === idx ? { ...s, url: val } : s,
                              ),
                            },
                          }));
                        }}
                        className="flex-1 rounded border border-gray-300 p-1.5 text-xs text-forest"
                        placeholder="https://..."
                      />

                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-1.5 text-xs font-semibold text-forest cursor-pointer">
                          <input
                            type="checkbox"
                            checked={social.enabled}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              updateData((prev) => ({
                                ...prev,
                                footer: {
                                  ...prev.footer,
                                  socialLinks: prev.footer.socialLinks.map((s, i) =>
                                    i === idx ? { ...s, enabled: checked } : s,
                                  ),
                                },
                              }));
                            }}
                            className="rounded text-leaf focus:ring-leaf"
                          />
                          <span>Visible</span>
                        </label>

                        <button
                          type="button"
                          onClick={() => {
                            updateData((prev) => ({
                              ...prev,
                              footer: {
                                ...prev.footer,
                                socialLinks: prev.footer.socialLinks.filter((_, i) => i !== idx),
                              },
                            }));
                          }}
                          className="text-red-500 hover:text-red-700"
                          title="Delete link"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contact Information in Footer */}
              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <h3 className="font-display text-sm font-bold text-forest">
                  Business Contact Details
                </h3>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">Phone Label</label>
                    <input
                      type="text"
                      value={data.footer.phoneLabel}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, phoneLabel: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">Phone Call Link</label>
                    <input
                      type="text"
                      value={data.footer.phoneHref}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, phoneHref: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">Email Label</label>
                    <input
                      type="text"
                      value={data.footer.emailLabel}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, emailLabel: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">Email Mailto Link</label>
                    <input
                      type="text"
                      value={data.footer.emailHref}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, emailHref: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-forest">Location Text</label>
                    <input
                      type="text"
                      value={data.footer.location}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, location: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-forest">Studio Hours</label>
                    <input
                      type="text"
                      value={data.footer.hours}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateData((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, hours: val },
                        }));
                      }}
                      className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-forest">Copyright Text</label>
                  <input
                    type="text"
                    value={data.footer.copyright}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateData((prev) => ({
                        ...prev,
                        footer: { ...prev.footer, copyright: val },
                      }));
                    }}
                    className="mt-1 w-full rounded border border-gray-300 p-2 text-xs text-forest"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB: BACKUP & EXPORT/IMPORT JSON */}
          {activeTab === "backup" && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-forest">
                  Site Data Backup, Export &amp; Restore
                </h2>
                <p className="mt-1 text-xs text-forest/70">
                  Export the entire site configuration as JSON to save or share, or paste a backup to restore it.
                </p>
              </div>

              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-sm font-bold text-forest">Export Configuration</h3>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(exportJson());
                      showToast("JSON copied to clipboard!");
                    }}
                    className="inline-flex items-center gap-1.5 rounded bg-leaf px-3 py-1.5 text-xs font-bold text-white hover:bg-leaf-dark"
                  >
                    <Copy className="h-3.5 w-3.5" /> Copy JSON to Clipboard
                  </button>
                </div>
                <textarea
                  readOnly
                  rows={8}
                  value={exportJson()}
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 font-mono text-[0.72rem] text-forest"
                />
              </div>

              <div className="rounded-xl border border-cream-line bg-white p-5 shadow-sm space-y-4">
                <h3 className="font-display text-sm font-bold text-forest">Import Configuration</h3>
                <p className="text-xs text-forest/70">
                  Paste valid site JSON here to import all settings at once.
                </p>
                <textarea
                  rows={4}
                  placeholder="Paste JSON here..."
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 p-2.5 font-mono text-[0.72rem] text-forest"
                />
                <button
                  type="button"
                  disabled={!importText.trim()}
                  onClick={() => {
                    const ok = importJson(importText);
                    if (ok) {
                      showToast("Site configuration imported successfully!");
                      setImportText("");
                    } else {
                      alert("Invalid JSON format. Please verify the copied structure.");
                    }
                  }}
                  className="inline-flex items-center gap-1.5 rounded bg-forest px-4 py-2 text-xs font-bold text-white hover:bg-forest-deep disabled:opacity-50"
                >
                  <Upload className="h-3.5 w-3.5" /> Apply Imported JSON
                </button>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Preset Stock Asset Picker Modal */}
      {showPresetPickerFor ? (
        <div className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="font-display text-base font-bold text-forest">
                  Choose Tropical Media Asset
                </h3>
                <p className="text-xs text-forest/70">
                  Click any tropical image or video to instantly use it.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowPresetPickerFor(null)}
                className="grid h-8 w-8 place-items-center rounded-full text-gray-500 hover:bg-gray-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 max-h-96 overflow-y-auto space-y-4">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-forest/70 mb-2">
                  Tropical Garden Photos
                </h4>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {PRESET_TROPICAL_IMAGES.map((preset, pIdx) => (
                    <button
                      key={pIdx}
                      type="button"
                      onClick={() => {
                        const target = showPresetPickerFor.target;
                        if (target === "hero") {
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, imageUrl: preset.url },
                          }));
                        } else if (target === "service" && showPresetPickerFor.serviceId) {
                          updateData((prev) => ({
                            ...prev,
                            services: {
                              ...prev.services,
                              items: prev.services.items.map((s) =>
                                s.id === showPresetPickerFor.serviceId
                                  ? { ...s, image: preset.url }
                                  : s,
                              ),
                            },
                          }));
                        } else if (target === "project" && showPresetPickerFor.projectId) {
                          updateData((prev) => ({
                            ...prev,
                            projects: {
                              ...prev.projects,
                              items: prev.projects.items.map((p) =>
                                p.id === showPresetPickerFor.projectId
                                  ? {
                                      ...p,
                                      image: preset.url,
                                      images: p.images ? [preset.url, ...p.images.slice(1)] : [preset.url],
                                    }
                                  : p,
                              ),
                            },
                          }));
                        }
                        setShowPresetPickerFor(null);
                        showToast(`Selected "${preset.title}"`);
                      }}
                      className="group overflow-hidden rounded-lg border border-gray-200 text-left transition hover:border-leaf"
                    >
                      <img
                        src={preset.thumbnail}
                        alt={preset.title}
                        className="h-20 w-full object-cover transition group-hover:scale-105"
                      />
                      <div className="p-2">
                        <p className="truncate text-[0.7rem] font-bold text-forest">
                          {preset.title}
                        </p>
                        <p className="text-[0.62rem] text-forest/60">{preset.category}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-forest/70 mb-2">
                  Sample Video Loops
                </h4>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-2">
                  {PRESET_TROPICAL_VIDEOS.map((preset, vIdx) => (
                    <button
                      key={vIdx}
                      type="button"
                      onClick={() => {
                        if (showPresetPickerFor.target === "hero") {
                          updateData((prev) => ({
                            ...prev,
                            hero: { ...prev.hero, videoUrl: preset.url, mediaType: "video" },
                          }));
                        }
                        setShowPresetPickerFor(null);
                        showToast(`Video set: "${preset.title}"`);
                      }}
                      className="group overflow-hidden rounded-lg border border-gray-200 text-left transition hover:border-leaf"
                    >
                      <div className="relative h-20 w-full overflow-hidden bg-black">
                        <img
                          src={preset.thumbnail}
                          alt={preset.title}
                          className="h-full w-full object-cover opacity-80"
                        />
                        <span className="absolute inset-0 grid place-items-center">
                          <Play className="h-6 w-6 text-white drop-shadow" />
                        </span>
                      </div>
                      <div className="p-2">
                        <p className="truncate text-[0.7rem] font-bold text-forest">
                          {preset.title}
                        </p>
                        <p className="text-[0.62rem] text-forest/60">Video Asset</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* Floating Toast Notification */}
      {toastMessage ? (
        <div className="fixed bottom-5 right-5 z-[300] flex items-center gap-2 rounded-xl bg-forest px-4 py-3 text-xs font-semibold text-white shadow-xl ring-1 ring-white/20">
          <Check className="h-4 w-4 text-leaf" strokeWidth={2.4} />
          <span>{toastMessage}</span>
        </div>
      ) : null}
    </div>
  );
}
