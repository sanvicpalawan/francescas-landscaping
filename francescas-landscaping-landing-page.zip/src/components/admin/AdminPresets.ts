/**
 * PRESET STOCK MEDIA ASSETS FOR QUICK 1-CLICK CMS SELECTION
 * Tropical garden landscapes, nursery plants, stone pathways, resort pergolas,
 * and high-definition video loops for Francesca's Greens & Petals.
 */

export interface PresetMedia {
  title: string;
  category: string;
  url: string;
  type: "image" | "video";
  thumbnail: string;
}

export const PRESET_TROPICAL_IMAGES: PresetMedia[] = [
  {
    title: "Master Landscaped Garden & Exotic Flowers",
    category: "Master Design Hero",
    url: "/images/hero-tropical-landscaping.jpg",
    thumbnail: "/images/hero-tropical-landscaping.jpg",
    type: "image",
  },
  {
    title: "Stone Stairway & Exotic Palms",
    category: "Garden Entry",
    url: "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Tropical Villa Stone Facade",
    category: "Landscape Design",
    url: "https://images.pexels.com/photos/28586235/pexels-photo-28586235.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/28586235/pexels-photo-28586235.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Staircase to Tropical Countryside Villa",
    category: "Landscape Architecture",
    url: "https://images.pexels.com/photos/6129981/pexels-photo-6129981.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/6129981/pexels-photo-6129981.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Stone Path Lined with Palms",
    category: "Garden Pathways",
    url: "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Modern Resort Patio & Pool Terrace",
    category: "Outdoor Living",
    url: "https://images.pexels.com/photos/5563471/pexels-photo-5563471.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/5563471/pexels-photo-5563471.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Vibrant Pink Hibiscus Bloom",
    category: "Tropical Flowers",
    url: "https://images.pexels.com/photos/37108159/pexels-photo-37108159.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/37108159/pexels-photo-37108159.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Nursery Potted Tropical Plants",
    category: "Plant Supply",
    url: "https://images.pexels.com/photos/39823780/pexels-photo-39823780.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/39823780/pexels-photo-39823780.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Luxurious Resort Terrace Seating",
    category: "Hospitality Grounds",
    url: "https://images.pexels.com/photos/35171519/pexels-photo-35171519.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/35171519/pexels-photo-35171519.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
  {
    title: "Palawan Tropical Forest River Walk",
    category: "Flora & Palms",
    url: "https://images.pexels.com/photos/6416202/pexels-photo-6416202.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280",
    thumbnail:
      "https://images.pexels.com/photos/6416202/pexels-photo-6416202.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "image",
  },
];

export const PRESET_TROPICAL_VIDEOS: PresetMedia[] = [
  {
    title: "Lush Tropical Garden Walkthrough (Sample Video)",
    category: "Garden Video",
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ", // Embeddable sample or direct MP4
    thumbnail:
      "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "video",
  },
  {
    title: "Palawan Tropical Nature & Palms (Landscape Loop)",
    category: "Resort Video",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    thumbnail:
      "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=160",
    type: "video",
  },
];
