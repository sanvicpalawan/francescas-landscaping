import type { ReactNode, SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

function Svg({ children, ...props }: IconProps & { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...props}
    >
      {children}
    </svg>
  );
}

export function LeafIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M20.5 3.5C11 3 4.5 7.5 4.5 14a5.5 5.5 0 0 0 5.5 5.5c6.5 0 10.5-6.5 10.5-16Z" />
      <path d="M3 21c1.7-5.6 5.4-9.5 11-12" />
    </Svg>
  );
}

export function CareLeafIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M12 21c-4.4-3.1-7-7-7-10.5A6.5 6.5 0 0 1 12 4a6.5 6.5 0 0 1 7 6.5c0 3.5-2.6 7.4-7 10.5Z" />
      <path d="M12 20V7" />
      <path d="M12 12.5 8.6 9.4" />
      <path d="M12 16l3.4-3.1" />
    </Svg>
  );
}

export function PotPlantIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M12 12.5V8" />
      <path d="M12 8c0-3 1.8-4.8 4.6-5.2C16.4 5.8 14.7 7.6 12 8Z" />
      <path d="M12 9.4c-2.6-.2-4.2-1.8-4.4-4.4C10.2 5.3 11.7 6.9 12 9.4Z" />
      <path d="M5.5 12.5h13l-1.1 7a2 2 0 0 1-2 1.7H8.6a2 2 0 0 1-2-1.7l-1.1-7Z" />
      <path d="M7 15.5h10" />
    </Svg>
  );
}

export function UsersIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <circle cx="9" cy="8" r="3.1" />
      <path d="M3 19.5c0-3.2 2.7-5.4 6-5.4s6 2.2 6 5.4" />
      <path d="M16 5.2a3 3 0 0 1 0 5.8" />
      <path d="M17.6 14.6c2.1.5 3.4 2.1 3.4 4.4" />
    </Svg>
  );
}

export function ShieldCheckIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M12 3 5 5.8v5.4c0 4.2 2.9 7.7 7 9.3 4.1-1.6 7-5.1 7-9.3V5.8L12 3Z" />
      <path d="m8.8 11.6 2.2 2.2 4.2-4.4" />
    </Svg>
  );
}

export function SparklesIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M12 3.5c.6 3.6 2.1 5.1 5.7 5.7-3.6.6-5.1 2.1-5.7 5.7-.6-3.6-2.1-5.1-5.7-5.7 3.6-.6 5.1-2.1 5.7-5.7Z" />
      <path d="M18 15.2c.3 1.9 1.1 2.7 3 3-1.9.3-2.7 1.1-3 3-.3-1.9-1.1-2.7-3-3 1.9-.3 2.7-1.1 3-3Z" />
      <path d="M5.6 14.7c.25 1.5.9 2.15 2.4 2.4-1.5.25-2.15.9-2.4 2.4-.25-1.5-.9-2.15-2.4-2.4 1.5-.25 2.15-.9 2.4-2.4Z" />
    </Svg>
  );
}

export function ChatIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M20.5 11.4c0 4.1-3.8 7.4-8.5 7.4-1 0-2-.15-2.9-.42L4.5 20l1.3-3.6A6.9 6.9 0 0 1 3.5 11.4C3.5 7.3 7.3 4 12 4s8.5 3.3 8.5 7.4Z" />
      <path d="M8.4 11.4h.01M12 11.4h.01M15.6 11.4h.01" strokeWidth={2.1} />
    </Svg>
  );
}

export function PencilLeafIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M12.2 19.2 4.5 20l.8-7.7L16 4.6a2.4 2.4 0 0 1 3.4 3.4L8.8 18.6 4.5 20" />
      <path d="m14.2 6.5 3.4 3.4" />
    </Svg>
  );
}

export function LayersIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="m3 12.4 9-4.4 9 4.4-9 4.4-9-4.4Z" />
      <path d="m3 16.4 9 4.3 9-4.3" />
      <path d="m3 8.4 9-4.3 9 4.3" />
    </Svg>
  );
}

export function CareGrowIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M12 21.5V13" />
      <path d="M12 16.5c-4 0-6.5-2.6-6.5-6.5 3.9 0 6.5 2.5 6.5 6.5Z" />
      <path d="M12 13c.6-3.7 3-6 6.8-6 0 3.8-2.5 6-6.8 6Z" />
      <path d="M8 21.5h8" />
    </Svg>
  );
}

export function ArrowRightIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M4 12h15" />
      <path d="m13.5 6.5 6 5.5-6 5.5" />
    </Svg>
  );
}

export function ChevronLeftIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="m14.5 5.5-6.5 6.5 6.5 6.5" />
    </Svg>
  );
}

export function ChevronRightIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="m9.5 5.5 6.5 6.5-6.5 6.5" />
    </Svg>
  );
}

export function ChevronDownIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="m6 9.5 6 6 6-6" />
    </Svg>
  );
}

export function CheckIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="m4.5 12.5 5 5 10-11" />
    </Svg>
  );
}

export function StarIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" {...props}>
      <path d="M12 2.6l2.9 5.9 6.5.95-4.7 4.6 1.1 6.45L12 17.45 6.2 20.5l1.1-6.45L2.6 9.45l6.5-.95L12 2.6Z" />
    </svg>
  );
}

export function QuoteIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 32 24" fill="currentColor" aria-hidden="true" focusable="false" {...props}>
      <path d="M0 24V13.2C0 5.9 3.9 1.2 10.6 0l1.1 3.3C7.5 4.5 5.4 6.7 5.2 9.4h5.2V24H0Z" />
      <path d="M20.2 24V13.2C20.2 5.9 24.1 1.2 30.8 0l1.1 3.3c-4.2 1.2-6.3 3.4-6.5 6.1H30.6V24H20.2Z" />
    </svg>
  );
}

export function CloseIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="m6 6 12 12M18 6 6 18" />
    </Svg>
  );
}

export function MenuIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M4 7h16M4 12h16M4 17h16" />
    </Svg>
  );
}

export function WhatsAppIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" {...props}>
      <path d="M12.04 2C6.6 2 2.2 6.4 2.2 11.84c0 1.74.46 3.44 1.32 4.94L2 22l5.36-1.4a9.9 9.9 0 0 0 4.68 1.2h.01c5.43 0 9.84-4.4 9.84-9.84A9.78 9.78 0 0 0 19 4.88 9.78 9.78 0 0 0 12.04 2Zm0 17.9h-.01a8.2 8.2 0 0 1-4.18-1.14l-.3-.18-3.1.81.83-3.03-.2-.31a8.17 8.17 0 0 1-1.26-4.35c0-4.52 3.69-8.2 8.22-8.2a8.15 8.15 0 0 1 5.8 2.4 8.15 8.15 0 0 1 2.4 5.8c0 4.53-3.68 8.2-8.2 8.2Zm4.52-6.14c-.25-.12-1.47-.72-1.7-.8-.22-.09-.39-.13-.55.12-.16.25-.63.8-.77.96-.14.16-.28.18-.53.06a6.66 6.66 0 0 1-1.96-1.21 7.4 7.4 0 0 1-1.36-1.7c-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.43.12-.14.16-.25.25-.41.08-.17.04-.31-.03-.43-.06-.12-.55-1.34-.76-1.83-.2-.48-.4-.42-.55-.43h-.47c-.16 0-.43.06-.65.31-.23.25-.86.84-.86 2.05s.88 2.38 1 2.54c.12.17 1.73 2.64 4.19 3.7.59.25 1.04.4 1.4.52.59.18 1.12.16 1.54.1.47-.07 1.47-.6 1.67-1.18.2-.58.2-1.08.15-1.18-.06-.1-.23-.17-.48-.29Z" />
    </svg>
  );
}

export function PhoneIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M7 3.5H4.8c-.8 0-1.4.7-1.3 1.5.6 7.8 6.7 13.9 14.5 14.5.8.1 1.5-.5 1.5-1.3V16l-4-1.5-1.7 1.7a14.3 14.3 0 0 1-5-5L10.5 9.5 7 3.5Z" />
    </Svg>
  );
}

export function MailIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <rect x="3" y="5.5" width="18" height="13" rx="2.4" />
      <path d="m3.8 6.8 8.2 6.3 8.2-6.3" />
    </Svg>
  );
}

export function MapPinIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M20 10.4c0 5.4-8 11.1-8 11.1s-8-5.7-8-11.1a8 8 0 1 1 16 0Z" />
      <circle cx="12" cy="10.2" r="2.9" />
    </Svg>
  );
}

export function FacebookIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" {...props}>
      <path d="M14.2 21v-8.1h2.7l.4-3.2h-3.1V7.7c0-.9.3-1.5 1.6-1.5h1.7V3.3c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.2H8.4v3.2h2.4V21h3.4Z" />
    </svg>
  );
}

export function InstagramIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <rect x="3.5" y="3.5" width="17" height="17" rx="4.6" />
      <circle cx="12" cy="12" r="4" />
      <path d="M16.9 7.1h.01" strokeWidth={2.2} />
    </Svg>
  );
}

export function YouTubeIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" {...props}>
      <path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8ZM10 15.1V8.9l5.2 3.1L10 15.1Z" />
    </svg>
  );
}

export function AlertIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5v5.3" />
      <path d="M12 16.4h.01" strokeWidth={2.2} />
    </Svg>
  );
}

export function ImagePlaceholderIcon(props: IconProps) {
  return (
    <Svg {...props}>
      <rect x="3" y="4.5" width="18" height="15" rx="2.4" />
      <circle cx="8.6" cy="9.6" r="1.6" />
      <path d="m4 17 4.7-4.5 3.4 3.2 2.7-2.4L20 17.5" />
    </Svg>
  );
}
