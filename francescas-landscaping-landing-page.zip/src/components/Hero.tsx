import { useSite } from "../context/SiteContext";
import { ArrowRightIcon } from "./Icons";

export function Hero() {
  const { data } = useSite();
  const { hero } = data;

  const isVideo = hero.mediaType === "video" && hero.videoUrl;

  const isYoutube = (url?: string) =>
    url && (url.includes("youtube.com") || url.includes("youtu.be"));

  const getYoutubeEmbed = (url: string) => {
    try {
      if (url.includes("youtu.be/")) {
        const id = url.split("youtu.be/")[1]?.split("?")[0];
        return `https://www.youtube.com/embed/${id}?autoplay=1&mute=1&loop=1&playlist=${id}&controls=0&showinfo=0&rel=0`;
      }
      const match = url.match(/[?&]v=([^&#]+)/);
      if (match && match[1]) {
        return `https://www.youtube.com/embed/${match[1]}?autoplay=1&mute=1&loop=1&playlist=${match[1]}&controls=0&showinfo=0&rel=0`;
      }
    } catch (e) {
      console.warn("Invalid YouTube URL", e);
    }
    return url;
  };

  return (
    <section
      id="home"
      aria-labelledby="hero-heading"
      className="relative isolate w-full overflow-hidden bg-forest-ink"
    >
      {isVideo ? (
        <div className="absolute inset-0 h-full w-full overflow-hidden">
          {isYoutube(hero.videoUrl) ? (
            <iframe
              src={getYoutubeEmbed(hero.videoUrl!)}
              title="Hero Background Video"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              className="pointer-events-none absolute left-1/2 top-1/2 h-[150%] w-[150%] -translate-x-1/2 -translate-y-1/2 object-cover"
            />
          ) : (
            <video
              src={hero.videoUrl}
              autoPlay
              muted
              loop
              playsInline
              className="absolute inset-0 h-full w-full object-cover object-center"
            />
          )}
        </div>
      ) : (
        <img
          src={hero.imageUrl}
          alt={hero.altText}
          className="absolute inset-0 h-full w-full object-cover object-[62%_center] md:object-center"
          loading="eager"
          fetchPriority="high"
          decoding="async"
          width={1920}
          height={1280}
        />
      )}

      {/* Darkened overlay matching reference */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[linear-gradient(100deg,rgba(12,40,25,0.94)_0%,rgba(16,50,32,0.86)_32%,rgba(17,52,33,0.55)_58%,rgba(17,52,33,0.18)_82%,rgba(17,52,33,0.08)_100%)]"
      />
      <div
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-forest-ink/55 to-transparent"
      />

      <div className="relative mx-auto flex w-full max-w-[76rem] flex-col justify-center px-5 pb-10 pt-11 sm:px-8 sm:pb-12 sm:pt-14 md:min-h-[clamp(19rem,34vw,25rem)] md:py-14 lg:px-10">
        <div className="max-w-[30rem]">
          <h1
            id="hero-heading"
            className="font-display text-[clamp(1.85rem,4.5vw,3.05rem)] font-extrabold leading-[1.06] tracking-[-0.035em] text-white [text-wrap:balance]"
          >
            {hero.headline.map((line, idx) => (
              <span key={idx} className="block whitespace-nowrap">
                {line}
              </span>
            ))}
          </h1>
          <p className="mt-4 max-w-[29rem] font-sans text-[0.95rem] leading-relaxed text-white/90">
            {hero.description}
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3 sm:mt-7 sm:gap-4">
            {hero.primaryCtaText ? (
              <a
                href={hero.primaryCtaHref || "#contact"}
                className="btn btn-primary px-6 py-3.5 text-[0.92rem] sm:text-[0.95rem]"
              >
                {hero.primaryCtaText}
                <ArrowRightIcon className="h-[1.15rem] w-[1.15rem]" strokeWidth={2} />
              </a>
            ) : null}
            {hero.secondaryCtaText ? (
              <a
                href={hero.secondaryCtaHref || "#services"}
                className="btn btn-ghost-light px-6 py-3.5 text-[0.92rem] text-white sm:text-[0.95rem]"
              >
                {hero.secondaryCtaText}
              </a>
            ) : null}
          </div>
        </div>
      </div>

      <p className="absolute bottom-3 right-4 z-10 font-sans text-[0.62rem] uppercase tracking-[0.18em] text-white/55 sm:bottom-4 sm:right-8">
        {isVideo ? "Illustrative garden video" : "Illustrative garden photography"}
      </p>
    </section>
  );
}
