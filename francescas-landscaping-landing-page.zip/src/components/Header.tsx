import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { useSite } from "../context/SiteContext";
import { Logo } from "./Logo";
import { ArrowRightIcon, CloseIcon, MenuIcon } from "./Icons";
import { Key } from "lucide-react";

export function Header() {
  const { data, openAdmin } = useSite();
  const { header } = data;

  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;
    const ids = header.navItems.map((n) => n.href.replace("#", ""));
    const sections = ids
      .map((id) => document.getElementById(id))
      .filter((node): node is HTMLElement => Boolean(node));
    if (!sections.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-38% 0px -52% 0px", threshold: [0, 0.2, 0.6] },
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, [header.navItems]);

  useEffect(() => {
    if (!menuOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  const handleNavigate = () => setMenuOpen(false);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full border-b bg-white/97 backdrop-blur transition-shadow duration-300",
        scrolled
          ? "border-cream-line shadow-[0_10px_28px_-22px_rgba(20,63,42,0.45)]"
          : "border-transparent",
      )}
    >
      <a
        href="#services"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-50 focus:rounded-full focus:bg-forest focus:px-5 focus:py-2.5 focus:font-display focus:text-sm focus:font-semibold focus:text-white"
      >
        Skip to content
      </a>

      <div className="mx-auto flex w-full max-w-[86rem] items-center justify-between gap-4 px-5 py-3 md:px-8 lg:px-10">
        <a
          href="#home"
          onClick={handleNavigate}
          className="shrink-0 rounded-lg"
          aria-label={`${header.brandName} ${header.brandSubtitle} — back to top`}
        >
          {header.useCustomLogo && header.customLogoUrl ? (
            <img
              src={header.customLogoUrl}
              alt={`${header.brandName} ${header.brandSubtitle}`}
              style={{ height: `${header.logoHeight || 42}px` }}
              className="w-auto object-contain"
            />
          ) : (
            <Logo
              height={header.logoHeight || 42}
              className="max-w-[13.5rem] sm:max-w-none"
            />
          )}
        </a>

        <nav aria-label="Primary" className="hidden items-center gap-1 min-[900px]:flex min-[900px]:gap-2 xl:gap-4">
          {header.navItems.map((link) => {
            const isActive = active === link.href.replace("#", "");
            return (
              <a
                key={link.id || link.href}
                href={link.href}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "relative rounded-md px-3 py-2 font-display text-[0.92rem] font-semibold transition-colors xl:px-4",
                  "after:absolute after:bottom-0 after:left-1/2 after:h-[3px] after:w-7 after:-translate-x-1/2 after:rounded-full after:bg-leaf after:transition-opacity",
                  isActive
                    ? "text-forest after:opacity-100"
                    : "text-forest/80 after:opacity-0 hover:text-forest hover:after:opacity-40",
                )}
              >
                {link.label}
              </a>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          {/* Header Admin Key shortcut so it is found immediately from the top */}
          <button
            type="button"
            onClick={openAdmin}
            className="hidden sm:inline-flex items-center gap-1.5 rounded-full border border-forest/25 bg-cream-soft px-3 py-1.5 font-display text-[0.76rem] font-bold text-forest transition hover:bg-forest hover:text-white"
            title="Open Admin CMS Portal (no login required)"
          >
            <Key className="h-3.5 w-3.5 text-leaf" />
            <span>Admin Key</span>
          </button>

          {header.ctaText ? (
            <a
              href={header.ctaHref || "#contact"}
              className="btn btn-primary hidden px-5 py-3 text-[0.88rem] sm:inline-flex"
            >
              {header.ctaText}
              <ArrowRightIcon className="h-4 w-4" strokeWidth={2} />
            </a>
          ) : null}

          <button
            type="button"
            className="grid h-11 w-11 place-items-center rounded-full border border-cream-line text-forest transition hover:border-leaf hover:bg-cream min-[900px]:hidden"
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            onClick={() => setMenuOpen((value) => !value)}
          >
            {menuOpen ? <CloseIcon className="h-6 w-6" /> : <MenuIcon className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      <div
        id="mobile-menu"
        className={cn(
          "min-[900px]:hidden overflow-y-auto overscroll-contain border-t border-cream-line bg-white transition-[max-height,opacity] duration-300 ease-out",
          menuOpen ? "max-h-[calc(100dvh-4.5rem)] opacity-100" : "max-h-0 opacity-0",
        )}
        aria-hidden={!menuOpen}
      >
        <nav aria-label="Mobile" className="px-5 pb-6 pt-2">
          <ul className="divide-y divide-cream-line/80">
            {header.navItems.map((link) => (
              <li key={link.id || link.href}>
                <a
                  href={link.href}
                  onClick={handleNavigate}
                  tabIndex={menuOpen ? 0 : -1}
                  className="flex items-center justify-between py-3.5 font-display text-[1.05rem] font-semibold text-forest"
                >
                  {link.label}
                  <ArrowRightIcon className="h-4 w-4 text-leaf-dark" strokeWidth={2} />
                </a>
              </li>
            ))}
          </ul>
          {header.ctaText ? (
            <a
              href={header.ctaHref || "#contact"}
              onClick={handleNavigate}
              tabIndex={menuOpen ? 0 : -1}
              className="btn btn-primary mt-5 w-full py-3.5"
            >
              {header.ctaText}
              <ArrowRightIcon className="h-4 w-4" strokeWidth={2} />
            </a>
          ) : null}

          <button
            type="button"
            onClick={() => {
              handleNavigate();
              openAdmin();
            }}
            tabIndex={menuOpen ? 0 : -1}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-full border border-forest/20 bg-cream py-2.5 font-display text-xs font-bold text-forest transition hover:bg-forest hover:text-white"
          >
            <Key className="h-3.5 w-3.5 text-leaf" />
            <span>Open Admin Key / CMS</span>
          </button>

          <p className="mt-4 text-center text-xs text-forest/60">
            {header.brandTagline} in Palawan
          </p>
        </nav>
      </div>
    </header>
  );
}
