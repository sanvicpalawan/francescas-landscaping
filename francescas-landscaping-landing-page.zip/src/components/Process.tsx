import { useEffect, useRef, useState } from "react";
import { useSite } from "../context/SiteContext";
import { ArrowRightIcon, CareGrowIcon, ChatIcon, LayersIcon, PencilLeafIcon } from "./Icons";
import { Leaf, CheckCircle2, Sparkles } from "lucide-react";
import { cn } from "../utils/cn";

export function Process() {
  const { data } = useSite();
  const { process, sectionVisibility } = data;

  const [isInView, setIsInView] = useState(false);
  const [activeStepIdx, setActiveStepIdx] = useState<number | null>(null);
  const [autoPulseIdx, setAutoPulseIdx] = useState<number>(0);
  const sectionRef = useRef<HTMLElement>(null);

  // Scroll reveal observer
  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.15 },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Ambient forward flow pulse cycling through the 4 steps
  useEffect(() => {
    if (!isInView || !process.items.length) return;
    const interval = setInterval(() => {
      setAutoPulseIdx((curr) => (curr + 1) % process.items.length);
    }, 2800);
    return () => clearInterval(interval);
  }, [isInView, process.items.length]);

  if (!sectionVisibility.process || !process.items.length) {
    return null;
  }

  const renderIcon = (iconName: string, isHovered: boolean, isAutoPulsed: boolean) => {
    switch (iconName) {
      case "design":
        return (
          <span
            className={cn(
              "inline-block transition-transform duration-300",
              isHovered && "rotate-[-12deg] scale-115",
              isAutoPulsed && !isHovered && "scale-105",
            )}
          >
            <PencilLeafIcon className="h-6 w-6" strokeWidth={1.55} />
          </span>
        );
      case "build":
        return (
          <span
            className={cn(
              "inline-block transition-transform duration-300",
              isHovered && "-translate-y-1 scale-110",
              isAutoPulsed && !isHovered && "scale-105",
            )}
          >
            <LayersIcon className="h-6 w-6" strokeWidth={1.55} />
          </span>
        );
      case "maintain":
        return (
          <span
            className={cn(
              "inline-block transition-transform duration-500",
              isHovered && "rotate-12 scale-115 text-leaf-dark",
              isAutoPulsed && !isHovered && "scale-105",
            )}
          >
            <CareGrowIcon className="h-6 w-6" strokeWidth={1.55} />
          </span>
        );
      case "leaf":
        return (
          <span
            className={cn(
              "inline-block transition-transform duration-300",
              isHovered && "scale-115 rotate-6",
            )}
          >
            <Leaf className="h-6 w-6" strokeWidth={1.55} />
          </span>
        );
      case "check":
        return (
          <span
            className={cn(
              "inline-block transition-transform duration-300",
              isHovered && "scale-115",
            )}
          >
            <CheckCircle2 className="h-6 w-6" strokeWidth={1.55} />
          </span>
        );
      case "consult":
      default:
        return (
          <span
            className={cn(
              "inline-block transition-transform duration-300",
              isHovered && "scale-115",
              isAutoPulsed && !isHovered && "scale-105",
            )}
          >
            <ChatIcon className="h-6 w-6" strokeWidth={1.55} />
          </span>
        );
    }
  };

  return (
    <section
      ref={sectionRef}
      aria-labelledby="process-heading"
      className="bg-cream pb-9 md:pb-10 overflow-hidden"
    >
      <div className="shell">
        <div
          className={cn(
            "transition-all duration-700",
            isInView ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0",
          )}
        >
          <div className="flex items-center gap-2">
            <h2
              id="process-heading"
              className="font-display text-[clamp(1.45rem,3.6vw,1.8rem)] font-bold tracking-[-0.025em] text-forest"
            >
              {process.sectionTitle}
            </h2>
            <span
              className={cn(
                "hidden sm:inline-flex items-center gap-1 rounded-full bg-leaf/15 px-2 py-0.5 text-[0.62rem] font-bold text-leaf-dark transition-all duration-500",
                isInView ? "scale-100 opacity-100" : "scale-75 opacity-0",
              )}
            >
              <Sparkles className="h-2.5 w-2.5" />
              <span>4-Stage Journey</span>
            </span>
          </div>

          {process.intro ? (
            <p className="mt-1.5 max-w-2xl font-sans text-[0.87rem] leading-relaxed text-forest/75 sm:text-[0.95rem]">
              {process.intro}
            </p>
          ) : null}
        </div>

        <ol className="mt-6 grid grid-cols-1 gap-4 md:mt-7 min-[900px]:flex min-[900px]:flex-row min-[900px]:items-start min-[900px]:gap-0">
          {process.items.map((step, index) => {
            const isLast = index === process.items.length - 1;
            const isHovered = activeStepIdx === index;
            const isAutoPulsed = autoPulseIdx === index && activeStepIdx === null;
            const delayMs = index * 120;

            return (
              <li
                key={step.id || index}
                onMouseEnter={() => setActiveStepIdx(index)}
                onMouseLeave={() => setActiveStepIdx(null)}
                style={{ transitionDelay: `${delayMs}ms` }}
                className={cn(
                  "group relative flex flex-1 items-start gap-3.5 pr-4 sm:gap-4 transition-all duration-500 cursor-pointer rounded-xl p-2 -m-2 sm:p-2.5 sm:-m-2.5",
                  isInView ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0",
                  isHovered && "bg-white/50 backdrop-blur-xs shadow-xs",
                )}
              >
                {/* Mobile Animated Vertical Connector Line with Flow Pulse */}
                {!isLast ? (
                  <div
                    aria-hidden="true"
                    className="absolute left-[1.85rem] top-14 h-[calc(100%+0.75rem)] w-[2px] bg-gradient-to-b from-leaf via-leaf/40 to-leaf/10 sm:hidden overflow-hidden"
                  >
                    <span
                      className="block h-1/2 w-full bg-leaf shadow-[0_0_8px_#6EB33F] animate-pulse"
                      style={{ animationDuration: "2s" }}
                    />
                  </div>
                ) : null}

                {/* Animated Circular Step Node */}
                <div className="relative shrink-0">
                  <span
                    className={cn(
                      "relative z-10 grid h-11 w-11 place-items-center rounded-full transition-all duration-300 ring-1",
                      isHovered
                        ? "bg-leaf text-white ring-4 ring-leaf/30 shadow-[0_0_16px_rgba(110,179,63,0.45)] scale-112"
                        : isAutoPulsed
                        ? "bg-[#E3EED0] text-leaf-dark ring-2 ring-leaf/40 scale-106"
                        : "bg-[#EDF3DE] text-leaf-dark ring-leaf/20",
                    )}
                  >
                    {renderIcon(step.icon, isHovered, isAutoPulsed)}
                  </span>

                  {/* Step Number Tag Badge */}
                  <span
                    className={cn(
                      "absolute -top-1.5 -right-1.5 z-20 grid h-4 w-4 place-items-center rounded-full font-mono text-[0.55rem] font-bold shadow-xs transition-all duration-300",
                      isHovered
                        ? "bg-forest text-white scale-110"
                        : isAutoPulsed
                        ? "bg-leaf text-white scale-100"
                        : "bg-forest-ink/70 text-white/90 opacity-70",
                    )}
                  >
                    0{index + 1}
                  </span>
                </div>

                {/* Step Text Info with Smooth Color Transitions */}
                <div className="min-w-0 pt-0.5 lg:pt-2 flex-1">
                  <h3
                    className={cn(
                      "font-display text-[1rem] font-bold leading-tight transition-colors duration-200 sm:text-[1.05rem]",
                      isHovered ? "text-leaf-dark" : "text-forest",
                    )}
                  >
                    {step.title}
                  </h3>
                  <p
                    className={cn(
                      "mt-1 max-w-[13rem] font-sans text-[0.8rem] leading-relaxed transition-colors duration-200",
                      isHovered ? "text-forest" : "text-forest/75",
                    )}
                  >
                    {step.description}
                  </p>
                </div>

                {/* Desktop Connecting Arrow with Smooth Forward Flow Pulse */}
                {!isLast ? (
                  <div
                    aria-hidden="true"
                    className="absolute right-1 top-[1.15rem] hidden min-[900px]:flex items-center"
                  >
                    <ArrowRightIcon
                      className={cn(
                        "h-6 w-6 transition-all duration-300",
                        isHovered
                          ? "translate-x-1.5 text-leaf scale-115"
                          : isAutoPulsed
                          ? "translate-x-0.5 text-leaf"
                          : "text-leaf-dark/60",
                      )}
                      strokeWidth={1.8}
                    />
                  </div>
                ) : null}
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
