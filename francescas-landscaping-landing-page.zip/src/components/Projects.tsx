import { useCallback, useEffect, useState } from "react";
import { useSite } from "../context/SiteContext";
import { Modal, ModalCloseButton } from "./Modal";
import {
  ArrowRightIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ImagePlaceholderIcon,
} from "./Icons";
import { cn } from "../utils/cn";
import { Play, Images, Video as VideoIcon } from "lucide-react";

export function Projects() {
  const { data } = useSite();
  const { projects: projectSection, sectionVisibility } = data;
  const projects = projectSection.items || [];
  const featured = projects.slice(0, 3);

  const [galleryIndex, setGalleryIndex] = useState<number | null>(null);
  const [activePhotoSubIndex, setActivePhotoSubIndex] = useState<number>(0);

  const closeGallery = useCallback(() => {
    setGalleryIndex(null);
    setActivePhotoSubIndex(0);
  }, []);

  const next = useCallback(() => {
    setGalleryIndex((index) => {
      if (index === null) return 0;
      return (index + 1) % projects.length;
    });
    setActivePhotoSubIndex(0);
  }, [projects.length]);

  const previous = useCallback(() => {
    setGalleryIndex((index) => {
      if (index === null) return 0;
      return (index - 1 + projects.length) % projects.length;
    });
    setActivePhotoSubIndex(0);
  }, [projects.length]);

  useEffect(() => {
    if (galleryIndex === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "ArrowRight") next();
      if (event.key === "ArrowLeft") previous();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [galleryIndex, next, previous]);

  if (!sectionVisibility.projects || !projects.length) {
    return null;
  }

  const current = galleryIndex === null ? null : projects[galleryIndex];
  const currentImages = current
    ? current.images && current.images.length > 0
      ? current.images
      : [current.image]
    : [];
  const activeMediaUrl = currentImages[activePhotoSubIndex] || current?.image || "";

  // Helper to detect video embed
  const isYoutube = (url?: string) =>
    url && (url.includes("youtube.com") || url.includes("youtu.be"));
  const getYoutubeEmbed = (url: string) => {
    try {
      if (url.includes("youtu.be/")) {
        const id = url.split("youtu.be/")[1]?.split("?")[0];
        return `https://www.youtube.com/embed/${id}?autoplay=1`;
      }
      const match = url.match(/[?&]v=([^&#]+)/);
      if (match && match[1]) {
        return `https://www.youtube.com/embed/${match[1]}?autoplay=1`;
      }
    } catch (e) {
      console.warn("Invalid YouTube URL", e);
    }
    return url;
  };

  return (
    <section id="projects" aria-labelledby="projects-heading" className="bg-cream pb-8 md:pb-9">
      <div className="shell">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 sm:gap-4">
            <h2
              id="projects-heading"
              className="font-display text-[clamp(1.45rem,3.6vw,1.8rem)] font-bold tracking-[-0.025em] text-forest"
            >
              {projectSection.sectionTitle}
            </h2>
            <span aria-hidden="true" className="h-[2.5px] w-10 rounded-full bg-leaf sm:w-14" />
          </div>
          <button
            type="button"
            onClick={() => setGalleryIndex(0)}
            className="group inline-flex items-center gap-1.5 rounded-md font-display text-[0.85rem] font-semibold text-forest transition-colors hover:text-leaf-dark sm:text-[0.92rem]"
          >
            {projectSection.viewAllText}
            <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-0.5" strokeWidth={1.9} />
          </button>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2 sm:gap-3.5 md:grid-cols-3">
          {featured.map((project, index) => {
            const hasMultipleImages = project.images && project.images.length > 1;
            const hasVideo = Boolean(project.videoUrl);

            return (
              <figure
                key={project.id || index}
                className="group relative overflow-hidden rounded-xl bg-cream-line sm:first:col-span-2 md:first:col-span-1"
              >
                <button
                  type="button"
                  onClick={() => {
                    setGalleryIndex(index);
                    setActivePhotoSubIndex(0);
                  }}
                  className="block w-full text-left"
                  aria-label={`Open larger view of ${project.title}`}
                >
                  <img
                    src={project.image}
                    alt={project.alt}
                    loading="lazy"
                    decoding="async"
                    width={1200}
                    height={720}
                    className="h-36 w-full object-cover transition-transform duration-700 group-hover:scale-[1.03] sm:h-40 md:h-[8.4rem] lg:h-40"
                  />

                  {/* Top Badges for Multiple Photos or Video */}
                  <div className="absolute left-2.5 top-2.5 flex items-center gap-1.5">
                    {hasVideo ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-forest-ink/80 px-2 py-0.5 font-sans text-[0.62rem] font-semibold text-white shadow-sm backdrop-blur">
                        <Play className="h-2.5 w-2.5 fill-current" />
                        Video
                      </span>
                    ) : null}
                    {hasMultipleImages ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-forest-ink/80 px-2 py-0.5 font-sans text-[0.62rem] font-semibold text-white shadow-sm backdrop-blur">
                        <Images className="h-2.5 w-2.5" />
                        {project.images!.length} Photos
                      </span>
                    ) : null}
                  </div>

                  {/* Bottom overlay with title and placeholder badge */}
                  <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-forest-ink/80 via-forest-ink/20 to-transparent px-3 pb-2 pt-7">
                    <span className="flex items-center justify-between gap-2">
                      <span className="font-display text-[0.78rem] font-semibold text-white">
                        {project.title}
                      </span>
                      {project.isPlaceholderPhoto ? (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-white/15 px-2 py-0.5 font-sans text-[0.55rem] font-semibold uppercase tracking-[0.1em] text-white/90 ring-1 ring-inset ring-white/30">
                          <ImagePlaceholderIcon className="h-2.5 w-2.5" strokeWidth={2} />
                          Placeholder
                        </span>
                      ) : null}
                    </span>
                  </span>
                </button>
              </figure>
            );
          })}
        </div>

        {projectSection.disclaimer ? (
          <p className="mt-3 max-w-[54rem] font-sans text-[0.7rem] leading-relaxed text-forest/50">
            {projectSection.disclaimer}
          </p>
        ) : null}
      </div>

      <Modal
        open={current !== null}
        onClose={closeGallery}
        label={current ? `${current.title} project details` : "Project gallery"}
        panelClassName="sm:max-w-4xl bg-cream"
      >
        {current ? (
          <div>
            <div className="relative bg-forest-ink">
              {current.videoUrl ? (
                <div className="aspect-video w-full overflow-hidden bg-black">
                  {isYoutube(current.videoUrl) ? (
                    <iframe
                      src={getYoutubeEmbed(current.videoUrl)}
                      title={current.title}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="h-full w-full border-0"
                    />
                  ) : (
                    <video
                      src={current.videoUrl}
                      controls
                      autoPlay
                      className="h-full w-full object-contain"
                    />
                  )}
                </div>
              ) : (
                <img
                  src={activeMediaUrl}
                  alt={current.alt}
                  className="mx-auto max-h-[60vh] w-full object-cover"
                  loading="lazy"
                  decoding="async"
                />
              )}

              <ModalCloseButton onClose={closeGallery} />

              {/* Prev / Next project arrows */}
              <div className="absolute inset-y-0 left-0 flex items-center pl-2 sm:pl-3">
                <button
                  type="button"
                  onClick={previous}
                  aria-label="Previous project"
                  className="grid h-10 w-10 place-items-center rounded-full bg-white/90 text-forest shadow-md transition hover:bg-white"
                >
                  <ChevronLeftIcon className="h-5 w-5" strokeWidth={2} />
                </button>
              </div>
              <div className="absolute inset-y-0 right-0 flex items-center pr-2 sm:pr-3">
                <button
                  type="button"
                  onClick={next}
                  aria-label="Next project"
                  className="grid h-10 w-10 place-items-center rounded-full bg-white/90 text-forest shadow-md transition hover:bg-white"
                >
                  <ChevronRightIcon className="h-5 w-5" strokeWidth={2} />
                </button>
              </div>
            </div>

            <div className="p-5 sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-sans text-[0.62rem] font-bold uppercase tracking-[0.18em] text-leaf-dark">
                    {current.isPlaceholderPhoto
                      ? "Project imagery placeholder"
                      : "Completed Francesca's Project"}
                  </p>
                  <h3 className="mt-1 font-display text-xl font-bold text-forest">
                    {current.title}
                  </h3>
                  <p className="font-sans text-[0.8rem] text-forest/65">
                    {current.category}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {current.videoUrl ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-leaf/20 px-2.5 py-1 text-xs font-semibold text-leaf-dark">
                      <VideoIcon className="h-3 w-3" /> Video Included
                    </span>
                  ) : null}
                  <p className="rounded-full border border-forest/15 px-3 py-1 font-sans text-[0.68rem] font-semibold text-forest/70">
                    Project {(galleryIndex ?? 0) + 1} of {projects.length}
                  </p>
                </div>
              </div>

              {current.description ? (
                <p className="mt-2.5 font-sans text-[0.85rem] leading-relaxed text-forest/80">
                  {current.description}
                </p>
              ) : null}

              {/* Multiple Images Sub-strip */}
              {currentImages.length > 1 ? (
                <div className="mt-4 border-t border-cream-line pt-3">
                  <div className="flex items-center justify-between text-xs text-forest/70">
                    <span className="font-semibold">
                      Project Photos ({currentImages.length})
                    </span>
                    <span>Photo {activePhotoSubIndex + 1} of {currentImages.length}</span>
                  </div>
                  <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
                    {currentImages.map((img, subIdx) => (
                      <button
                        key={subIdx}
                        type="button"
                        onClick={() => setActivePhotoSubIndex(subIdx)}
                        className={cn(
                          "relative h-14 w-20 shrink-0 overflow-hidden rounded-md border-2 transition",
                          activePhotoSubIndex === subIdx
                            ? "border-leaf ring-2 ring-leaf/40"
                            : "border-transparent opacity-70 hover:opacity-100",
                        )}
                      >
                        <img
                          src={img}
                          alt={`Project photo ${subIdx + 1}`}
                          className="h-full w-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}

              {/* All Projects Navigation Strip */}
              <div className="mt-5 border-t border-cream-line pt-4">
                <p className="mb-2 font-sans text-[0.7rem] font-semibold uppercase tracking-wider text-forest/60">
                  All Projects
                </p>
                <div
                  className="grid grid-cols-3 gap-2 sm:grid-cols-6"
                  role="group"
                  aria-label="Gallery thumbnails"
                >
                  {projects.map((project, index) => (
                    <button
                      key={project.id || index}
                      type="button"
                      onClick={() => {
                        setGalleryIndex(index);
                        setActivePhotoSubIndex(0);
                      }}
                      aria-label={`View ${project.title}`}
                      aria-current={index === galleryIndex}
                      className={cn(
                        "overflow-hidden rounded-md ring-offset-2 transition",
                        index === galleryIndex
                          ? "ring-2 ring-leaf"
                          : "opacity-70 hover:opacity-100",
                      )}
                    >
                      <img
                        src={project.image}
                        alt=""
                        className="h-10 w-full object-cover sm:h-14"
                        loading="lazy"
                        decoding="async"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </Modal>
    </section>
  );
}
