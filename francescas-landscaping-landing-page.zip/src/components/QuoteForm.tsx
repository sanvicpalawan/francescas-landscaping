import { useEffect, useRef, useState, type FormEvent } from "react";
import { useSite } from "../context/SiteContext";
import { cn } from "../utils/cn";
import { AlertIcon, ArrowRightIcon, CheckIcon, WhatsAppIcon } from "./Icons";
import { PalmFrond } from "./Leaves";

type FormState = {
  name: string;
  email: string;
  phone: string;
  service: string;
  location: string;
  budget: string;
  message: string;
};

type FieldErrors = Partial<Record<keyof FormState, string>>;

type SubmissionStatus =
  | { kind: "idle" }
  | { kind: "sending" }
  | { kind: "success"; note?: string }
  | { kind: "failure"; message: string }
  | { kind: "whatsapp-missing" };

const EMPTY_FORM: FormState = {
  name: "",
  email: "",
  phone: "",
  service: "",
  location: "",
  budget: "",
  message: "",
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_PATTERN = /^[+()\d\s.-]{7,24}$/;

function validate(form: FormState): FieldErrors {
  const errors: FieldErrors = {};
  if (form.name.trim().length < 2) errors.name = "Please enter your name.";
  if (!EMAIL_PATTERN.test(form.email.trim()))
    errors.email = "Please enter a valid email address.";
  if (form.phone.trim()) {
    const digits = form.phone.replace(/\D/g, "");
    if (!PHONE_PATTERN.test(form.phone.trim()) || digits.length < 7) {
      errors.phone = "Please enter a valid phone number, or leave it blank.";
    }
  }
  if (!form.service) errors.service = "Please choose the service you need.";
  if (form.message.trim().length < 10) {
    errors.message =
      "Please add a few details about your project (at least 10 characters).";
  }
  return errors;
}

const inputShell =
  "block rounded-lg bg-white px-3 py-2 text-left transition focus-within:ring-2 focus-within:ring-leaf focus-within:ring-offset-2 focus-within:ring-offset-forest";
const labelText = "block font-sans text-[0.68rem] font-semibold leading-tight text-earth/85";
const controlText =
  "mt-0.5 w-full border-0 bg-transparent p-0 font-sans text-[0.9rem] leading-snug text-forest placeholder:text-forest/40 focus:outline-none";

export function QuoteForm({
  presetService,
}: {
  presetService?: { service: string; key: number } | null;
}) {
  const { data, addSubmission } = useSite();
  const { quoteForm, sectionVisibility } = data;

  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [status, setStatus] = useState<SubmissionStatus>({ kind: "idle" });
  const [copied, setCopied] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);
  const lastPresetKey = useRef<number | null>(null);

  useEffect(() => {
    if (!presetService) return;
    if (lastPresetKey.current === presetService.key) return;
    lastPresetKey.current = presetService.key;
    setForm((current) => ({ ...current, service: presetService.service }));
    setErrors((current) => ({ ...current, service: undefined }));
    setStatus({ kind: "idle" });
    const timer = window.setTimeout(() => {
      nameRef.current?.focus({ preventScroll: true });
    }, 400);
    return () => window.clearTimeout(timer);
  }, [presetService]);

  if (!sectionVisibility.quote) {
    return null;
  }

  const update = (field: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
    if (status.kind !== "idle" && status.kind !== "sending") setStatus({ kind: "idle" });
    setCopied(false);
  };

  const inquiryText = () =>
    [
      `Name: ${form.name.trim()}`,
      `Email: ${form.email.trim()}`,
      `Phone: ${form.phone.trim() || "—"}`,
      `Service needed: ${form.service}`,
      form.location ? `Property Location: ${form.location.trim()}` : "",
      form.budget ? `Estimated Budget: ${form.budget.trim()}` : "",
      "",
      "Project details:",
      form.message.trim(),
    ]
      .filter(Boolean)
      .join("\n");

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(inquiryText());
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validate(form);
    setErrors(nextErrors);
    setCopied(false);

    if (Object.keys(nextErrors).length > 0) {
      setStatus({ kind: "idle" });
      const firstField = (
        ["name", "email", "phone", "service", "message"] as const
      ).find((field) => nextErrors[field]);
      if (firstField) {
        const container = document.getElementById(`field-${firstField}`);
        container?.scrollIntoView({ behavior: "smooth", block: "center" });
        const control = container?.querySelector<HTMLElement>(
          "input, select, textarea",
        );
        control?.focus({ preventScroll: true });
      }
      return;
    }

    // Always log to local Inbox for the admin to view
    addSubmission({
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      service: form.service,
      location: form.location.trim(),
      budget: form.budget.trim(),
      message: form.message.trim(),
    });

    if (quoteForm.submissionEndpoint) {
      setStatus({ kind: "sending" });
      try {
        const response = await fetch(quoteForm.submissionEndpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({
            ...form,
            submittedAt: new Date().toISOString(),
          }),
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        setStatus({
          kind: "success",
          note: "Inquiry sent successfully to our team endpoint!",
        });
        setForm(EMPTY_FORM);
      } catch {
        setStatus({
          kind: "success",
          note: "Inquiry saved to local admin inbox. (Endpoint unreachable at this moment).",
        });
        setForm(EMPTY_FORM);
      }
    } else {
      // Saved in admin inbox
      setStatus({
        kind: "success",
        note: "Inquiry recorded in the Admin Submissions Inbox! (Connect an endpoint in Admin Settings for live email forwarding).",
      });
      setForm(EMPTY_FORM);
    }
  };

  const handleWhatsApp = () => {
    const rawNumber = quoteForm.whatsappNumber || data.footer.phoneLabel;
    if (!rawNumber) {
      setStatus({ kind: "whatsapp-missing" });
      return;
    }
    const cleanNumber = rawNumber.replace(/\D/g, "");
    const text = encodeURIComponent(
      `Hello ${data.header.brandName}, I'd like to ask about landscaping and garden services in Palawan.`,
    );
    window.open(
      `https://wa.me/${cleanNumber}?text=${text}`,
      "_blank",
      "noopener,noreferrer",
    );
  };

  const fieldError = (field: keyof FormState) =>
    errors[field] ? (
      <p
        id={`error-${field}`}
        role="alert"
        className="mt-1.5 flex items-start gap-1.5 font-sans text-[0.72rem] font-medium leading-snug text-[#FFD9C2]"
      >
        <AlertIcon className="mt-px h-3.5 w-3.5 shrink-0" strokeWidth={2} />
        {errors[field]}
      </p>
    ) : null;

  return (
    <section
      id="contact"
      aria-labelledby="quote-heading"
      className="bg-cream pb-8 md:pb-9"
    >
      <div className="shell">
        <div className="relative overflow-hidden rounded-3xl bg-forest px-5 py-6 shadow-[0_28px_60px_-45px_rgba(15,50,33,0.85)] sm:px-7 md:px-8 md:py-7">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 overflow-hidden"
          >
            <PalmFrond className="absolute -bottom-28 -left-24 h-[20rem] w-auto -rotate-12 text-leaf/[0.18]" />
            <PalmFrond className="absolute -right-28 -top-24 h-[18rem] w-auto rotate-[150deg] text-white/[0.05]" />
          </div>

          <div className="desktop-quote relative z-10 grid gap-6 lg:gap-10 min-[900px]:grid-cols-[minmax(0,0.82fr)_minmax(0,2.05fr)]">
            <div className="min-[900px]:pt-1">
              <h2
                id="quote-heading"
                className="font-display text-[clamp(1.7rem,4vw,2.3rem)] font-bold tracking-[-0.03em] text-white"
              >
                {quoteForm.title}
              </h2>
              <p className="mt-2 max-w-[19rem] font-sans text-[0.9rem] leading-relaxed text-white/85 sm:text-[0.95rem]">
                {quoteForm.subtitle}
              </p>
            </div>

            <form onSubmit={handleSubmit} noValidate className="min-w-0">
              <div className="grid gap-3 sm:grid-cols-2">
                <div id="field-name">
                  <label
                    htmlFor="name"
                    className={cn(
                      inputShell,
                      errors.name && "ring-2 ring-[#FFB18A]",
                    )}
                  >
                    <span className={labelText}>
                      {quoteForm.nameLabel} <span aria-hidden="true">*</span>
                    </span>
                    <input
                      id="name"
                      name="name"
                      ref={nameRef}
                      type="text"
                      autoComplete="name"
                      value={form.name}
                      onChange={(event) => update("name", event.target.value)}
                      placeholder="Full name"
                      aria-required="true"
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? "error-name" : undefined}
                      className={controlText}
                    />
                  </label>
                  {fieldError("name")}
                </div>

                <div id="field-email">
                  <label
                    htmlFor="email"
                    className={cn(
                      inputShell,
                      errors.email && "ring-2 ring-[#FFB18A]",
                    )}
                  >
                    <span className={labelText}>
                      {quoteForm.emailLabel} <span aria-hidden="true">*</span>
                    </span>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      inputMode="email"
                      autoComplete="email"
                      value={form.email}
                      onChange={(event) => update("email", event.target.value)}
                      placeholder="you@example.com"
                      aria-required="true"
                      aria-invalid={Boolean(errors.email)}
                      aria-describedby={
                        errors.email ? "error-email" : undefined
                      }
                      className={controlText}
                    />
                  </label>
                  {fieldError("email")}
                </div>

                <div id="field-phone">
                  <label
                    htmlFor="phone"
                    className={cn(
                      inputShell,
                      errors.phone && "ring-2 ring-[#FFB18A]",
                    )}
                  >
                    <span className={labelText}>{quoteForm.phoneLabel}</span>
                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      inputMode="tel"
                      autoComplete="tel"
                      value={form.phone}
                      onChange={(event) => update("phone", event.target.value)}
                      placeholder="+63"
                      aria-invalid={Boolean(errors.phone)}
                      aria-describedby={
                        errors.phone ? "error-phone" : undefined
                      }
                      className={controlText}
                    />
                  </label>
                  {fieldError("phone")}
                </div>

                <div id="field-service">
                  <div
                    className={cn(
                      inputShell,
                      "relative",
                      errors.service && "ring-2 ring-[#FFB18A]",
                    )}
                  >
                    <label htmlFor="service" className={labelText}>
                      {quoteForm.serviceLabel} <span aria-hidden="true">*</span>
                    </label>
                    <select
                      id="service"
                      name="service"
                      value={form.service}
                      onChange={(event) =>
                        update("service", event.target.value)
                      }
                      aria-required="true"
                      aria-invalid={Boolean(errors.service)}
                      aria-describedby={
                        errors.service ? "error-service" : undefined
                      }
                      className={cn(
                        controlText,
                        "cursor-pointer appearance-none pr-6",
                        !form.service && "text-forest/45",
                      )}
                    >
                      <option value="">Select a service</option>
                      {quoteForm.serviceOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                    <svg
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      className="pointer-events-none absolute bottom-2.5 right-3 h-4 w-4 text-forest/70"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                    >
                      <path d="m6 9.5 6 6 6-6" />
                    </svg>
                  </div>
                  {fieldError("service")}
                </div>

                {/* Optional Property Location Field */}
                {quoteForm.showLocationField ? (
                  <div id="field-location">
                    <label htmlFor="location" className={inputShell}>
                      <span className={labelText}>
                        Property Location (Optional)
                      </span>
                      <input
                        id="location"
                        name="location"
                        type="text"
                        value={form.location}
                        onChange={(event) =>
                          update("location", event.target.value)
                        }
                        placeholder="e.g. Puerto Princesa, El Nido, San Vicente..."
                        className={controlText}
                      />
                    </label>
                  </div>
                ) : null}

                {/* Optional Budget / Scope Field */}
                {quoteForm.showBudgetField ? (
                  <div id="field-budget">
                    <label htmlFor="budget" className={inputShell}>
                      <span className={labelText}>
                        Project Scope / Budget (Optional)
                      </span>
                      <input
                        id="budget"
                        name="budget"
                        type="text"
                        value={form.budget}
                        onChange={(event) =>
                          update("budget", event.target.value)
                        }
                        placeholder="e.g. Backyard garden, Full villa, Routine care"
                        className={controlText}
                      />
                    </label>
                  </div>
                ) : null}

                <div
                  id="field-message"
                  className={cn(
                    "sm:col-span-2",
                    !quoteForm.showLocationField && !quoteForm.showBudgetField
                      ? ""
                      : "",
                  )}
                >
                  <label
                    htmlFor="message"
                    className={cn(
                      inputShell,
                      errors.message && "ring-2 ring-[#FFB18A]",
                    )}
                  >
                    <span className={labelText}>
                      {quoteForm.messageLabel} <span aria-hidden="true">*</span>
                    </span>
                    <textarea
                      id="message"
                      name="message"
                      rows={3}
                      value={form.message}
                      onChange={(event) =>
                        update("message", event.target.value)
                      }
                      placeholder="Location, size of the space, and what you'd like to achieve"
                      aria-required="true"
                      aria-invalid={Boolean(errors.message)}
                      aria-describedby={
                        errors.message ? "error-message" : undefined
                      }
                      className={cn(controlText, "resize-y min-h-[3.25rem]")}
                    />
                  </label>
                  {fieldError("message")}
                </div>
              </div>

              <div className="mt-4 flex flex-col items-stretch gap-3 sm:flex-row sm:items-center">
                <button
                  type="submit"
                  disabled={status.kind === "sending"}
                  className="btn btn-primary order-1 px-6 py-3.5 sm:order-none sm:min-w-[12.5rem] disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {status.kind === "sending"
                    ? "Sending…"
                    : quoteForm.submitButtonText || "Send Inquiry"}
                  <ArrowRightIcon
                    className="h-[1.1rem] w-[1.1rem]"
                    strokeWidth={2}
                  />
                </button>
                <span
                  aria-hidden="true"
                  className="hidden h-8 w-px bg-white/25 sm:block"
                />
                <button
                  type="button"
                  onClick={handleWhatsApp}
                  className="btn btn-ghost-light order-2 px-6 py-3.5 sm:order-none"
                >
                  <WhatsAppIcon className="h-[1.15rem] w-[1.15rem]" />
                  {quoteForm.whatsappButtonText || "Chat on WhatsApp"}
                </button>
              </div>

              <div aria-live="polite" className="mt-3.5">
                {status.kind === "whatsapp-missing" ? (
                  <p
                    role="status"
                    className="flex items-start gap-2 rounded-lg border border-white/20 bg-white/5 px-3.5 py-2.5 font-sans text-[0.78rem] leading-relaxed text-cream"
                  >
                    <AlertIcon
                      className="mt-0.5 h-4 w-4 shrink-0"
                      strokeWidth={2}
                    />
                    WhatsApp number not configured yet. Set it in the Admin
                    Portal or contact us via email.
                  </p>
                ) : null}

                {status.kind === "failure" ? (
                  <p
                    role="alert"
                    className="flex items-start gap-2 rounded-lg border border-[#FFB18A]/50 bg-[#7B2F1A]/30 px-3.5 py-2.5 font-sans text-[0.78rem] leading-relaxed text-[#FFE1D2]"
                  >
                    <AlertIcon
                      className="mt-0.5 h-4 w-4 shrink-0"
                      strokeWidth={2}
                    />
                    {status.message}
                  </p>
                ) : null}

                {status.kind === "success" ? (
                  <div
                    role="status"
                    className="rounded-lg border border-leaf/50 bg-leaf/15 px-3.5 py-2.5 font-sans text-[0.8rem] leading-relaxed text-white"
                  >
                    <p className="flex items-start gap-2 font-medium">
                      <CheckIcon
                        className="mt-0.5 h-4 w-4 shrink-0 text-leaf"
                        strokeWidth={2.4}
                      />
                      <span>
                        Thank you! Your inquiry has been submitted.
                      </span>
                    </p>
                    {status.note ? (
                      <p className="mt-1 text-xs text-white/80 pl-6">
                        {status.note}
                      </p>
                    ) : null}
                    <div className="mt-2 pl-6">
                      <button
                        type="button"
                        onClick={handleCopy}
                        className="inline-flex items-center gap-1.5 rounded-full border border-white/30 px-2.5 py-1 text-xs text-white transition hover:bg-white/10"
                      >
                        {copied ? <CheckIcon className="h-3 w-3" /> : null}
                        {copied ? "Copied Inquiry" : "Copy Inquiry Copy"}
                      </button>
                    </div>
                  </div>
                ) : null}

                {status.kind === "idle" || status.kind === "sending" ? (
                  <p className="font-sans text-[0.7rem] leading-relaxed text-white/50">
                    Required fields are marked *. All inquiries are securely
                    logged in the Admin Submissions Inbox.
                  </p>
                ) : null}
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
