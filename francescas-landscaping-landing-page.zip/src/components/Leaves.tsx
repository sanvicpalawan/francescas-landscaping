import { cn } from "../utils/cn";

/**
 * Decorative tropical foliage used at the edges of cream and dark-green
 * panels. Purely ornamental — hidden from assistive technology.
 */

export function PalmFrond({ className, flip = false }: { className?: string; flip?: boolean }) {
  const leaflets = Array.from({ length: 13 }, (_, i) => {
    const t = i / 12;
    const x = 92 - 22 * t * t;
    const y = 196 - 182 * t;
    const len = 22 + 58 * (1 - t) ** 1.15;
    const drop = 8 + 24 * (1 - t);
    return {
      id: i,
      left: `M${x} ${y}c-${len * 0.45} -2 -${len * 0.85} -${drop * 0.7} -${len} -${drop}c${len * 0.4} ${drop * 0.35} ${len * 0.8} ${drop * 0.85} ${len} ${drop}Z`,
      right: `M${x} ${y}c${len * 0.42} -3 ${len * 0.8} -${drop * 0.75} ${len * 0.95} -${drop * 1.15}c-${len * 0.4} ${drop * 0.45} -${len * 0.75} ${drop * 0.9} -${len * 0.95} ${drop * 1.15}Z`,
    };
  });

  return (
    <svg
      viewBox="0 0 180 200"
      aria-hidden="true"
      focusable="false"
      className={cn("block", flip && "-scale-x-100", className)}
    >
      <g fill="currentColor">
        <path d="M92 198c3-46 2-92-8-140l5-1c11 48 12 95 9 141h-6Z" />
        {leaflets.map((leaflet) => (
          <g key={leaflet.id}>
            <path d={leaflet.left} />
            <path d={leaflet.right} />
          </g>
        ))}
      </g>
    </svg>
  );
}

export function BroadLeaf({ className, flip = false }: { className?: string; flip?: boolean }) {
  return (
    <svg
      viewBox="0 0 200 200"
      aria-hidden="true"
      focusable="false"
      className={cn("block", flip && "-scale-x-100", className)}
    >
      <g fill="currentColor">
        <path d="M100 196C44 148 20 96 32 40 52 8 92 4 120 22c36 24 42 82-20 174Z" />
        <path d="M96 182C78 132 74 80 90 26" fill="none" stroke="currentColor" strokeWidth="4" opacity="0" />
      </g>
    </svg>
  );
}

export function LeafSpray({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 260 220"
      aria-hidden="true"
      focusable="false"
      className={cn("block", className)}
    >
      <g fill="currentColor">
        <path d="M126 214C74 168 40 122 44 64c4-38 26-56 58-52 42 6 62 58 24 202Z" />
        <path d="M132 210c10-62 38-108 86-136 8 42-16 100-86 136Z" opacity="0.85" />
        <path d="M124 208C92 154 56 124 10 118c14 42 54 78 114 90Z" opacity="0.7" />
      </g>
    </svg>
  );
}

/** Subtle cream-panel edge foliage, as in the "Why Choose" / quote bands. */
export function PanelFoliage({ tone = "leaf" }: { tone?: "leaf" | "white" }) {
  const color = tone === "leaf" ? "text-leaf/35" : "text-white/10";
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden rounded-[inherit]">
      <PalmFrond
        className={cn("absolute -left-10 -top-10 h-[150%] w-auto rotate-[18deg]", color)}
      />
      <PalmFrond
        flip
        className={cn("absolute -right-12 -bottom-16 h-[140%] w-auto -rotate-[24deg]", color)}
      />
      <BroadLeaf className={cn("absolute -right-6 -top-8 h-28 w-auto rotate-[130deg]", color)} />
    </div>
  );
}
