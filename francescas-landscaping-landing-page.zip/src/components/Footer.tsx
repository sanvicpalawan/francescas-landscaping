import { useSite } from "../context/SiteContext";
import { Logo } from "./Logo";
import { MailIcon, MapPinIcon, PhoneIcon } from "./Icons";
import { LucideSocialIcon } from "./LucideSocialIcon";
import { Key } from "lucide-react";

export function Footer() {
  const { data, openAdmin } = useSite();
  const { footer, header } = data;
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-forest-deep text-white">
      <div
        aria-hidden="true"
        className="h-1 w-full bg-gradient-to-r from-leaf via-leaf/50 to-forest-deep"
      />
      <div className="mx-auto w-full max-w-[76rem] px-5 pb-5 pt-7 md:px-8 md:pt-8 lg:px-10">
        <div className="desktop-footer grid gap-7 md:grid-cols-2 lg:gap-0">
          {/* Brand */}
          <div className="min-[900px]:pr-7">
            <a
              href="#home"
              className="inline-block rounded-lg"
              aria-label={`${header.brandName} ${header.brandSubtitle} — back to top`}
            >
              {footer.useCustomLogo && footer.customLogoUrl ? (
                <img
                  src={footer.customLogoUrl}
                  alt={header.brandName}
                  style={{ height: `${footer.logoHeight || 46}px` }}
                  className="w-auto object-contain brightness-0 invert"
                />
              ) : (
                <Logo
                  tone="white"
                  variant="footer"
                  height={footer.logoHeight || 46}
                />
              )}
            </a>
            <div className="mt-3 flex items-start gap-3">
              <span
                aria-hidden="true"
                className="mt-0.5 block h-11 w-px shrink-0 bg-white/25"
              />
              <p className="max-w-[15rem] font-sans text-[0.8rem] leading-relaxed text-white/75">
                {footer.blurb}
              </p>
            </div>
          </div>

          {/* Explore */}
          <nav
            aria-label="Footer navigation"
            className="min-[900px]:border-l min-[900px]:border-white/15 min-[900px]:pl-7"
          >
            <h2 className="font-display text-[0.72rem] font-bold uppercase tracking-[0.16em] text-white/60">
              {footer.exploreTitle}
            </h2>
            <ul className="desktop-footer-nav mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5">
              {header.navItems.map((link) => (
                <li key={link.id || link.href}>
                  <a
                    href={link.href}
                    className="inline-block rounded font-sans text-[0.85rem] font-medium text-white/85 transition-colors hover:text-leaf"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div className="min-[900px]:border-l min-[900px]:border-white/15 min-[900px]:pl-7">
            <h2 className="font-display text-[0.72rem] font-bold uppercase tracking-[0.16em] text-white/60">
              {footer.contactTitle}
            </h2>
            <ul className="mt-3 space-y-2.5 font-sans text-[0.85rem] text-white/85">
              <li className="flex items-start gap-2.5">
                <PhoneIcon
                  className="mt-0.5 h-4 w-4 shrink-0 text-leaf"
                  strokeWidth={1.8}
                />
                {footer.phoneHref ? (
                  <a
                    href={footer.phoneHref}
                    className="rounded hover:text-leaf"
                  >
                    {footer.phoneLabel}
                  </a>
                ) : (
                  <span>{footer.phoneLabel}</span>
                )}
              </li>
              <li className="flex items-start gap-2.5">
                <MailIcon
                  className="mt-0.5 h-4 w-4 shrink-0 text-leaf"
                  strokeWidth={1.8}
                />
                {footer.emailHref ? (
                  <a
                    href={footer.emailHref}
                    className="min-w-0 break-words rounded hover:text-leaf"
                  >
                    {footer.emailLabel}
                  </a>
                ) : (
                  <span className="min-w-0 break-words">
                    {footer.emailLabel}
                  </span>
                )}
              </li>
              <li className="flex items-start gap-2.5">
                <MapPinIcon
                  className="mt-0.5 h-4 w-4 shrink-0 text-leaf"
                  strokeWidth={1.8}
                />
                <span>
                  {footer.location}
                  {footer.hours ? (
                    <span className="block font-sans text-[0.7rem] text-white/55">
                      {footer.hours}
                    </span>
                  ) : null}
                </span>
              </li>
            </ul>
          </div>

          {/* Follow & Social Media with Lucide Icons */}
          <div className="min-[900px]:border-l min-[900px]:border-white/15 min-[900px]:pl-7">
            <h2 className="font-display text-[0.72rem] font-bold uppercase tracking-[0.16em] text-white/60">
              {footer.followTitle}
            </h2>
            <div className="mt-3 flex flex-wrap items-center gap-2.5">
              {footer.socialLinks
                .filter((s) => s.enabled)
                .map((social) => (
                  <a
                    key={social.id}
                    href={social.url || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`${social.label} (opens in a new tab)`}
                    title={social.label}
                    className="grid h-9 w-9 place-items-center rounded-full border border-white/25 text-white/90 transition hover:border-leaf hover:bg-leaf hover:text-white"
                  >
                    <LucideSocialIcon name={social.icon} size={18} />
                  </a>
                ))}
            </div>
            <p className="mt-3 max-w-[12rem] font-sans text-[0.68rem] leading-relaxed text-white/50">
              Social media accounts can be managed via the Admin Portal.
            </p>
          </div>
        </div>

        {/* Bottom bar with Copyright and the Single Official Admin Key button */}
        <div className="mt-6 border-t border-white/15 pt-4">
          <div className="flex flex-col items-center gap-3 text-center sm:flex-row sm:items-center sm:justify-between sm:text-left">
            <p className="font-sans text-[0.72rem] text-white/65">
              {footer.copyright ||
                `© ${currentYear} Francesca's Greens & Petals. All rights reserved.`}
            </p>

            {/* Admin Key Button — Exactly one in the footer, clear, unmistakable, and prominent */}
            <div className="flex items-center">
              <button
                type="button"
                id="admin-key"
                data-testid="admin-key"
                onClick={openAdmin}
                className="group inline-flex items-center gap-2 rounded-full border border-leaf/70 bg-forest px-4 py-2 font-display text-[0.82rem] font-bold text-white shadow-md transition hover:border-leaf hover:bg-leaf-dark hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-leaf focus:ring-offset-2 focus:ring-offset-forest-deep"
                title="Admin Key — Open CMS Portal (no login required)"
                aria-label="Admin Key"
              >
                <Key className="h-4 w-4 text-leaf transition-transform duration-200 group-hover:rotate-45" />
                <span>Admin Key</span>
              </button>
            </div>
          </div>
          {footer.previewNote ? (
            <p className="mt-2 text-center font-sans text-[0.64rem] text-white/40 sm:text-left">
              {footer.previewNote}
            </p>
          ) : null}
        </div>
      </div>
    </footer>
  );
}
