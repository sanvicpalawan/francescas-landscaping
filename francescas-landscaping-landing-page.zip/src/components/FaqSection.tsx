import { useEffect, useRef, useState } from "react";
import { useSite } from "../context/SiteContext";
import { ChevronDown, HelpCircle, RotateCcw, CheckCircle2 } from "lucide-react";
import { cn } from "../utils/cn";

interface TypewriterAnswerProps {
  answer: string;
  isOpen: boolean;
  questionId: string;
}

function TypewriterAnswer({ answer, isOpen, questionId }: TypewriterAnswerProps) {
  const [displayText, setDisplayText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [replayCount, setReplayCount] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    if (!isOpen) {
      setDisplayText("");
      setIsTyping(false);
      return;
    }

    // Start typewriter effect
    setIsTyping(true);
    setDisplayText("");

    let currentIndex = 0;
    const totalChars = answer.length;

    // Responsive typewriter rhythm:
    // Faster on long answers so user is engaged without waiting too long (~1.4s to 2s total)
    const baseSpeed = totalChars > 240 ? 10 : totalChars > 120 ? 14 : 18;

    function typeNextChar() {
      if (currentIndex >= totalChars) {
        setIsTyping(false);
        return;
      }

      // Step 1 to 2 characters for natural flow
      const step = totalChars > 280 ? 2 : 1;
      currentIndex = Math.min(totalChars, currentIndex + step);
      setDisplayText(answer.slice(0, currentIndex));

      // Realistic human punctuation pauses
      const lastChar = answer[currentIndex - 1];
      let delay = baseSpeed;
      if (lastChar === "." || lastChar === "!" || lastChar === "?") {
        delay = baseSpeed + 90;
      } else if (lastChar === "," || lastChar === ";" || lastChar === "—") {
        delay = baseSpeed + 45;
      }

      timerRef.current = setTimeout(typeNextChar, delay);
    }

    // Initial brief delay for accordion slide-in
    timerRef.current = setTimeout(typeNextChar, 100);

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isOpen, answer, questionId, replayCount]);

  const handleSkipToEnd = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    setDisplayText(answer);
    setIsTyping(false);
  };

  const handleReplay = () => {
    setReplayCount((c) => c + 1);
  };

  return (
    <div className="border-t border-cream-line/70 bg-white/70 px-4 pb-4 pt-3.5 sm:px-5 sm:pl-13">
      {/* Typewriter Status Badge */}
      <div className="mb-2 flex items-center justify-between text-[0.7rem]">
        <div className="flex items-center gap-1.5 font-semibold text-leaf-dark">
          {isTyping ? (
            <>
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-leaf opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-leaf" />
              </span>
              <span>Answering in real-time…</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="h-3.5 w-3.5 text-leaf" />
              <span className="text-forest/70">Verified Palawan Guidance</span>
            </>
          )}
        </div>

        {/* Action Controls: Skip or Replay */}
        <div className="flex items-center gap-2">
          {isTyping ? (
            <button
              type="button"
              onClick={handleSkipToEnd}
              className="text-[0.68rem] font-semibold text-forest/60 underline hover:text-leaf-dark"
            >
              Skip to end
            </button>
          ) : (
            <button
              type="button"
              onClick={handleReplay}
              title="Replay typewriter motion response"
              className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[0.68rem] font-semibold text-forest/60 hover:bg-cream hover:text-leaf-dark"
            >
              <RotateCcw className="h-3 w-3" />
              <span>Replay</span>
            </button>
          )}
        </div>
      </div>

      {/* Answer Paragraph with Emerald Typewriter Cursor */}
      <p
        aria-live="polite"
        className="font-sans text-[0.88rem] leading-relaxed text-forest/90 sm:text-[0.92rem]"
      >
        {displayText}
        {isTyping && (
          <span
            className="animate-typewriter-cursor ml-1 inline-block h-[1.15em] w-[2.5px] rounded-xs bg-leaf align-middle shadow-[0_0_8px_#6EB33F]"
            aria-hidden="true"
          />
        )}
      </p>
    </div>
  );
}

export function FaqSection() {
  const { data } = useSite();
  const { faq, sectionVisibility } = data;
  const [openId, setOpenId] = useState<string | null>(faq.items[0]?.id || null);

  if (!sectionVisibility.faq || !faq.items.length) {
    return null;
  }

  const toggle = (id: string) => {
    setOpenId((curr) => (curr === id ? null : id));
  };

  return (
    <section id="faq" aria-labelledby="faq-heading" className="bg-cream pb-12 md:pb-14">
      <div className="shell">
        <div className="text-center">
          <div className="title-rule flex justify-center text-center font-display text-[clamp(1.5rem,3.8vw,2.1rem)] font-bold text-forest">
            <span>{faq.sectionTitle}</span>
          </div>
          {faq.subtitle ? (
            <p className="mx-auto mt-2 max-w-2xl font-sans text-[0.88rem] leading-relaxed text-forest/75 sm:text-[0.95rem]">
              {faq.subtitle}
            </p>
          ) : null}
        </div>

        <div className="mx-auto mt-8 max-w-3xl space-y-3 md:mt-10">
          {faq.items.map((item, index) => {
            const isOpen = openId === item.id;
            return (
              <div
                key={item.id || index}
                className={cn(
                  "overflow-hidden rounded-xl border transition-all duration-300",
                  isOpen
                    ? "border-leaf/50 bg-white shadow-md ring-1 ring-leaf/20"
                    : "border-cream-line bg-cream-soft hover:border-leaf/30 hover:bg-white/60",
                )}
              >
                <button
                  type="button"
                  onClick={() => toggle(item.id)}
                  aria-expanded={isOpen}
                  className="flex w-full items-start justify-between gap-4 p-4 text-left transition-colors sm:p-5"
                >
                  <div className="flex items-start gap-3">
                    <span
                      className={cn(
                        "mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-bold transition-all duration-300",
                        isOpen
                          ? "bg-leaf text-white shadow-[0_0_10px_rgba(110,179,63,0.4)] scale-105"
                          : "bg-leaf/15 text-forest/80",
                      )}
                    >
                      {index + 1}
                    </span>
                    <div>
                      {item.category ? (
                        <span className="mb-1 inline-block rounded-full bg-cream px-2 py-0.5 font-sans text-[0.68rem] font-semibold uppercase tracking-wider text-forest/60">
                          {item.category}
                        </span>
                      ) : null}
                      <h3
                        className={cn(
                          "font-display text-[0.98rem] font-bold transition-colors sm:text-[1.05rem]",
                          isOpen ? "text-leaf-dark" : "text-forest",
                        )}
                      >
                        {item.question}
                      </h3>
                    </div>
                  </div>
                  <ChevronDown
                    className={cn(
                      "mt-1 h-5 w-5 shrink-0 text-forest/60 transition-transform duration-300",
                      isOpen && "rotate-180 text-leaf",
                    )}
                  />
                </button>

                {isOpen ? (
                  <TypewriterAnswer
                    key={`${item.id}-${isOpen}`}
                    answer={item.answer}
                    isOpen={isOpen}
                    questionId={item.id}
                  />
                ) : null}
              </div>
            );
          })}
        </div>

        <div className="mx-auto mt-8 flex max-w-md items-center justify-center gap-2 text-center text-xs text-forest/60">
          <HelpCircle className="h-4 w-4 text-leaf" />
          <span>Have a custom question about your property?</span>
          <a
            href="#contact"
            className="font-semibold text-forest underline hover:text-leaf-dark"
          >
            Ask us directly
          </a>
        </div>
      </div>
    </section>
  );
}
