import { cn } from "../utils/cn";

/**
 * APPROVED LOGO LOCKUP
 * The two-leaf + water-droplet mark and the Francesca's Greens & Petals
 * wordmark are reproduced here as vector artwork so the logo keeps its
 * proportions and transparent background at any size.
 *
 * To use the supplied master logo files instead, drop them into
 * `public/assets/` and render an <img> here with the same dimensions.
 * Do not recolor, crop, or redraw the lockup.
 */

import type { CSSProperties } from "react";

export function LeafMark({
  className,
  tone = "forest",
  style,
}: {
  className?: string;
  tone?: "forest" | "white";
  style?: CSSProperties;
}) {
  const fill = tone === "white" ? "#ffffff" : "#1B5236";
  const knockout = tone === "white" ? "#143F2A" : "#FBFBF7";
  return (
    <svg
      viewBox="0 0 200 160"
      style={style}
      className={cn("block h-auto w-auto", className)}
      role="img"
      aria-label="Francesca's Greens & Petals leaf and water droplet mark"
      focusable="false"
    >
      <g fill={fill}>
        {/* Large sweeping leaf */}
        <path d="M103 138C86 92 114 39 192 8c6 64-26 111-89 130Z" />
        {/* Smaller left leaf */}
        <path d="M95 133C76 99 47 74 8 65c8 40 36 64 87 68Z" />
        {/* Water droplet */}
        <path d="M134 92c12 17 24 31 24 44 0 12-11 21-24 21s-24-9-24-21c0-13 12-27 24-44Z" />
      </g>
      {/* Leaf veins and the droplet highlight are knocked out, exactly as in
          the supplied transparent artwork. */}
      <g fill="none" stroke={knockout} strokeLinecap="round">
        <path d="M116 124C130 88 152 48 184 16" strokeWidth="7" />
        <path d="M28 79c20 16 40 32 58 48" strokeWidth="6" />
        <path d="M146 133c6 6 5 13-2 16" strokeWidth="5" />
      </g>
    </svg>
  );
}

export function Logo({
  tone = "forest",
  variant = "header",
  className,
  height,
}: {
  tone?: "forest" | "white";
  variant?: "header" | "footer" | "stacked";
  className?: string;
  height?: number;
}) {
  const isLight = tone === "white";
  const wordColor = isLight ? "text-white" : "text-forest";
  const isFooter = variant === "footer";

  const effectiveHeight = height || (isFooter ? 46 : 42);
  const scale = effectiveHeight / 42;

  if (variant === "stacked") {
    return (
      <div
        className={cn("flex flex-col items-center text-center", className)}
        role="img"
        aria-label="Francesca's Greens & Petals — Landscaping & Garden Needs"
      >
        <LeafMark
          tone={tone}
          style={{ height: `${effectiveHeight * 1.4}px` }}
          className="w-auto"
        />
        <span
          style={{ fontSize: `${scale * 1.8}rem` }}
          className={cn("mt-2 font-display font-bold tracking-tight", wordColor)}
        >
          Francesca&rsquo;s
        </span>
        <span
          style={{ fontSize: `${scale * 0.8}rem` }}
          className={cn(
            "mt-1 flex items-center gap-2 font-display font-medium tracking-[0.03em]",
            wordColor,
          )}
        >
          <span aria-hidden className="h-px w-4 bg-current opacity-70" />
          Greens &amp; Petals
          <span aria-hidden className="h-px w-4 bg-current opacity-70" />
        </span>
      </div>
    );
  }

  return (
    <div
      className={cn("flex items-center gap-2.5", className)}
      role="img"
      aria-label="Francesca's Greens & Petals — Landscaping & Garden Needs"
    >
      <LeafMark
        tone={tone}
        style={{ height: `${effectiveHeight}px` }}
        className="w-auto shrink-0"
      />
      <span className="flex min-w-0 flex-col leading-none">
        <span
          style={{ fontSize: `${scale * (isFooter ? 1.55 : 1.5)}rem` }}
          className={cn(
            "font-display font-bold tracking-[-0.04em] leading-none",
            wordColor,
          )}
        >
          Francesca&rsquo;s
        </span>
        <span
          style={{ fontSize: `${scale * (isFooter ? 0.76 : 0.7)}rem` }}
          className={cn(
            "mt-[0.25rem] flex items-center gap-1.5 whitespace-nowrap font-display font-medium tracking-[0.005em]",
            wordColor,
          )}
        >
          <span aria-hidden className="h-px w-2.5 bg-current opacity-60" />
          Greens &amp; Petals
          <span aria-hidden className="h-px w-2.5 bg-current opacity-60" />
        </span>
      </span>
    </div>
  );
}
