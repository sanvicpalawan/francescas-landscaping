import { useCallback, useState } from "react";
import { useSite } from "../context/SiteContext";
import { type ServiceItem } from "../types/siteData";
import { Modal, ModalCloseButton } from "./Modal";
import {
  ArrowRightIcon,
  CareLeafIcon,
  CheckIcon,
  LeafIcon,
  PotPlantIcon,
} from "./Icons";
import { Sprout, TreePine, Flower2, Play } from "lucide-react";

export function Services({ onRequestQuote }: { onRequestQuote: (service: string) => void }) {
  const { data } = useSite();
  const { services, sectionVisibility } = data;
  const [selected, setSelected] = useState<ServiceItem | null>(null);
  const closeModal = useCallback(() => setSelected(null), []);

  if (!sectionVisibility.services || !services.items.length) {
    return null;
  }

  const handleRequest = (service: ServiceItem) => {
    setSelected(null);
    onRequestQuote(service.title);
  };

  const renderIcon = (iconName: string, className = "h-8 w-8") => {
    switch (iconName) {
      case "care":
        return <CareLeafIcon className={className} strokeWidth={1.45} />;
      case "supply":
        return <PotPlantIcon className={className} strokeWidth={1.45} />;
      case "sprout":
        return <Sprout className={className} strokeWidth={1.45} />;
      case "tree":
        return <TreePine className={className} strokeWidth={1.45} />;
      case "flower":
        return <Flower2 className={className} strokeWidth={1.45} />;
      case "landscape":
      case "leaf":
      default:
        return <LeafIcon className={className} strokeWidth={1.45} />;
    }
  };

  return (
    <section id="services" aria-labelledby="services-heading" className="bg-cream pb-6 pt-10 md:pb-7 md:pt-12">
      <div className="shell">
        <h2
          id="services-heading"
          className="title-rule flex justify-center text-center font-display text-[clamp(1.6rem,4vw,2.15rem)] font-bold text-forest"
        >
          <span>{services.sectionTitle}</span>
        </h2>

        <div className="mx-auto mt-6 flex max-w-[52rem] flex-col gap-3 md:mt-7 md:gap-3.5">
          {services.items.map((service) => {
            return (
              <article
                key={service.id}
                className="group relative flex flex-col overflow-hidden rounded-2xl border border-white/80 bg-cream-soft shadow-[0_1px_0_rgba(27,82,54,0.03)] transition-shadow duration-300 hover:shadow-[0_16px_36px_-28px_rgba(20,63,42,0.55)] sm:flex-row sm:items-center sm:gap-4 sm:p-2.5 sm:pr-3.5 md:gap-5"
              >
                <button
                  type="button"
                  onClick={() => setSelected(service)}
                  aria-label={`View details for ${service.title}`}
                  className="relative block shrink-0 overflow-hidden sm:w-[10.5rem] md:w-[12.5rem]"
                >
                  <img
                    src={service.image}
                    alt={service.alt}
                    loading="lazy"
                    decoding="async"
                    width={900}
                    height={560}
                    className="h-32 w-full object-cover transition-transform duration-500 group-hover:scale-[1.04] sm:h-[4.9rem] sm:rounded-lg md:h-[5.4rem]"
                  />
                  {service.videoUrl ? (
                    <span className="absolute bottom-2 right-2 flex items-center gap-1 rounded-full bg-forest-ink/80 px-2 py-0.5 text-[0.6rem] font-semibold text-white">
                      <Play className="h-2.5 w-2.5 fill-current" /> Video
                    </span>
                  ) : null}
                  <span className="absolute bottom-2 left-2 rounded-full bg-forest-ink/65 px-2 py-0.5 font-sans text-[0.58rem] font-semibold uppercase tracking-[0.12em] text-white/90 sm:hidden">
                    Service preview
                  </span>
                </button>

                <div className="flex min-w-0 flex-1 items-start gap-3.5 px-4 py-3.5 sm:px-0 sm:py-0.5">
                  <span className="hidden shrink-0 text-leaf sm:grid sm:h-11 sm:w-11 sm:place-items-center">
                    {renderIcon(service.icon, "h-10 w-10")}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="flex items-center gap-2 font-display text-[1.1rem] font-bold leading-tight text-forest sm:text-[1.2rem]">
                        <span className="text-leaf sm:hidden">
                          {renderIcon(service.icon, "h-6 w-6")}
                        </span>
                        <button
                          type="button"
                          onClick={() => setSelected(service)}
                          className="text-left hover:text-leaf-dark"
                        >
                          {service.title}
                        </button>
                      </h3>
                      <button
                        type="button"
                        onClick={() => setSelected(service)}
                        aria-label={`Open ${service.title} details`}
                        className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-cream-line bg-white/70 text-leaf-dark transition group-hover:bg-leaf group-hover:text-white sm:hidden"
                      >
                        <ArrowRightIcon className="h-4 w-4" strokeWidth={2} />
                      </button>
                    </div>
                    <p className="mt-1 font-sans text-[0.85rem] leading-snug text-forest/85 sm:text-[0.885rem]">
                      {service.blurb}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setSelected(service)}
                  aria-label={`Open ${service.title} details`}
                  className="ml-auto mr-4 hidden h-9 w-9 shrink-0 place-items-center rounded-full bg-white/75 text-leaf-dark transition group-hover:bg-leaf group-hover:text-white sm:mr-0 sm:grid"
                >
                  <ArrowRightIcon className="h-[1.15rem] w-[1.15rem]" strokeWidth={2} />
                </button>
              </article>
            );
          })}
        </div>

        <p className="mx-auto mt-4 max-w-[46rem] text-center font-sans text-[0.72rem] leading-relaxed text-forest/50">
          Service photography &amp; details are editable via the Admin Portal in the footer.
        </p>
      </div>

      <Modal open={Boolean(selected)} onClose={closeModal} label={selected ? `${selected.title} details` : "Service details"}>
        {selected ? (
          <div>
            <div className="relative">
              {selected.videoUrl ? (
                <div className="aspect-video w-full overflow-hidden bg-black sm:rounded-t-3xl">
                  <iframe
                    src={selected.videoUrl}
                    title={selected.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="h-full w-full border-0"
                  />
                </div>
              ) : (
                <img
                  src={selected.image}
                  alt={selected.alt}
                  className="h-48 w-full object-cover sm:h-56 sm:rounded-t-3xl"
                  loading="lazy"
                  decoding="async"
                />
              )}
              <ModalCloseButton onClose={closeModal} />
            </div>
            <div className="p-6 sm:p-8">
              <div className="flex items-center gap-3">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-leaf-soft text-leaf-dark">
                  {renderIcon(selected.icon, "h-6 w-6")}
                </span>
                <div>
                  <h3 className="font-display text-xl font-bold text-forest sm:text-2xl">{selected.title}</h3>
                  <p className="font-sans text-[0.7rem] uppercase tracking-[0.14em] text-forest/50">
                    Palawan Landscaping &amp; Garden Service
                  </p>
                </div>
              </div>
              <p className="mt-4 font-sans text-[0.94rem] leading-relaxed text-forest/85">{selected.description}</p>
              {selected.includes && selected.includes.length > 0 ? (
                <ul className="mt-5 space-y-2.5">
                  {selected.includes.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 font-sans text-[0.9rem] text-forest/90">
                      <CheckIcon className="mt-0.5 h-4 w-4 shrink-0 text-leaf-dark" strokeWidth={2.2} />
                      {item}
                    </li>
                  ))}
                </ul>
              ) : null}
              <button
                type="button"
                onClick={() => handleRequest(selected)}
                className="btn btn-primary mt-7 w-full py-3.5 sm:w-auto"
              >
                Request a quote for this service
                <ArrowRightIcon className="h-4 w-4" strokeWidth={2} />
              </button>
            </div>
          </div>
        ) : null}
      </Modal>
    </section>
  );
}
