/**
 * FRANCESCA'S GREENS & PETALS - CENTRAL SITE STATE & TYPES
 * Supports full Admin control for:
 * - Theme & Color Palette (Hex + CSS variables)
 * - Fonts & Typography
 * - Header & Nav
 * - Hero (Images or Videos)
 * - Services (Add, Edit, Delete, Photos, Videos)
 * - Why Choose / Benefits
 * - Projects (Multiple Images, Videos, Add, Edit, Delete)
 * - Process Steps
 * - FAQ Section (Add, Edit, Delete questions)
 * - Testimonials
 * - Form Builder & Submissions Inbox
 * - Footer & Lucide Social Media Links
 */

export interface NavItem {
  id: string;
  label: string;
  href: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  icon: "landscape" | "care" | "supply" | "leaf" | "sprout" | "flower" | "tree";
  blurb: string;
  description: string;
  image: string;
  videoUrl?: string;
  alt: string;
  includes: string[];
}

export interface BenefitItem {
  id: string;
  title: string;
  description: string;
  icon: "professional" | "reliable" | "tropical" | "tailored" | "eco" | "quality";
}

export interface ProjectItem {
  id: string;
  title: string;
  category: string;
  image: string;
  images?: string[]; // Multiple photos support
  videoUrl?: string; // Video support
  alt: string;
  description?: string;
  isPlaceholderPhoto: boolean;
}

export interface ProcessItem {
  id: string;
  title: string;
  description: string;
  icon: "consult" | "design" | "build" | "maintain" | "leaf" | "check";
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category?: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  quote: string;
  rating: number;
  portraitUrl?: string;
  isPlaceholder: boolean;
}

export interface SocialLinkItem {
  id: string;
  platform: string;
  label: string;
  url: string;
  icon: string; // Lucide icon identifier: 'facebook' | 'instagram' | 'youtube' | 'whatsapp' | 'twitter' | 'linkedin' | 'tiktok' | 'globe' | 'mail' | 'phone'
  enabled: boolean;
}

export interface FormSubmission {
  id: string;
  name: string;
  email: string;
  phone?: string;
  service: string;
  location?: string;
  budget?: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export interface SiteData {
  theme: {
    forest: string; // Primary forest green #1B5236
    forestDeep: string; // #143F2A
    leaf: string; // Secondary leaf green #6EB33F
    leafDark: string; // #4F8E2A
    cream: string; // Warm cream #F6F3E8
    creamLine: string; // #E7E2D2
    earth: string; // Earth brown #7B5E3B
    headingFont: string; // 'Montserrat' | 'Playfair Display' | 'Plus Jakarta Sans' | 'Poppins' | 'Cinzel'
    bodyFont: string; // 'Open Sans' | 'Inter' | 'Lato' | 'Roboto'
  };

  header: {
    brandName: string;
    brandSubtitle: string;
    brandTagline: string;
    customLogoUrl?: string;
    useCustomLogo?: boolean;
    logoHeight?: number; // In pixels, default 42
    navItems: NavItem[];
    ctaText: string;
    ctaHref: string;
  };

  hero: {
    eyebrow: string;
    headline: string[];
    description: string;
    mediaType: "image" | "video";
    imageUrl: string;
    videoUrl?: string;
    altText: string;
    primaryCtaText: string;
    primaryCtaHref: string;
    secondaryCtaText: string;
    secondaryCtaHref: string;
  };

  sectionVisibility: {
    services: boolean;
    whyChoose: boolean;
    projects: boolean;
    process: boolean;
    testimonials: boolean;
    faq: boolean;
    quote: boolean;
  };

  services: {
    sectionTitle: string;
    items: ServiceItem[];
  };

  whyChoose: {
    sectionTitle: string;
    items: BenefitItem[];
  };

  projects: {
    sectionTitle: string;
    viewAllText: string;
    disclaimer: string;
    items: ProjectItem[];
  };

  process: {
    sectionTitle: string;
    intro: string;
    items: ProcessItem[];
  };

  faq: {
    sectionTitle: string;
    subtitle: string;
    items: FaqItem[];
  };

  testimonials: {
    sectionTitle: string;
    trustHeading: string;
    ratingNote: string;
    items: TestimonialItem[];
  };

  quoteForm: {
    title: string;
    subtitle: string;
    nameLabel: string;
    emailLabel: string;
    phoneLabel: string;
    serviceLabel: string;
    serviceOptions: string[];
    showLocationField: boolean;
    showBudgetField: boolean;
    messageLabel: string;
    submitButtonText: string;
    whatsappButtonText: string;
    whatsappNumber: string;
    submissionEndpoint: string;
  };

  footer: {
    blurb: string;
    exploreTitle: string;
    contactTitle: string;
    followTitle: string;
    phoneLabel: string;
    phoneHref: string;
    emailLabel: string;
    emailHref: string;
    location: string;
    hours: string;
    copyright: string;
    previewNote: string;
    customLogoUrl?: string;
    useCustomLogo?: boolean;
    logoHeight?: number; // In pixels, default 46
    socialLinks: SocialLinkItem[];
  };
}

export const INITIAL_SITE_DATA: SiteData = {
  theme: {
    forest: "#1B5236",
    forestDeep: "#143F2A",
    leaf: "#6EB33F",
    leafDark: "#4F8E2A",
    cream: "#F6F3E8",
    creamLine: "#E7E2D2",
    earth: "#7B5E3B",
    headingFont: "Montserrat",
    bodyFont: "Open Sans",
  },

  header: {
    brandName: "Francesca's",
    brandSubtitle: "Greens & Petals",
    brandTagline: "Landscaping & Garden Needs",
    customLogoUrl: "",
    useCustomLogo: false,
    logoHeight: 42,
    navItems: [
      { id: "nav-home", label: "Home", href: "#home" },
      { id: "nav-services", label: "Services", href: "#services" },
      { id: "nav-projects", label: "Projects", href: "#projects" },
      { id: "nav-about", label: "About", href: "#about" },
      { id: "nav-faq", label: "FAQ", href: "#faq" },
      { id: "nav-contact", label: "Contact", href: "#contact" },
    ],
    ctaText: "Get a Quote",
    ctaHref: "#contact",
  },

  hero: {
    eyebrow: "Palawan landscaping & garden needs",
    headline: ["Beautiful Outdoor", "Spaces for", "Tropical Living"],
    description:
      "Landscaping, garden care, and plant supply in Palawan — designed for beautiful, sustainable, and easy-to-maintain outdoor spaces.",
    mediaType: "image",
    imageUrl: "/images/hero-tropical-landscaping.jpg",
    videoUrl: "",
    altText: "Master tropical landscape design in Palawan with stone stairs, vibrant red cordylines, blooming exotic flowers, lanterns, and outdoor planters.",
    primaryCtaText: "Get a Quote",
    primaryCtaHref: "#contact",
    secondaryCtaText: "View Services",
    secondaryCtaHref: "#services",
  },

  sectionVisibility: {
    services: true,
    whyChoose: true,
    projects: true,
    process: true,
    testimonials: true,
    faq: true,
    quote: true,
  },

  services: {
    sectionTitle: "Our Services",
    items: [
      {
        id: "landscape-design",
        title: "Landscape Design",
        icon: "landscape",
        blurb:
          "Creative and functional landscape solutions for homes, resorts, and businesses.",
        description:
          "We plan outdoor spaces around how you actually live and work. Planting, paths, lighting, and hardscape are considered together so the garden looks intentional and thrives in Palawan's climate.",
        image:
          "https://images.pexels.com/photos/28586235/pexels-photo-28586235.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=560",
        videoUrl: "",
        alt: "Stone villa surrounded by tropical landscaping.",
        includes: [
          "Site visit and initial consultation",
          "Custom tropical planting plan & materials",
          "Full 2D/3D layout for new builds or garden refreshes",
        ],
      },
      {
        id: "garden-care",
        title: "Garden Care",
        icon: "care",
        blurb:
          "Professional garden maintenance to keep your outdoor spaces healthy and vibrant.",
        description:
          "Regular, practical care keeps a tropical garden lush instead of overgrown. We work with a maintenance rhythm that suits your space, from a private courtyard to resort grounds.",
        image:
          "https://images.pexels.com/photos/37108159/pexels-photo-37108159.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=560",
        videoUrl: "",
        alt: "Vibrant pink tropical hibiscus flower closeup.",
        includes: [
          "Pruning, trimming, weeding, and plant health checks",
          "Seasonal fertilization and soil enrichment",
          "Smart watering advice and irrigation checkups",
        ],
      },
      {
        id: "plant-supply",
        title: "Plant Supply",
        icon: "supply",
        blurb:
          "Quality ornamental plants, shrubs, and garden essentials sourced for Palawan's tropical climate.",
        description:
          "Choose plants that are suited to coastal Palawan conditions and the specific sunlight your space receives. We help match species to site, maintenance level, and design intent.",
        image:
          "https://images.pexels.com/photos/39823780/pexels-photo-39823780.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=560",
        videoUrl: "",
        alt: "Tropical potted plants and nursery greenery.",
        includes: [
          "Acclimatized ornamental palms, ferns, and flowering shrubs",
          "Organic potting mixes, mulch, and soil conditioners",
          "Direct site delivery and planting assistance in Palawan",
        ],
      },
    ],
  },

  whyChoose: {
    sectionTitle: "Why Choose Francesca's?",
    items: [
      {
        id: "benefit-pro",
        title: "Professional",
        description: "Skilled, experienced, and quality-focused.",
        icon: "professional",
      },
      {
        id: "benefit-rel",
        title: "Reliable",
        description: "On time, honest, and committed to great results.",
        icon: "reliable",
      },
      {
        id: "benefit-trop",
        title: "Tropical Expertise",
        description: "Deep understanding of Palawan's plants and climate.",
        icon: "tropical",
      },
      {
        id: "benefit-tail",
        title: "Tailored Solutions",
        description: "Designs and services fit to your space, style, and needs.",
        icon: "tailored",
      },
    ],
  },

  projects: {
    sectionTitle: "Featured Projects",
    viewAllText: "View All Projects",
    disclaimer:
      "Featured project images are illustrative placeholders, not photographs of Francesca's completed work. Authentic business photography will be added before launch.",
    items: [
      {
        id: "project-1",
        title: "Tropical garden entry",
        category: "Landscape design · sample",
        image:
          "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
        images: [
          "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
          "https://images.pexels.com/photos/6129981/pexels-photo-6129981.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
          "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
        ],
        videoUrl: "",
        alt: "Tropical garden entrance stairway with dense exotic planting.",
        description: "Stone staircase framed by broadleaf tropical shrubs, calatheas, and palm canopies.",
        isPlaceholderPhoto: true,
      },
      {
        id: "project-2",
        title: "Garden pathway & lawn",
        category: "Garden care · sample",
        image:
          "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
        images: [
          "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
          "https://images.pexels.com/photos/6416202/pexels-photo-6416202.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
        ],
        videoUrl: "",
        alt: "Curved garden stone walkway bordered by palms and manicured lawn.",
        description: "Neatly maintained pathway and coastal turf with natural stone stepping pavers.",
        isPlaceholderPhoto: true,
      },
      {
        id: "project-3",
        title: "Shaded outdoor lounge",
        category: "Outdoor living · sample",
        image:
          "https://images.pexels.com/photos/5563471/pexels-photo-5563471.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
        images: [
          "https://images.pexels.com/photos/5563471/pexels-photo-5563471.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
          "https://images.pexels.com/photos/35171519/pexels-photo-35171519.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
        ],
        videoUrl: "",
        alt: "Modern timber pergola outdoor sitting area beside pool with tropical garden.",
        description: "Comfortable shaded pavilion surrounded by potted monsteras and privacy screening trees.",
        isPlaceholderPhoto: true,
      },
    ],
  },

  process: {
    sectionTitle: "Our Process",
    intro: "A simple, clear process from ideas to long-term garden care.",
    items: [
      {
        id: "proc-1",
        title: "Consult",
        description: "Share your ideas, space, and goals.",
        icon: "consult",
      },
      {
        id: "proc-2",
        title: "Design",
        description: "Get a custom landscape plan and plant selection.",
        icon: "design",
      },
      {
        id: "proc-3",
        title: "Build",
        description: "Bring the design to life with quality work.",
        icon: "build",
      },
      {
        id: "proc-4",
        title: "Maintain",
        description: "Keep your garden healthy, beautiful, and thriving.",
        icon: "maintain",
      },
    ],
  },

  faq: {
    sectionTitle: "Frequently Asked Questions",
    subtitle:
      "Everything you need to know about our landscaping, garden care, and plant supply services in Palawan.",
    items: [
      {
        id: "faq-1",
        question: "What areas in Palawan do you provide services to?",
        answer:
          "We regularly service Puerto Princesa and surrounding municipalities. For larger residential estates, resort grounds, and boutique hospitality developments, we undertake projects across Palawan, including El Nido, San Vicente, and Coron by scheduled appointment.",
        category: "Service Areas",
      },
      {
        id: "faq-2",
        question: "How do you select plants that thrive in Palawan's climate?",
        answer:
          "Palawan experiences distinct tropical wet and dry seasons, alongside intense coastal sun and sea salt breezes. We source acclimatized native and tropical species — including heliconias, cordylines, bougainvillea, traveler's palms, and hardy groundcovers — that resist droughts, pests, and heavy monsoon rains with minimal chemical intervention.",
        category: "Plant Selection",
      },
      {
        id: "faq-3",
        question: "Do you offer ongoing garden maintenance or just one-off landscaping?",
        answer:
          "Both! We can execute a full one-time landscape installation, or partner with you for scheduled weekly, bi-weekly, or monthly garden care. Our maintenance programs cover precision pruning, lawn care, soil revitalization, and preventative pest management.",
        category: "Maintenance",
      },
      {
        id: "faq-4",
        question: "Can I order specific ornamental plants and pots for delivery?",
        answer:
          "Yes. Our Plant Supply division provides curated indoor and outdoor ornamental plants, shrubs, architectural palms, and decorative planters. We ensure all specimens are properly rooted and hardened before delivery to your location.",
        category: "Plant Supply",
      },
      {
        id: "faq-5",
        question: "How do I get an accurate cost estimate for my property?",
        answer:
          "Simply send an inquiry using our 'Get a Quote' form or tap 'Chat on WhatsApp'. Share your approximate location, lot dimensions, and photos of your current space. We will provide an initial estimate or schedule an on-site consultation.",
        category: "Pricing & Quotes",
      },
    ],
  },

  testimonials: {
    sectionTitle: "Client Feedback",
    trustHeading: "Trusted by homeowners and businesses in Palawan",
    ratingNote: "Rating design shown for layout only — verified reviews will replace placeholders.",
    items: [
      {
        id: "testi-1",
        name: "Maria L.",
        role: "Homeowner, Puerto Princesa",
        quote:
          "Francesca's Greens & Petals transformed our outdoor space into a beautiful, relaxing garden. The team is professional, easy to work with, and truly knows what works in Palawan.",
        rating: 5,
        isPlaceholder: true,
      },
    ],
  },

  quoteForm: {
    title: "Get a Quote",
    subtitle: "Tell us about your project and we'll get back to you soon.",
    nameLabel: "Your Name",
    emailLabel: "Email",
    phoneLabel: "Phone (Optional)",
    serviceLabel: "Service Needed",
    serviceOptions: [
      "Landscape Design",
      "Garden Care",
      "Plant Supply",
      "Resort Grounds Care",
      "Not sure yet — please advise",
    ],
    showLocationField: true,
    showBudgetField: true,
    messageLabel: "Project Details / Message",
    submitButtonText: "Send Inquiry",
    whatsappButtonText: "Chat on WhatsApp",
    whatsappNumber: "639171234567",
    submissionEndpoint: "",
  },

  footer: {
    blurb:
      "Landscaping & garden needs in Palawan — thoughtful outdoor spaces, healthy gardens, and tropical plants.",
    exploreTitle: "Explore",
    contactTitle: "Contact",
    followTitle: "Follow",
    phoneLabel: "+63 917 123 4567",
    phoneHref: "tel:+639171234567",
    emailLabel: "francescas@greenspetals.ph",
    emailHref: "mailto:francescas@greenspetals.ph",
    location: "Palawan, Philippines",
    hours: "Studio visits by appointment",
    copyright: "© 2026 Francesca's Greens & Petals. All rights reserved.",
    previewNote:
      "Editable site content — administrators can edit all text, media, colors, and links via the Admin Key below.",
    customLogoUrl: "",
    useCustomLogo: false,
    logoHeight: 46,
    socialLinks: [
      {
        id: "soc-fb",
        platform: "Facebook",
        label: "Facebook",
        url: "https://facebook.com",
        icon: "facebook",
        enabled: true,
      },
      {
        id: "soc-ig",
        platform: "Instagram",
        label: "Instagram",
        url: "https://instagram.com",
        icon: "instagram",
        enabled: true,
      },
      {
        id: "soc-yt",
        platform: "YouTube",
        label: "YouTube",
        url: "https://youtube.com",
        icon: "youtube",
        enabled: true,
      },
      {
        id: "soc-wa",
        platform: "WhatsApp",
        label: "WhatsApp",
        url: "https://wa.me/639171234567",
        icon: "whatsapp",
        enabled: true,
      },
    ],
  },
};
