/**
 * FRANCESCA'S GREENS & PETALS — EDITABLE SITE CONTENT
 * ---------------------------------------------------
 * Everything the business may need to change lives in this file:
 * contact details, services, project photos, process copy, testimonial
 * placeholder, gallery images, and the form submission endpoint.
 *
 * IMPORTANT CONTENT RULES
 * • Contact details below are deliberately bracketed placeholders.
 *   Replace them with verified business information before launch.
 * • Project and gallery images are clearly labelled illustrative
 *   placeholders. They are NOT photographs of Francesca's completed work.
 *   Swap each `image` and `alt` for authentic business photography.
 * • The testimonial is a placeholder. Do not publish an endorsement until
 *   a genuine, approved customer review is supplied.
 */

export type NavLink = { label: string; href: string };

export type Service = {
  id: string;
  title: string;
  icon: "landscape" | "care" | "supply";
  blurb: string;
  description: string;
  image: string;
  alt: string;
  includes: string[];
};

export type Project = {
  id: string;
  title: string;
  category: string;
  image: string;
  alt: string;
  /** Set to false once an authentic Francesca's project photograph is added. */
  isPlaceholderPhoto: boolean;
};

export const siteContent = {
  brand: {
    name: "Francesca's Greens & Petals",
    shortName: "Francesca's",
    tagline: "Landscaping & Garden Needs",
    blurb: "Landscaping & garden needs in Palawan.",
  },

  nav: [
    { label: "Home", href: "#home" },
    { label: "Services", href: "#services" },
    { label: "Projects", href: "#projects" },
    { label: "About", href: "#about" },
    { label: "Contact", href: "#contact" },
  ] satisfies NavLink[],

  /**
   * Verified business details go here. Keep the brackets until the owner
   * confirms each detail — nothing on the site should imply they are live.
   */
  contact: {
    phoneLabel: "+63 9XX XXX XXXX",
    phoneHref: "",
    emailLabel: "hello@[yourdomain].ph",
    emailHref: "",
    location: "Palawan, Philippines",
    /** Full international number, digits only, e.g. "639171234567". */
    whatsappNumber: "",
    instagram: "",
    facebook: "",
    youtube: "",
    hours: "Studio visits by appointment",
  },

  /** Add a POST endpoint (Formspree, Basin, custom API…) when ready. */
  formEndpoint: "",

  hero: {
    eyebrow: "Palawan landscaping & garden needs",
    headline: ["Beautiful Outdoor", "Spaces for", "Tropical Living"],
    description:
      "Landscaping, garden care, and plant supply in Palawan — designed for beautiful, sustainable, and easy-to-maintain outdoor spaces.",
    image: "/images/hero-tropical-landscaping.jpg",
    alt: "Master tropical landscape design in Palawan with stone stairs, vibrant red cordylines, blooming exotic flowers, lanterns, and outdoor planters.",
  },

  services: [
    {
      id: "landscape-design",
      title: "Landscape Design",
      icon: "landscape",
      blurb:
        "Creative and functional landscape solutions for homes, resorts, and businesses.",
      description:
        "We plan outdoor spaces around how you actually live and work. Planting, paths, lighting, and hardscape are considered together so the garden looks intentional and thrives in Palawan's climate.",
      image:
        "https://images.pexels.com/photos/28586235/pexels-photo-28586235.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=560",
      alt: "Illustrative photograph of a stone villa surrounded by tropical planting.",
      includes: [
        "Site visit and brief consultation",
        "Planting plan and material suggestions",
        "Garden layout for new builds or refreshes",
      ],
    },
    {
      id: "garden-care",
      title: "Garden Care",
      icon: "care",
      blurb:
        "Professional garden maintenance to keep your outdoor spaces healthy and vibrant.",
      description:
        "Regular, practical care keeps a tropical garden lush instead of overgrown. We work with a maintenance rhythm that suits your space, from a small courtyard to resort grounds.",
      image:
        "https://images.pexels.com/photos/37108159/pexels-photo-37108159.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=560",
      alt: "Illustrative close-up photograph of a pink hibiscus in bloom.",
      includes: [
        "Pruning, weeding, and plant health checks",
        "Seasonal maintenance schedules",
        "Advice on watering and soil care",
      ],
    },
    {
      id: "plant-supply",
      title: "Plant Supply",
      icon: "supply",
      blurb:
        "Quality ornamental plants, shrubs, and garden essentials sourced for Palawan's tropical climate.",
      description:
        "Choose plants that are suited to coastal Palawan conditions and the light your space receives. We help match species to site, maintenance level, and design intent.",
      image:
        "https://images.pexels.com/photos/39823780/pexels-photo-39823780.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=560",
      alt: "Illustrative photograph of tropical plants in pots at an outdoor nursery.",
      includes: [
        "Ornamental plants and shrubs",
        "Garden essentials and growing advice",
        "Selection guidance for sun and salt exposure",
      ],
    },
  ] satisfies Service[],

  benefits: [
    {
      title: "Professional",
      description: "Skilled, experienced, and quality-focused.",
      icon: "professional",
    },
    {
      title: "Reliable",
      description: "On time, honest, and committed to great results.",
      icon: "reliable",
    },
    {
      title: "Tropical Expertise",
      description: "Deep understanding of Palawan's plants and climate.",
      icon: "tropical",
    },
    {
      title: "Tailored Solutions",
      description: "Designs and services fit to your space, style, and needs.",
      icon: "tailored",
    },
  ],

  /**
   * PLACEHOLDER GALLERY — replace every image with authentic business
   * photography. These stock images are illustrative only.
   */
  projects: [
    {
      id: "garden-entry",
      title: "Tropical garden entry",
      category: "Landscape design · sample",
      image:
        "https://images.pexels.com/photos/6129997/pexels-photo-6129997.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
      alt: "Illustrative tropical villa staircase with green planting — awaiting authentic project photography.",
      isPlaceholderPhoto: true,
    },
    {
      id: "stone-pathway",
      title: "Garden pathway & lawn",
      category: "Garden care · sample",
      image:
        "https://images.pexels.com/photos/14036439/pexels-photo-14036439.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
      alt: "Illustrative stone path lined with palms — awaiting authentic project photography.",
      isPlaceholderPhoto: true,
    },
    {
      id: "garden-lounge",
      title: "Shaded outdoor lounge",
      category: "Outdoor living · sample",
      image:
        "https://images.pexels.com/photos/5563471/pexels-photo-5563471.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
      alt: "Illustrative covered outdoor lounge beside a pool — awaiting authentic project photography.",
      isPlaceholderPhoto: true,
    },
    {
      id: "palm-walk",
      title: "Palm walk & border planting",
      category: "Plant supply · sample",
      image:
        "https://images.pexels.com/photos/6416202/pexels-photo-6416202.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
      alt: "Illustrative walkway between palms — awaiting authentic project photography.",
      isPlaceholderPhoto: true,
    },
    {
      id: "resort-terrace",
      title: "Resort terrace planting",
      category: "Hospitality grounds · sample",
      image:
        "https://images.pexels.com/photos/35171519/pexels-photo-35171519.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
      alt: "Illustrative tropical resort seating terrace — awaiting authentic project photography.",
      isPlaceholderPhoto: true,
    },
    {
      id: "garden-refresh",
      title: "Garden refresh & maintenance",
      category: "Garden care · sample",
      image:
        "https://images.pexels.com/photos/7854134/pexels-photo-7854134.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=720",
      alt: "Illustrative gardener pruning a hedge — awaiting authentic project photography.",
      isPlaceholderPhoto: true,
    },
  ] satisfies Project[],

  processingNote:
    "Featured project images are illustrative placeholders, not photographs of Francesca's completed work. Authentic business photography will be added before launch.",

  process: {
    intro: "A simple, clear process from ideas to long-term garden care.",
    steps: [
      {
        title: "Consult",
        description: "Share your ideas, space, and goals.",
        icon: "consult",
      },
      {
        title: "Design",
        description: "Get a custom landscape plan and plant selection.",
        icon: "design",
      },
      {
        title: "Build",
        description: "Bring the design to life with quality work.",
        icon: "build",
      },
      {
        title: "Maintain",
        description: "Keep your garden healthy, beautiful, and thriving.",
        icon: "maintain",
      },
    ],
  },

  /** PLACEHOLDER TESTIMONIAL — no real customer endorsement is implied. */
  testimonial: {
    isPlaceholder: true,
    quote:
      "This space is reserved for a verified customer review. Once a real testimonial from a Palawan homeowner or business has been approved for publication, it will appear here — in their own words.",
    name: "Customer name",
    role: "Homeowner, Palawan",
    portraitNote: "Portrait placeholder",
    rating: 5,
    ratingNote: "Rating design shown for layout only — no verified reviews yet.",
    trustHeading: "Trusted by homeowners and businesses in Palawan",
  },

  serviceOptions: [
    "Landscape Design",
    "Garden Care",
    "Plant Supply",
    "Not sure yet — please advise",
  ],

  footer: {
    navigationHeading: "Explore",
    contactHeading: "Contact",
    legal: `© ${new Date().getFullYear()} Francesca's Greens & Petals. All rights reserved.`,
    placeholderNote:
      "Preview build — contact details, social links, and project photography are editable placeholders pending verification.",
  },
};

export type SiteContent = typeof siteContent;
