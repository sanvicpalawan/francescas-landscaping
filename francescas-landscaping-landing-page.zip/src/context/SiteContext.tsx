import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import {
  type SiteData,
  type FormSubmission,
  INITIAL_SITE_DATA,
} from "../types/siteData";

const STORAGE_KEY = "francescas_greens_petals_data_v3";
const SUBMISSIONS_KEY = "francescas_form_submissions_v2";

interface SiteContextType {
  data: SiteData;
  updateData: (updater: (prev: SiteData) => SiteData) => void;
  resetToDefaults: () => void;
  exportJson: () => string;
  importJson: (json: string) => boolean;
  isAdminOpen: boolean;
  openAdmin: () => void;
  closeAdmin: () => void;
  toggleAdmin: () => void;
  // Submissions Inbox
  submissions: FormSubmission[];
  addSubmission: (
    item: Omit<FormSubmission, "id" | "timestamp" | "read">,
  ) => void;
  markSubmissionRead: (id: string) => void;
  deleteSubmission: (id: string) => void;
  clearSubmissions: () => void;
}

const SiteContext = createContext<SiteContextType | null>(null);

export function SiteProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<SiteData>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Deep merge with INITIAL_SITE_DATA to ensure new fields (like faq, videos) exist
        return {
          ...INITIAL_SITE_DATA,
          ...parsed,
          theme: { ...INITIAL_SITE_DATA.theme, ...parsed.theme },
          header: { ...INITIAL_SITE_DATA.header, ...parsed.header },
          hero: { ...INITIAL_SITE_DATA.hero, ...parsed.hero },
          sectionVisibility: {
            ...INITIAL_SITE_DATA.sectionVisibility,
            ...parsed.sectionVisibility,
          },
          services: { ...INITIAL_SITE_DATA.services, ...parsed.services },
          whyChoose: { ...INITIAL_SITE_DATA.whyChoose, ...parsed.whyChoose },
          projects: { ...INITIAL_SITE_DATA.projects, ...parsed.projects },
          process: { ...INITIAL_SITE_DATA.process, ...parsed.process },
          faq: { ...INITIAL_SITE_DATA.faq, ...parsed.faq },
          testimonials: {
            ...INITIAL_SITE_DATA.testimonials,
            ...parsed.testimonials,
          },
          quoteForm: { ...INITIAL_SITE_DATA.quoteForm, ...parsed.quoteForm },
          footer: { ...INITIAL_SITE_DATA.footer, ...parsed.footer },
        };
      }
    } catch (e) {
      console.warn("Failed to load saved site data from localStorage", e);
    }
    return INITIAL_SITE_DATA;
  });

  const [submissions, setSubmissions] = useState<FormSubmission[]>(() => {
    try {
      const stored = localStorage.getItem(SUBMISSIONS_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn("Failed to load form submissions", e);
    }
    return [];
  });

  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Sync site data to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.warn("Failed to save site data to localStorage", e);
    }
  }, [data]);

  // Sync submissions to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
    } catch (e) {
      console.warn("Failed to save submissions to localStorage", e);
    }
  }, [submissions]);

  // Apply dynamic theme colors and fonts to CSS variables
  useEffect(() => {
    const root = document.documentElement;
    const { theme } = data;

    root.style.setProperty("--color-forest", theme.forest);
    root.style.setProperty("--color-forest-deep", theme.forestDeep);
    root.style.setProperty("--color-leaf", theme.leaf);
    root.style.setProperty("--color-leaf-dark", theme.leafDark);
    root.style.setProperty("--color-cream", theme.cream);
    root.style.setProperty("--color-cream-line", theme.creamLine);
    root.style.setProperty("--color-earth", theme.earth);

    // Apply font variables
    root.style.setProperty(
      "--font-display",
      `"${theme.headingFont}", ui-sans-serif, system-ui, sans-serif`,
    );
    root.style.setProperty(
      "--font-sans",
      `"${theme.bodyFont}", ui-sans-serif, system-ui, sans-serif`,
    );

    // Load Google fonts dynamically if needed
    const fontNames = [theme.headingFont, theme.bodyFont].filter(Boolean);
    const linkId = "dynamic-google-fonts";
    let linkEl = document.getElementById(linkId) as HTMLLinkElement | null;
    if (!linkEl) {
      linkEl = document.createElement("link");
      linkEl.id = linkId;
      linkEl.rel = "stylesheet";
      document.head.appendChild(linkEl);
    }
    const fontParams = fontNames
      .map((f) => `family=${f.replace(/ /g, "+")}:wght@400;500;600;700;800`)
      .join("&");
    linkEl.href = `https://fonts.googleapis.com/css2?${fontParams}&display=swap`;
  }, [data.theme]);

  // Keyboard shortcut for admin: Ctrl/Cmd + Shift + A or Alt + A
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey || e.altKey) && e.shiftKey && (e.key === "a" || e.key === "A")) {
        e.preventDefault();
        setIsAdminOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const updateData = useCallback((updater: (prev: SiteData) => SiteData) => {
    setData((prev) => updater(prev));
  }, []);

  const resetToDefaults = useCallback(() => {
    setData(INITIAL_SITE_DATA);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const exportJson = useCallback(() => {
    return JSON.stringify(data, null, 2);
  }, [data]);

  const importJson = useCallback((jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed && typeof parsed === "object" && parsed.hero && parsed.services) {
        setData({
          ...INITIAL_SITE_DATA,
          ...parsed,
        });
        return true;
      }
    } catch (e) {
      console.error("Invalid JSON imported", e);
    }
    return false;
  }, []);

  const openAdmin = useCallback(() => setIsAdminOpen(true), []);
  const closeAdmin = useCallback(() => setIsAdminOpen(false), []);
  const toggleAdmin = useCallback(() => setIsAdminOpen((v) => !v), []);

  const addSubmission = useCallback(
    (item: Omit<FormSubmission, "id" | "timestamp" | "read">) => {
      const newSub: FormSubmission = {
        ...item,
        id: "sub-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7),
        timestamp: new Date().toISOString(),
        read: false,
      };
      setSubmissions((prev) => [newSub, ...prev]);
    },
    [],
  );

  const markSubmissionRead = useCallback((id: string) => {
    setSubmissions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, read: true } : s)),
    );
  }, []);

  const deleteSubmission = useCallback((id: string) => {
    setSubmissions((prev) => prev.filter((s) => s.id !== id));
  }, []);

  const clearSubmissions = useCallback(() => {
    setSubmissions([]);
    localStorage.removeItem(SUBMISSIONS_KEY);
  }, []);

  return (
    <SiteContext.Provider
      value={{
        data,
        updateData,
        resetToDefaults,
        exportJson,
        importJson,
        isAdminOpen,
        openAdmin,
        closeAdmin,
        toggleAdmin,
        submissions,
        addSubmission,
        markSubmissionRead,
        deleteSubmission,
        clearSubmissions,
      }}
    >
      {children}
    </SiteContext.Provider>
  );
}

export function useSite() {
  const context = useContext(SiteContext);
  if (!context) {
    throw new Error("useSite must be used within a SiteProvider");
  }
  return context;
}
