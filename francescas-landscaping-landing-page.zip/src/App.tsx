import { useCallback, useState } from "react";
import { SiteProvider } from "./context/SiteContext";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { WhyChoose } from "./components/WhyChoose";
import { Projects } from "./components/Projects";
import { Process } from "./components/Process";
import { FaqSection } from "./components/FaqSection";
import { Testimonials } from "./components/Testimonials";
import { QuoteForm } from "./components/QuoteForm";
import { Footer } from "./components/Footer";
import { AdminBackend } from "./components/admin/AdminBackend";

function LandingPageContent() {
  const [presetService, setPresetService] = useState<{
    service: string;
    key: number;
  } | null>(null);

  const handleRequestQuote = useCallback((service: string) => {
    setPresetService({ service, key: Date.now() });
    window.requestAnimationFrame(() => {
      document
        .getElementById("contact")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, []);

  return (
    <div className="min-h-screen bg-cream antialiased">
      <Header />
      <main>
        <Hero />
        <Services onRequestQuote={handleRequestQuote} />
        <WhyChoose />
        <Projects />
        <Process />
        <FaqSection />
        <Testimonials />
        <QuoteForm presetService={presetService} />
      </main>
      <Footer />

      {/* Full Admin Backend Panel */}
      <AdminBackend />
    </div>
  );
}

export default function App() {
  return (
    <SiteProvider>
      <LandingPageContent />
    </SiteProvider>
  );
}
